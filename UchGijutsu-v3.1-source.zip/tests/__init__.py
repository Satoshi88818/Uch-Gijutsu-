"""Test package (enables `from tests._campaign import ...`)."""
