import numpy as np
import pytest

from uchu import SimConfig, make_rng, child_seed, provenance
from uchu.config import DType, ProcessNode
from uchu.stats import poisson_rate_ci, wilson_ci


def test_same_keys_same_stream_different_keys_differ():
    a = make_rng(1, "x").random(5)
    assert np.array_equal(a, make_rng(1, "x").random(5))
    assert not np.array_equal(a, make_rng(1, "y").random(5))
    assert not np.array_equal(a, make_rng(2, "x").random(5))


def test_child_seed_deterministic_and_distinct():
    assert child_seed(7, "s", 1) == child_seed(7, "s", 1)
    assert len({child_seed(7, "s", i) for i in range(1000)}) == 1000


def test_global_rng_untouched():
    np.random.seed(123)
    before = np.random.get_state()[1].copy()
    make_rng(5, "a").random(100)
    assert np.array_equal(before, np.random.get_state()[1])


def test_default_config_validates_and_hash_is_stable():
    c = SimConfig().validate()
    assert c.config_hash() == SimConfig().config_hash()
    c2 = c.copy(); c2.compute.array_size = 128
    assert c2.config_hash() != c.config_hash()


@pytest.mark.parametrize("mutate", [
    lambda c: setattr(c.compute, "array_size", 0),
    lambda c: setattr(c.power, "static_frac", 1.0),
    lambda c: setattr(c.dvfs, "nom_voltage_v", 2.0),
    lambda c: setattr(c.radiation, "mbu_prob", 1.5),
    lambda c: setattr(c.radiation, "scrub_interval_s", 0.0),
    lambda c: setattr(c.thermal, "capacitance_j_per_k", -1.0),
])
def test_invalid_configs_rejected(mutate):
    c = SimConfig(); mutate(c)
    with pytest.raises(ValueError):
        c.validate()


def test_dtype_throughput_is_not_inverted():
    assert DType.INT4.pe_throughput > DType.INT8.pe_throughput > DType.FP16.pe_throughput > DType.FP32.pe_throughput


def test_provenance_fields():
    p = provenance(SimConfig())
    assert {"model_version", "config_hash", "seed", "numpy", "scipy"} <= set(p)


def test_poisson_ci_covers_and_zero_case():
    lo, hi = poisson_rate_ci(0, 10.0)
    assert lo == 0.0 and 0.365 < hi < 0.373         # 3.689/10 (exact Garwood)
    lo, hi = poisson_rate_ci(100, 1.0)
    assert lo < 100 < hi


def test_poisson_ci_coverage_monte_carlo():
    rng = make_rng(0, "cov")
    lam, n, cover = 7.3, 4000, 0
    for k in rng.poisson(lam, size=n):
        lo, hi = poisson_rate_ci(int(k), 1.0)
        cover += lo <= lam <= hi
    assert cover / n >= 0.94          # exact interval is conservative (>= nominal 95%)


def test_wilson_ci_basic():
    lo, hi = wilson_ci(50, 100)
    assert 0.40 < lo < 0.5 < hi < 0.60


def test_bootstrap_ci_brackets_mean_and_shrinks_with_n():
    from uchu.stats import bootstrap_ci
    rng = make_rng(0, "b")
    small, large = rng.normal(5.0, 2.0, 30), rng.normal(5.0, 2.0, 3000)
    lo, hi = bootstrap_ci(small, rng=make_rng(1, "bb"))
    assert lo < small.mean() < hi
    lo2, hi2 = bootstrap_ci(large, n_boot=500, rng=make_rng(1, "bb"))
    assert (hi2 - lo2) < 0.3 * (hi - lo) and lo2 < 5.0 < hi2
