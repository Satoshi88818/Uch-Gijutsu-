import numpy as np
import pytest

from uchu import flip_bit, measure_gemm_vulnerability


def test_int8_two_complement_flips_and_involution():
    a = np.zeros(4, dtype=np.int8)
    assert flip_bit(a, 2, 7)[2] == -128 and flip_bit(a, 2, 0)[2] == 1 and flip_bit(a, 2, 6)[2] == 64
    b = flip_bit(a, 1, 5)
    assert np.array_equal(flip_bit(b, 1, 5), a)
    assert a.sum() == 0                                  # input untouched


def test_float_flips_follow_ieee754():
    assert flip_bit(np.array([1.0], np.float32), 0, 31)[0] == -1.0
    assert np.isinf(flip_bit(np.array([1.0], np.float32), 0, 30)[0])
    assert flip_bit(np.array([1.0], np.float16), 0, 15)[0] == -1.0
    assert flip_bit(np.array([1.0], np.float32), 0, 0)[0] == np.nextafter(np.float32(1.0), np.float32(2.0))


def test_flip_preserves_shape_and_handles_noncontiguous():
    a = np.arange(12, dtype=np.int8).reshape(3, 4).T          # non-contiguous view
    out = flip_bit(a, 5, 0)
    assert out.shape == a.shape and (out != a).sum() == 1


def test_flip_bit_range_checked():
    with pytest.raises(ValueError):
        flip_bit(np.zeros(2, np.int8), 0, 8)
    with pytest.raises(ValueError):
        flip_bit(np.zeros(2, np.float32), 0, -1)


def test_avf_zero_tolerance_is_one_and_monotone_in_tolerance():
    r0 = measure_gemm_vulnerability(tol=0.0, trials_per_bit=40, seed=1)
    assert r0.avf == 1.0
    prev = 1.0
    for tol in (1e-4, 1e-3, 1e-2, 1e-1, 1.0, 1e9):
        r = measure_gemm_vulnerability(tol=tol, trials_per_bit=40, seed=1)
        assert r.avf <= prev + 1e-12
        prev = r.avf
    assert prev == 0.0


def test_int8_msb_is_far_more_vulnerable_than_lsb():
    r = measure_gemm_vulnerability(tol=1e-2, trials_per_bit=80, seed=2)
    assert r.per_bit_avf[7] > 0.9 and r.per_bit_avf[0] < 0.05
    assert 0.2 < r.avf < 0.6                                  # roughly the top 3 of 8 bits matter
    assert r.ci_low <= r.avf <= r.ci_high and r.ci_high - r.ci_low < 0.15
    assert r.n_trials == 8 * 80


def test_float32_exponent_bits_dominate():
    r = measure_gemm_vulnerability(dtype="float32", tol=1e-2, trials_per_bit=60, seed=3)
    assert r.per_bit_avf[30] > 0.7 and r.per_bit_avf[0] == 0.0 and r.per_bit_avf[23] < r.per_bit_avf[30]


def test_vulnerability_is_reproducible_and_seed_sensitive():
    kw = dict(dtype="float32", tol=1e-3, trials_per_bit=30)      # fractional per-bit AVFs (mantissa bits)
    a = measure_gemm_vulnerability(seed=7, **kw)
    assert a == measure_gemm_vulnerability(seed=7, **kw)
    assert a.per_bit_avf != measure_gemm_vulnerability(seed=8, **kw).per_bit_avf
