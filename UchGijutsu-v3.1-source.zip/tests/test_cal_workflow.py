import copy
import dataclasses
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

import uchu.calibration.workflow as W
from uchu import SimConfig, build_transformer_workload, make_rng
from uchu.calibration import (CalibrationOptions, epistemic_mission_study, load_plan, placeholder_audit, run_calibration)
from uchu.calibration.data import FlightLog, ThermalSample
from uchu.calibration.registry import get_by_path
from uchu.calibration.synthetic import write_campaign
from uchu.calibration.workflow import _static_rate_per_bit_day, main
from tests._campaign import START, TRUTH, build

OPTS = CalibrationOptions(seed=7, n_boot=60, n_draws=60)
ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def full():
    d = build(11)
    return d, run_calibration(START, d, OPTS)


def near(ci, est, truth, k=3.5):
    se = (ci[1] - ci[0]) / (2 * 1.96)
    return abs(est - truth) <= k * se + 1e-12 * max(1.0, abs(truth))


# ====================================================================== end to end vs hidden truth
def test_every_step_succeeds_and_the_input_config_is_untouched(full):
    d, rep = full
    assert all(s.status == "ok" for s in rep.steps), [(s.name, s.error) for s in rep.steps if s.status != "ok"]
    assert START.calibration == {} and START.radiation.sram.ion.sigma_sat_cm2 == 1e-14      # caller's config not mutated
    assert rep.config.config_hash() != rep.initial_hash and rep.initial_hash == START.config_hash()
    rep.config.validate()
    assert SimConfig.from_json(rep.config.to_json()).config_hash() == rep.config.config_hash()


def test_calibrated_parameters_recover_the_hidden_truth(full):
    _, rep = full
    cal, inside, tot, bad = rep.config.calibration, 0, 0, []
    for path, e in cal.items():
        if e["ci95"] is None or path == "radiation.avf_sram":          # avf has no hidden truth: it is a measurement
            continue
        tv, lo, hi = get_by_path(TRUTH, path), *e["ci95"]
        tot += 1; inside += lo <= tv <= hi
        if not near(e["ci95"], e["value"], tv):
            bad.append((path, tv, e["value"], e["ci95"]))
    assert tot >= 28 and inside / tot >= 0.85, (inside, tot)
    assert not bad, bad


def test_predicted_rate_moves_from_a_3x_error_to_within_15_percent(full):
    _, rep = full
    truth = _static_rate_per_bit_day(TRUTH, "sram")
    d = rep.rate_summary["sram"]
    assert truth / d["placeholder"] > 2.5                                    # the shipped placeholder was badly off
    assert d["median"] == pytest.approx(truth, rel=0.15)
    assert d["lo"] <= truth <= d["hi"] and d["posterior"]["lo"] <= truth <= d["posterior"]["hi"]
    assert (d["posterior"]["hi"] - d["posterior"]["lo"]) < (d["hi"] - d["lo"])      # flight data tighten the interval
    assert d["unresolved_fraction"] == 0.0


def test_intervals_resting_on_placeholders_are_flagged(full):
    _, rep = full
    r = rep.rate_summary["register"]
    assert r["unresolved_kinds"] == ["proton"] and r["unresolved_fraction"] > 0.99
    assert "⚠ 100% rests on placeholder proton" in rep.to_markdown()


def test_audit_lists_exactly_what_the_data_did_not_cover(full):
    _, rep = full
    a = rep.audit
    for p in ("radiation.logic_set.ion.sigma_sat_cm2", "radiation.sel.ion.x_th", "radiation.register.proton.width",
              "power.interconnect_frac", "power.interconnect_extra_exponent", "radiation.avf_register",
              "radiation.set_pulse_width_ps", "radiation.reg_bits_per_pe", "radiation.sel_recovery_s"):
        assert p in a.unresolved, p
    for p in ("radiation.sram.ion.sigma_sat_cm2", "radiation.environment", "radiation.mbu_prob", "orbital.sep_events_per_year",
              "power.base_power_w", "thermal.capacitance_j_per_k", "compute.pipeline_overlap", "memory.hbm_efficiency",
              "radiation.gates_per_pe", "radiation.avf_sram", "memory.ecc_bw_overhead_pct", "thermal.albedo_geometry"):
        assert p in a.resolved, p
    assert a.n_total == len(a.resolved) + len(a.accepted) + len(a.unresolved) and len(a.resolved) > 35


def test_flight_data_are_consistent_with_the_calibrated_model(full):
    _, rep = full
    f = rep.flight[0]
    assert f.p_consistency > 0.05 and f.ess > 10 and not f.warnings
    assert abs(f.observed - f.expected_prior_mean) < 4 * f.expected_prior_mean ** 0.5          # within 4 Poisson sigma


def test_report_serialises_and_renders(full):
    _, rep = full
    js = json.loads(json.dumps(rep.to_dict(), default=str))
    assert {"steps", "ledger", "audit", "rate_summary", "flight", "provenance"} <= set(js)
    assert js["audit"]["unresolved"] and js["calibrated_config_hash"] == rep.config.config_hash()
    md = rep.to_markdown()
    for h in ("# Calibration report", "## Steps", "## Calibrated parameters", "## Still placeholders", "## Flight-data consistency"):
        assert h in md
    assert "`radiation.sram.ion.sigma_sat_cm2`" in md


def test_determinism_and_seed_sensitivity():
    d = build(3, flight=False, hardware=False, avf=False)
    o = CalibrationOptions(seed=1, n_boot=30, n_draws=20)
    a, b = run_calibration(START, d, o), run_calibration(START, d, o)
    assert json.dumps(a.to_dict(), default=str) == json.dumps(b.to_dict(), default=str)
    c = run_calibration(START, d, dataclasses.replace(o, seed=2))
    assert c.config.calibration["radiation.sram.ion.x_th"]["ci95"] != a.config.calibration["radiation.sram.ion.x_th"]["ci95"]
    assert c.config.radiation.sram.ion == a.config.radiation.sram.ion          # point estimates are data-driven (seed only affects intervals)


# ====================================================================== failure isolation
def test_bad_data_in_one_step_fails_only_that_step_and_leaves_placeholders_alone():
    d = build(5, flight=False, avf=False)
    d.thermal = d.thermal[:6]                                               # far too short
    rep = run_calibration(START, d, dataclasses.replace(OPTS, n_boot=30, n_draws=10))
    st = {s.name: s for s in rep.steps}
    assert st["thermal model"].status == "failed" and "thermal telemetry samples" in st["thermal model"].error
    assert all(s.status in ("ok", "skipped") for n, s in st.items() if n != "thermal model")
    assert {n for n, s in st.items() if s.status == "skipped"} == {"flight-data update"}
    assert rep.config.thermal.capacitance_j_per_k == START.thermal.capacitance_j_per_k          # untouched
    assert "thermal.capacitance_j_per_k" in rep.audit.unresolved and "power.base_power_w" in rep.audit.resolved


def test_internal_bugs_are_not_disguised_as_data_problems(monkeypatch):
    d = build(5, flight=False, avf=False, mbu=False, sep=False, register=False)
    monkeypatch.setattr(W, "fit_power_model", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")))
    rep = run_calibration(START, d, dataclasses.replace(OPTS, n_boot=20, n_draws=5))
    s = next(s for s in rep.steps if s.name == "power model")
    assert s.status == "failed" and s.error.startswith("INTERNAL RuntimeError: boom")


def test_skipped_steps_when_no_data_and_empty_run_is_harmless():
    rep = run_calibration(START, W.CalibrationData(), OPTS)
    assert rep.steps and all(s.status == "skipped" for s in rep.steps)
    assert rep.config.config_hash() == START.config_hash() and rep.draws == [] and rep.rate_summary == {}
    assert len(rep.audit.unresolved) == rep.audit.n_total


# ====================================================================== flight data & epistemic propagation
def _small(seed, events_scale=1.0):
    d = build(seed, hardware=False, mbu=False, sep=False, register=False, avf=False)
    f = d.flight[0]
    d.flight = [FlightLog(f.name, f.region, f.n_units, f.segments, int(round(f.events * events_scale)), f.flare_events)]
    return d


def test_flight_counts_move_the_posterior_in_the_right_direction():
    o = dataclasses.replace(OPTS, n_boot=40, n_draws=120)
    lo = run_calibration(START, _small(21, 0.6), o).rate_summary["sram"]["posterior"]["median"]
    mid = run_calibration(START, _small(21, 1.0), o).rate_summary["sram"]["posterior"]["median"]
    hi = run_calibration(START, _small(21, 1.5), o).rate_summary["sram"]["posterior"]["median"]
    assert lo < mid < hi


def test_inconsistent_flight_data_raise_a_loud_flag_unless_discrepancy_is_allowed():
    d = _small(21, 8.0)
    o = dataclasses.replace(OPTS, n_boot=40, n_draws=100)
    rep = run_calibration(START, d, o)
    assert rep.flight[0].p_consistency < 0.01 and any("inconsistent" in w for s in rep.steps for w in s.warnings)
    soft = run_calibration(START, d, dataclasses.replace(o, flight_discrepancy_log_sigma=2.0))
    assert soft.flight[0].p_consistency > rep.flight[0].p_consistency


def test_sample_configs_are_valid_reproducible_and_span_the_uncertainty(full):
    _, rep = full
    cfgs = rep.sample_configs(40, make_rng(1, "s"))
    assert len(cfgs) == 40 and all(c.validate() for c in cfgs)
    again = rep.sample_configs(40, make_rng(1, "s"))
    assert [c.config_hash() for c in cfgs] == [c.config_hash() for c in again]
    sig = np.array([c.radiation.sram.ion.sigma_sat_cm2 for c in cfgs])
    lo, hi = rep.config.calibration["radiation.sram.ion.sigma_sat_cm2"]["ci95"]
    assert sig.std() > 0 and lo * 0.5 < np.median(sig) < hi * 1.5
    assert len({c.power.base_power_w for c in cfgs}) > 10 and len({c.thermal.capacitance_j_per_k for c in cfgs}) > 10
    assert rep.config_for_draw(0).radiation.sram.ion is not rep.config.radiation.sram.ion          # no aliasing


def test_epistemic_study_pushes_calibration_uncertainty_through_the_simulator(full):
    _, rep = full
    layers = build_transformer_workload(num_layers=2)
    out = epistemic_mission_study(rep, layers, mission_s=900.0, n=8, dt_max_s=30.0, seed=3)
    assert set(out) == {"T_max_k", "avg_tflops", "avg_power_w", "sdc_per_hr", "seu_sram"} and all(len(v) == 8 for v in out.values())
    assert np.all(np.isfinite(out["T_max_k"])) and np.all(out["avg_power_w"] > 5)
    assert out["avg_power_w"].std() > 0 and out["avg_power_w"].std() / out["avg_power_w"].mean() < 0.1
    again = epistemic_mission_study(rep, layers, mission_s=900.0, n=8, dt_max_s=30.0, seed=3)
    assert np.array_equal(out["avg_power_w"], again["avg_power_w"])


def test_calibrated_config_behaves_like_the_truth_in_the_simulator(full):
    from uchu import run_mission
    _, rep = full
    layers = build_transformer_workload(num_layers=4)
    t = run_mission(TRUTH, layers, 3000.0, dt_max_s=30.0, seed=1)
    c = run_mission(rep.config, layers, 3000.0, dt_max_s=30.0, seed=1)
    p = run_mission(START, layers, 3000.0, dt_max_s=30.0, seed=1)
    # measured: calibrated within <1 % of truth on power/throughput and <1 K on temperature; placeholders are 16-26 % / 21 K off
    assert c.avg_power_w == pytest.approx(t.avg_power_w, rel=0.02) and abs(p.avg_power_w - t.avg_power_w) > 0.15 * t.avg_power_w
    assert c.avg_tflops_dense == pytest.approx(t.avg_tflops_dense, rel=0.02) and abs(p.avg_tflops_dense - t.avg_tflops_dense) > 0.08 * t.avg_tflops_dense
    assert abs(c.T_mean_k - t.T_mean_k) < 1.0 and abs(p.T_mean_k - t.T_mean_k) > 10.0


# ====================================================================== CLI / files
def test_cli_end_to_end_from_csv_files(tmp_path):
    plan = write_campaign(tmp_path / "camp", TRUTH, START, make_rng(31, "cli"))
    out = tmp_path / "out"
    assert main([str(plan), "--out", str(out)]) == 0
    for f in ("calibrated_config.json", "calibration_report.json", "calibration_report.md"):
        assert (out / f).stat().st_size > 500
    cfg = SimConfig.from_json((out / "calibrated_config.json").read_text()).validate()
    assert cfg.calibration["radiation.sram.ion.sigma_sat_cm2"]["status"] == "measured"
    assert cfg.radiation.environment_mode == "tabulated_orbit" and cfg.radiation.gates_per_pe == 1800
    rep = json.loads((out / "calibration_report.json").read_text())
    assert all(s["status"] == "ok" for s in rep["steps"]) and rep["audit"]["unresolved"]
    assert "# Calibration report" in (out / "calibration_report.md").read_text()


def test_cli_plan_errors_and_failed_steps_have_distinct_exit_codes(tmp_path):
    plan = write_campaign(tmp_path / "camp", TRUTH, START, make_rng(32, "cli"))
    p = json.loads(plan.read_text())
    bad = tmp_path / "camp" / "bad_plan.json"
    q = copy.deepcopy(p); q["beam"][0]["file"] = "does_not_exist.csv"; bad.write_text(json.dumps(q))
    assert main([str(bad), "--out", str(tmp_path / "o1")]) == 3
    q = copy.deepcopy(p); (tmp_path / "camp" / "mbu.csv").write_text("cluster_size,count\n1,x\n"); bad.write_text(json.dumps(q))
    assert main([str(bad), "--out", str(tmp_path / "o2")]) == 3                       # malformed CSV: rejected up front
    assert main([str(tmp_path / "nonexistent.json")]) == 3
    # a *scientifically* unusable dataset (loads fine, cannot be fitted) -> workflow completes, exit 2, step marked failed
    short = tmp_path / "camp" / "thermal.csv"
    short.write_text("t_s,power_w,eclipse,T_k\n" + "\n".join(f"{i * 30},40,0,{290 + 0.01 * i}" for i in range(12)) + "\n")
    (tmp_path / "camp" / "mbu.csv").write_text("cluster_size,count\n1,500\n2,100\n3,40\n")
    q = copy.deepcopy(p); q["options"]["n_boot"] = 20; q["options"]["n_draws"] = 10; bad.write_text(json.dumps(q))
    assert main([str(bad), "--out", str(tmp_path / "o3")]) == 2
    rep = json.loads((tmp_path / "o3" / "calibration_report.json").read_text())
    assert [s["name"] for s in rep["steps"] if s["status"] == "failed"] == ["thermal model"]


def test_module_entry_point_runs():
    r = subprocess.run([sys.executable, "-m", "uchu.calibration", "--help"], cwd=ROOT, capture_output=True, text=True, timeout=60)
    assert r.returncode == 0 and "calibration plan" in r.stdout


def test_load_plan_resolves_relative_paths_and_options(tmp_path):
    plan = write_campaign(tmp_path / "c", TRUTH, START, make_rng(33, "cli"))
    cfg, data, opts = load_plan(plan)
    assert opts.n_boot == 80 and opts.seed == 7 and cfg.config_hash() == START.config_hash()
    assert len(data.beam) == 3 and data.mbu and data.sep and data.power and data.thermal and data.perf and data.flight
    assert set(data.env_tables) == set(TRUTH.radiation.tables) and data.design_facts[0].path == "radiation.gates_per_pe"


# ====================================================================== whole-pipeline statistical validation
@pytest.mark.slow
def test_whole_workflow_interval_coverage_over_independent_campaigns():
    R, inside, total, rate_hits = 10, 0, 0, 0
    tr = _static_rate_per_bit_day(TRUTH, "sram")
    o = CalibrationOptions(seed=1, n_boot=60, n_draws=60)
    for i in range(R):
        rep = run_calibration(START, build(1000 + i, flight=False, avf=False), o)
        assert not any(s.status == "failed" for s in rep.steps), [(s.name, s.error) for s in rep.steps if s.status == "failed"]
        for path, e in rep.config.calibration.items():
            if e["ci95"] is None:
                continue
            total += 1; inside += e["ci95"][0] <= get_by_path(TRUTH, path) <= e["ci95"][1]
        r = rep.rate_summary["sram"]; rate_hits += r["lo"] <= tr <= r["hi"]
    # measured: see docs.  Percentile-bootstrap + Wald intervals at these sample sizes are close to, but not exactly, nominal.
    assert inside / total >= 0.85, (inside, total)
    assert rate_hits / R >= 0.7
