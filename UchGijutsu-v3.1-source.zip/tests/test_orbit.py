import math

import numpy as np
import pytest

from uchu import SimConfig, make_rng
from uchu.config import OrbitalConfig, OrbitType, SolarActivity
from uchu.orbit import (FlareSchedule, OrbitalEnvironment, SEP_EVENTS_PER_YEAR, eclipse_fraction,
                        kepler_period_s)


def test_kepler_periods():
    assert kepler_period_s(400) == pytest.approx(5554, rel=2e-3)
    assert kepler_period_s(35786) == pytest.approx(86164, rel=2e-3)     # sidereal day


def test_eclipse_fraction_known_values():
    assert eclipse_fraction(400, 0.0) == pytest.approx(0.39, abs=0.01)
    assert eclipse_fraction(35786, 0.0) == pytest.approx(0.048, abs=0.003)
    assert eclipse_fraction(550, 80.0) == 0.0         # high beta: no eclipse


def test_deep_space_never_eclipsed():
    o = OrbitalEnvironment(OrbitalConfig.for_orbit(OrbitType.DEEP))
    assert o.eclipse_segments(0, 1e6) == [(0, 1e6, False)]


@pytest.mark.parametrize("t0,t1", [(0.0, 1.0), (100.0, 20000.0), (5000.3, 5001.7), (0.0, 100000.0)])
def test_eclipse_segments_partition_interval_exactly(t0, t1):
    o = OrbitalEnvironment(OrbitalConfig())
    segs = o.eclipse_segments(t0, t1)
    assert segs[0][0] == t0 and segs[-1][1] == t1
    for (a, b, _), (c, d, _) in zip(segs, segs[1:]):
        assert b == c
    for a, b, e in segs:
        assert b > a
        mid = 0.5 * (a + b)
        assert o.in_eclipse(mid) == e
    total_ecl = sum(b - a for a, b, e in segs if e)
    assert total_ecl == pytest.approx(o.eclipse_fraction * (t1 - t0), abs=o.period_s * o.eclipse_fraction)


def test_eclipse_time_over_many_orbits_matches_fraction():
    o = OrbitalEnvironment(OrbitalConfig())
    n = 50
    segs = o.eclipse_segments(0.0, n * o.period_s)
    assert sum(b - a for a, b, e in segs if e) == pytest.approx(n * o.period_s * o.eclipse_fraction, rel=1e-9)


def test_flare_integral_exact_and_additive():
    s = FlareSchedule.from_events([(100.0, 200.0, 2.0), (150.0, 400.0, 1.0)])
    assert s.intensity_integral(0, 1000) == pytest.approx(100 * 2 + 250 * 1)
    assert s.intensity_integral(120, 180) == pytest.approx(60 * 2 + 30 * 1)
    a = s.intensity_integral(0, 170) + s.intensity_integral(170, 1000)
    assert a == pytest.approx(s.intensity_integral(0, 1000))
    assert s.intensity_at(160) == 3.0 and s.intensity_at(250) == 1.0 and s.intensity_at(500) == 0.0


def test_flare_integral_matches_brute_force():
    s = FlareSchedule.from_events([(10.0, 55.5, 1.7), (40.0, 90.0, 0.4)])
    t = np.linspace(0, 100, 200001)
    brute = sum(s.intensity_at(x) for x in t[::200]) * (t[200] - t[0])
    assert s.intensity_integral(0, 100) == pytest.approx(brute, rel=0.02)


def test_schedule_prefix_independent_of_query_order():
    a = FlareSchedule(1 / 1e5, make_rng(3, "f")); b = FlareSchedule(1 / 1e5, make_rng(3, "f"))
    a.intensity_integral(0, 5e6)
    for t in np.linspace(0, 5e6, 25):
        b.intensity_integral(0, t)
    n = min(len(a.events), len(b.events))
    assert n > 10 and a.events[:n] == b.events[:n]


def test_flare_arrival_rate_statistics():
    rate = SEP_EVENTS_PER_YEAR[SolarActivity.HIGH] / (365.25 * 86400)
    counts = []
    for i in range(200):
        s = FlareSchedule(rate, make_rng(i, "f"))
        s.extend_to(10 * 365.25 * 86400)
        counts.append(sum(1 for e in s.events if e[0] <= 10 * 365.25 * 86400))
    assert np.mean(counts) == pytest.approx(80.0, rel=0.05)
    assert np.var(counts) == pytest.approx(80.0, rel=0.3)        # Poisson: var == mean


def test_flare_intensity_is_lognormal_median_one():
    s = FlareSchedule(1e-3, make_rng(1, "g")); s.extend_to(5e6)
    inten = np.array([e[2] for e in s.events])
    assert np.median(inten) == pytest.approx(1.0, rel=0.1)
