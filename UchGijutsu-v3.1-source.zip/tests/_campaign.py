"""Shared builder for synthetic calibration campaigns (hidden truth -> measurements)."""
from uchu import make_rng
from uchu.calibration import CalibrationData
from uchu.calibration.data import AvfRequest, DesignFact
from uchu.calibration.synthetic import (gen_beam, gen_flight, gen_mbu, gen_perf, gen_power, gen_sep_catalog, gen_thermal,
                                        analyst_start_config, make_truth_config)

ION_X = [1.5, 2.2, 3.3, 5.0, 7.5, 11.0, 17.0, 26.0, 40.0, 60.0, 85.0]
PRO_X = [12., 18., 25., 35., 50., 70., 100., 150., 200.]
TRUTH = make_truth_config()
START = analyst_start_config(TRUTH)


def build(seed, truth=TRUTH, start=START, *, flight=True, hardware=True, mbu=True, sep=True, register=True, avf=True,
          n_mbu=600, sep_years=25.0, flight_years=2.0):
    rng = make_rng(seed, "e2e")
    d = CalibrationData(env_tables=truth.radiation.tables, env_source="synthetic CREME tables")
    d.beam = [gen_beam(truth.radiation.sram.ion, "sram", "ion", "sram_ion", rng, 1e8, ION_X),
              gen_beam(truth.radiation.sram.proton, "sram", "proton", "sram_proton", rng, 1e8, PRO_X)]
    if register:
        d.beam.append(gen_beam(truth.radiation.register.ion, "register", "ion", "reg_ion", rng, 1.2e7, ION_X))
    if mbu:
        d.mbu = gen_mbu(truth, n_mbu, rng)
    if sep:
        d.sep = gen_sep_catalog(truth, sep_years, rng)
    if hardware:
        d.power, d.thermal, d.perf = gen_power(truth, rng), gen_thermal(truth, rng), gen_perf(truth, start, rng)
    if flight:
        d.flight = [gen_flight(truth, "sram", 5.4e8, flight_years, rng)]
    if avf:
        d.avf = [AvfRequest("avf_sram", "int8", 1e-2, 40)]
    d.design_facts = [DesignFact("radiation.gates_per_pe", 1800, "synthetic netlist")]
    return d
