import math

import numpy as np
import pytest

from uchu import LumpedThermalModel, PowerModel, SimConfig
from uchu.config import ProcessNode
from uchu.thermal import SIGMA_SB


def test_reference_power_at_nominal_equals_base_power():
    c = SimConfig().validate()
    pm = PowerModel(c)
    assert pm.power_w(300.0, 1.5, 0.9, 1.0) == pytest.approx(50.0)


def test_leakage_monotone_in_temperature():
    pm = PowerModel(SimConfig())
    p = [pm.breakdown(T, 1.5, 0.9)["leakage"] for T in (250, 300, 350, 400)]
    assert all(b > a for a, b in zip(p, p[1:]))


def test_dynamic_power_scales_with_f_and_v_squared():
    pm = PowerModel(SimConfig())
    a = pm.breakdown(300, 1.5, 0.9)
    b = pm.breakdown(300, 0.75, 0.9 * 0.5)
    for k in ("clock", "logic", "interconnect"):
        assert b[k] == pytest.approx(a[k] * 0.5 * 0.25)


def test_node_leakage_only_touches_static_power():
    c7, c3 = SimConfig(), SimConfig()
    c3.compute.process_node = ProcessNode.N3
    c3.dvfs.nom_voltage_v = 0.8
    c3.dvfs.nom_freq_ghz = 1.5
    a, b = PowerModel(c7), PowerModel(c3)
    assert b.static_nom_w == pytest.approx(a.static_nom_w * 3.5 / 2.1)
    assert b.dynamic_nom_w == pytest.approx(a.dynamic_nom_w * 0.72)   # cap factor, not leakage


def test_static_scales_with_area_dynamic_with_macs():
    a, b = SimConfig(), SimConfig()
    b.compute.area_mm2 = 800.0
    b.compute.array_size = 512
    pa, pb = PowerModel(a), PowerModel(b)
    assert pb.static_nom_w == pytest.approx(2 * pa.static_nom_w)
    assert pb.dynamic_nom_w == pytest.approx(4 * pa.dynamic_nom_w)


def test_dvfs_throttle_curve_smooth_and_monotone():
    pm = PowerModel(SimConfig())
    f = [pm.dvfs_state(T).freq_ghz for T in np.linspace(300, 420, 41)]
    assert f[0] == pytest.approx(1.5)
    assert all(b <= a + 1e-12 for a, b in zip(f, f[1:]))
    assert pm.dvfs_state(300).throttled is False and pm.dvfs_state(400).throttled is True
    assert min(f) >= 0.1 * 1.5 - 1e-12


def test_steady_state_matches_closed_form_for_constant_power():
    c = SimConfig()
    th = LumpedThermalModel(c)
    P = 80.0
    T = th.steady_state(lambda T: P, eclipse=True)
    k = c.thermal.emissivity * SIGMA_SB * c.thermal.view_factor * c.thermal.radiator_area_m2
    assert T == pytest.approx(((P + th.env_load_w(True)) / k) ** 0.25, rel=1e-9)


def test_time_integration_converges_to_steady_state():
    c = SimConfig()
    th = LumpedThermalModel(c)
    th.T = 200.0
    T_ss = th.steady_state(lambda T: 60.0, True)
    for _ in range(2000):                      # 60 000 s ~ 90 thermal time constants
        th.step(30.0, lambda T: 60.0, True)
    assert th.T == pytest.approx(T_ss, rel=1e-9)   # the BE fixed point IS the steady state


def _integrate(dt, t_end=300.0, T0=200.0):
    th = LumpedThermalModel(SimConfig()); th.T = T0
    for _ in range(int(round(t_end / dt))):
        th.step(dt, lambda T: 70.0, False)
    return th.T


def test_first_order_convergence_in_dt():
    ref = _integrate(0.05)
    e = [abs(_integrate(dt) - ref) for dt in (60.0, 30.0, 15.0)]
    assert e[0] > e[1] > e[2]
    assert 1.5 < e[0] / e[1] < 2.6 and 1.5 < e[1] / e[2] < 2.6     # backward Euler: O(dt)


def test_unconditionally_stable_with_huge_step():
    th = LumpedThermalModel(SimConfig()); th.T = 200.0
    T_ss = th.steady_state(lambda T: 60.0, False)
    th.step(1e7, lambda T: 60.0, False)
    # one finite BE step leaves a residual ~ C (T-T0) / (dt h') ~ 5e-3 K; it must be finite and tiny
    assert math.isfinite(th.T) and abs(th.T - T_ss) < 0.02


def test_energy_balance_closes_per_step():
    c = SimConfig(); th = LumpedThermalModel(c); th.T = 250.0
    pm = PowerModel(c)
    pf = lambda T: pm.power_w(T, 1.5, 0.9, 1.0)
    for dt in (0.01, 1.0, 20.0, 400.0):
        T0 = th.T
        T1 = th.step(dt, pf, False)
        stored = c.thermal.capacitance_j_per_k * (T1 - T0)
        net = (pf(T1) + th.env_load_w(False) - th.radiated_w(T1)) * dt      # implicit-Euler end-point rule
        assert stored == pytest.approx(net, rel=1e-7, abs=1e-7)


def test_sunlit_hotter_than_eclipse():
    c = SimConfig(); th = LumpedThermalModel(c)
    pf = lambda T: 60.0
    assert th.steady_state(pf, False) > th.steady_state(pf, True)


def test_cooling_direction_and_bounds():
    th = LumpedThermalModel(SimConfig()); th.T = 600.0
    th.step(100.0, lambda T: 10.0, True)
    assert 3.0 < th.T < 600.0


def test_thermal_runaway_detected():
    c = SimConfig()
    c.power.leak_temp_coeff = 12.0
    c.thermal.radiator_area_m2 = 0.02
    pm = PowerModel(c); th = LumpedThermalModel(c)
    th.T = 380.0
    for _ in range(50):
        th.step(60.0, lambda T: pm.power_w(T, 1.5, 0.9, 1.0), False)
        if th.runaway:
            break
    assert th.runaway
    assert pm  # keep linter quiet


def test_view_factor_degrades_with_mission_year():
    c = SimConfig(); c.thermal.mission_year = 10.0
    a, b = LumpedThermalModel(SimConfig()), LumpedThermalModel(c)
    assert b.radiated_w(300.0) < a.radiated_w(300.0)
    assert b.effective_view_factor == pytest.approx(0.85 * 0.8)


def test_default_design_is_thermally_feasible():
    c = SimConfig(); pm = PowerModel(c); th = LumpedThermalModel(c)
    T = th.steady_state(lambda T: pm.power_w(T, 1.5, 0.9, 1.0), False)
    assert T is not None and T < c.dvfs.throttle_onset_k
