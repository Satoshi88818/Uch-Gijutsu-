import random

import numpy as np
import pytest

from uchu import (ChipSimulator, SimConfig, build_transformer_workload, profile_pass, run_ensemble,
                  run_mission, run_workload)
from uchu.config import OrbitalConfig, OrbitType, SolarActivity
from uchu.orbit import FlareSchedule

LAYERS = build_transformer_workload(num_layers=2)


def hot_cfg(factor=1e8, **over):
    """Cross-sections inflated so rare events become countable in short, fast tests."""
    c = SimConfig()
    for reg in (c.radiation.sram, c.radiation.register, c.radiation.logic_set):
        reg.ion.sigma_sat_cm2 *= factor
        reg.proton.sigma_sat_cm2 *= factor
    c.radiation.scrub_interval_s = 1.0
    for k, v in over.items():
        setattr(c, k, v)
    return c.validate()


# ---------------------------------------------------------------- single clock & determinism
def test_run_does_not_touch_global_rngs():
    np.random.seed(1); random.seed(1)
    n0, p0 = np.random.get_state()[1].copy(), random.getstate()
    run_workload(hot_cfg(), LAYERS, n_passes=20)
    run_mission(hot_cfg(), LAYERS, 300.0)
    assert np.array_equal(n0, np.random.get_state()[1]) and p0 == random.getstate()


def test_mission_clock_is_exact_and_energy_is_consistent():
    r = run_mission(SimConfig(), LAYERS, 12345.6)
    assert r.simulated_s == pytest.approx(12345.6, abs=1e-6) and r.completed
    assert r.energy_j == pytest.approx(r.avg_power_w * r.simulated_s)
    assert 5.0 < r.avg_power_w < 120.0


def test_workload_elapsed_equals_sum_of_pass_durations_when_unthrottled():
    c = SimConfig()
    r = run_workload(c, LAYERS, n_passes=50)
    prof = profile_pass(LAYERS, c, c.dvfs.nom_freq_ghz)
    assert r.elapsed_s == pytest.approx(50 * prof.duration_s, rel=1e-12)
    assert r.dense_flops == pytest.approx(50 * prof.dense_flops)
    assert len(r.first_pass_layers) == len(LAYERS)
    assert r.avg_tflops_dense <= 2 * 256 * 256 * 1.5e9 / 1e12 * 1.0001 * 1.85


def test_same_seed_identical_different_seed_differs():
    a = run_mission(hot_cfg(), LAYERS, 400.0, seed=5)
    b = run_mission(hot_cfg(), LAYERS, 400.0, seed=5)
    c = run_mission(hot_cfg(), LAYERS, 400.0, seed=6)
    assert a.radiation == b.radiation and a.energy_j == b.energy_j
    assert a.radiation != c.radiation
    assert a.radiation.n_seu_sram > 1000                 # hot config really produces events


def test_provenance_attached():
    r = run_workload(SimConfig(), LAYERS, n_passes=2)
    assert r.provenance["config_hash"] == SimConfig().config_hash() and r.provenance["model_version"] == "3.0.0"


# ---------------------------------------------------------------- thermal / orbit coupling
def test_eclipse_cycles_drive_temperature_swings():
    c = SimConfig(); c.thermal.capacitance_j_per_k = 50.0           # fast enough to follow the eclipse
    r = run_mission(c, LAYERS, 3 * 5739.0, duty=1.0, dt_max_s=10.0, record_every_s=20.0)
    T, ecl = r.series["T"], r.series["eclipse"]
    assert ecl.any() and (~ecl).any()
    assert T[~ecl].mean() > T[ecl].mean() + 3.0
    assert r.T_max_k - r.T_min_k > 5.0
    assert 0.3 < ecl.mean() < 0.45                                   # ~37 % of samples in shadow


def test_deep_space_has_no_eclipse_swing():
    c = SimConfig(); c.orbital = OrbitalConfig.for_orbit(OrbitType.DEEP); c.thermal.capacitance_j_per_k = 50.0
    r = run_mission(c, LAYERS, 6000.0, record_every_s=20.0)
    assert not r.series["eclipse"].any()
    assert np.ptp(r.series["T"][len(r.series["T"]) // 2:]) < 0.5      # settled


def test_throttling_feedback_limits_temperature_and_throughput():
    big, small = SimConfig(), SimConfig()
    small.thermal.radiator_area_m2 = 0.06
    a = run_mission(big, LAYERS, 8000.0, dt_max_s=20.0)
    b = run_mission(small, LAYERS, 8000.0, dt_max_s=20.0)
    assert a.throttled_fraction == 0.0 and b.throttled_fraction > 0.5
    assert b.avg_tflops_dense < 0.95 * a.avg_tflops_dense
    assert b.T_max_k < small.power.T_max_k + 5.0 and not b.failed


def test_thermal_runaway_reported_not_hidden():
    c = SimConfig(); c.power.leak_temp_coeff = 12.0; c.thermal.radiator_area_m2 = 0.02; c.thermal.T_init_k = 380.0
    r = run_mission(c, LAYERS, 20000.0, dt_max_s=30.0)
    assert r.failed and r.fail_reason == "thermal_runaway" and not r.completed and r.simulated_s < 20000.0


def test_duty_cycle_reduces_power_and_work_but_not_exposure():
    full = run_mission(SimConfig(), LAYERS, 2000.0, duty=1.0)
    idle = run_mission(SimConfig(), LAYERS, 2000.0, duty=0.0)
    assert idle.dense_flops == 0.0 and idle.avg_power_w < full.avg_power_w
    with pytest.raises(ValueError):
        run_mission(SimConfig(), LAYERS, 10.0, duty=1.5)


# ---------------------------------------------------------------- radiation coupled to the clock
def test_flare_raises_observed_upset_rate_by_predicted_factor():
    c = hot_cfg(1e8)
    sim = ChipSimulator(c, seed=3)
    sim.orbit.flares = FlareSchedule.from_events([(1000.0, 2000.0, 10.0)])
    prof = profile_pass(LAYERS, c, 1.5)
    counts, t_mark = [], 0
    for t_end in (1000.0, 2000.0, 3000.0):
        before = sim.rad.ledger.n_seu_sram
        while sim.t < t_end - 1e-9:
            sim.advance(min(10.0, t_end - sim.t), prof.util, prof.live_sram_bits, sim.dvfs())
        counts.append(sim.rad.ledger.n_seu_sram - before)
    st, sep = sim.env.static_rate["sram"], sim.env.sep_coeff["sram"]
    pred = (st + 10.0 * sep) / st
    obs = counts[1] / counts[0]
    assert counts[0] > 1000 and obs == pytest.approx(pred, rel=0.1)
    assert counts[2] == pytest.approx(counts[0], rel=0.15)           # back to baseline afterwards


def test_observed_seu_count_matches_expected_value():
    c = hot_cfg(1e8)
    r = run_mission(c, LAYERS, 600.0, seed=9)
    sim = ChipSimulator(c, seed=9)
    prof = profile_pass(LAYERS, c, 1.5)
    exp = sim.env.expected("sram", prof.live_sram_bits, 0.0, 600.0)
    assert exp > 1000
    assert abs(r.radiation.n_seu_sram - exp) < 5 * exp ** 0.5     # within 5 Poisson sigma


def test_tmr_and_ecc_reduce_silent_corruption_end_to_end():
    base = run_mission(hot_cfg(), LAYERS, 600.0, seed=2).radiation
    c = hot_cfg(); c.radiation.tmr_enabled = True
    tmr = run_mission(c, LAYERS, 600.0, seed=2).radiation
    assert base.sdc_register > 100 and tmr.sdc_register < 0.01 * base.sdc_register
    assert tmr.sdc_logic <= base.sdc_logic
    c2 = hot_cfg(); c2.memory.ecc_enabled = False
    noecc = run_mission(c2, LAYERS, 600.0, seed=2).radiation
    assert noecc.sdc_sram > 20 * max(base.sdc_sram, 1)
    assert base.words_corrected > 0


def test_scrub_interval_controls_double_errors_end_to_end():
    def due(scrub):
        c = hot_cfg(3e10); c.radiation.scrub_interval_s = scrub; c.radiation.mbu_prob = 0.0
        return run_mission(c, LAYERS, 240.0, dt_max_s=20.0, seed=4).radiation.words_due
    fast, slow = due(1.0), due(8.0)
    assert fast > 1000
    assert 5.0 < slow / fast < 11.0              # DUE ~ lambda^2 * tau  => ratio ~ 8 for an 8x longer interval


def test_destructive_latchup_stops_the_mission():
    c = hot_cfg(); c.radiation.sel_protected = False
    c.radiation.sel.ion.sigma_sat_cm2 = 1e5                # absurdly latch-up prone
    r = run_mission(c, LAYERS, 5000.0, seed=1)
    assert r.failed and r.fail_reason == "single_event_latchup_destructive" and r.simulated_s < 5000.0


def test_protected_latchup_costs_availability_not_the_mission():
    c = hot_cfg(); c.radiation.sel.ion.sigma_sat_cm2 = 1e3
    r = run_mission(c, LAYERS, 3000.0, seed=1)
    assert not r.failed and r.radiation.n_sel > 0
    assert r.availability < 1.0 and r.radiation.downtime_s == pytest.approx(5.0 * r.radiation.n_sel)


def test_geo_flare_scenario_sees_flare_events_in_year_scale_schedule():
    c = SimConfig(); c.orbital = OrbitalConfig.for_orbit(OrbitType.GEO, solar_activity=SolarActivity.HIGH)
    sim = ChipSimulator(c, seed=1)
    sim.orbit.flares.extend_to(365.25 * 86400.0)
    assert 2 <= len(sim.orbit.flares.events) <= 25


# ---------------------------------------------------------------- ensemble
@pytest.mark.slow
def test_ensemble_parallel_equals_serial_and_ci_is_sane():
    c = hot_cfg()
    ser = run_ensemble(c, LAYERS, 4, 150.0, dt_max_s=10.0, n_jobs=1, base_seed=11)
    par = run_ensemble(c, LAYERS, 4, 150.0, dt_max_s=10.0, n_jobs=2, base_seed=11)
    assert ser.total_sdc == par.total_sdc and ser.total_due == par.total_due
    assert np.array_equal(ser.per_sample_sdc_per_hr, par.per_sample_sdc_per_hr)
    lo, hi = ser.sdc_per_hr_ci
    assert lo <= ser.sdc_per_hr <= hi and ser.n_failed == 0 and ser.total_sdc > 0
    other = run_ensemble(c, LAYERS, 4, 150.0, dt_max_s=10.0, base_seed=12)
    assert other.total_sdc != ser.total_sdc


@pytest.mark.slow
def test_ensemble_samples_solar_scenarios():
    w = {SolarActivity.LOW: 0.5, SolarActivity.HIGH: 0.5}
    r = run_ensemble(hot_cfg(), LAYERS, 6, 100.0, base_seed=3, solar_weights=w)
    assert r.n_samples == 6 and r.total_hours == pytest.approx(6 * 100.0 / 3600.0)


@pytest.mark.slow
def test_one_simulated_day_completes_with_realistic_rates():
    c = SimConfig(); c.radiation.scrub_interval_s = 10.0
    r = run_mission(c, LAYERS, 86400.0, dt_max_s=30.0, record_every_s=600.0)
    assert r.completed and r.simulated_s == pytest.approx(86400.0)
    assert r.radiation.n_seu_sram >= 0 and r.availability == 1.0
    assert r.series["T"].size > 100
