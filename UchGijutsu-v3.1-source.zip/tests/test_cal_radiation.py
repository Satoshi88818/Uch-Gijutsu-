import math

import numpy as np
import pytest
from scipy import stats

from uchu import RadiationSubsystem, SimConfig, make_rng
from uchu.calibration import fit_radiation as FR
from uchu.calibration.data import (BeamDataset, BeamPoint, CalibrationDataError, MbuDataset, SepCatalog)
from uchu.calibration.fit_radiation import (_cluster_pmf, _deviance, _mu, _nll, apply_cross_section_fit, apply_mbu_fit,
                                            apply_sep_fit, calibrate_avf, check_table_coverage, cross_section_upper_limit,
                                            expected_events_for_flight, fit_cross_section, fit_mbu,
                                            fit_power_law_to_table, fit_sep_statistics, flight_update,
                                            gamma_scale_posterior, install_environment_tables, weighted_quantile)
from uchu.calibration.registry import placeholder_audit
from uchu.calibration.synthetic import gen_beam
from uchu.config import CrossSection, SpectrumTable
from uchu.orbit import FlareSchedule, OrbitalEnvironment
from uchu.radiation import RadiationEnvironment, TruncatedPowerLaw, integral_rate

TRUTH = CrossSection(3.2e-14, 1.2, 14.0, 1.7)
ION_X = [1.5, 2.2, 3.3, 5.0, 7.5, 11.0, 17.0, 26.0, 40.0, 60.0, 85.0]
LAW = TruncatedPowerLaw(2e-3, 1.0, 1.6, 150.0)


def beam(seed=1, truth=TRUTH, **kw):
    return gen_beam(truth, "sram", "ion", "d", make_rng(seed, "d"), kw.pop("n_units", 1e8), kw.pop("x", ION_X), **kw)


def rate(cs):
    return integral_rate(cs, LAW, 1e-2, extra_nodes=[cs.x_th])


# ====================================================================== likelihood pieces
def test_deviance_matches_scipy_poisson_definition():
    rng = make_rng(0, "dev")
    mu = rng.uniform(0.5, 50, 12); k = rng.poisson(mu).astype(float)
    ref = 2 * np.sum(stats.poisson.logpmf(k, np.maximum(k, 1e-300)) - stats.poisson.logpmf(k, mu))
    assert _deviance(mu, k) == pytest.approx(ref, rel=1e-9)
    assert _deviance(k + 1e-12, k) == pytest.approx(0.0, abs=1e-6)         # saturated model
    assert _deviance(np.array([2.0]), np.array([0.0])) == pytest.approx(4.0)   # k=0: 2*mu


def test_weibull_mu_matches_config_cross_section():
    x = np.array([0.5, 1.2, 5.0, 40.0]); nF = np.array([1e8, 2e8, 1e9, 3e9])
    th = np.array([TRUTH.sigma_sat_cm2, TRUTH.x_th, TRUTH.width, TRUTH.shape])
    assert _mu(th, x, nF) == pytest.approx(TRUTH(x) * nF, rel=1e-12)


# ====================================================================== cross-section fit
def test_recovers_parameters_when_counts_are_abundant():
    ds = beam(target_events=2e5, f_max=1e13, f_min=1e5)
    f = fit_cross_section(ds, make_rng(2, "f"), n_boot=20)
    for k, v in (("sigma_sat_cm2", TRUTH.sigma_sat_cm2), ("x_th", TRUTH.x_th), ("width", TRUTH.width), ("shape", TRUTH.shape)):
        assert f.params[k] == pytest.approx(v, rel=0.03), k
    assert f.p_value > 0.01 and not f.overdispersed


def test_mle_is_at_least_as_likely_as_the_truth_and_deterministic():
    for seed in range(8):
        ds = beam(seed)
        f = fit_cross_section(ds, make_rng(5, "f"), n_boot=10)
        x = np.array([p.x for p in ds.points]); nF = np.array([p.n_units * p.fluence_cm2 for p in ds.points])
        k = np.array([p.events for p in ds.points], float)
        th_t = np.array([TRUTH.sigma_sat_cm2, TRUTH.x_th, TRUTH.width, TRUTH.shape])
        th_h = np.array([f.params[p] for p in ("sigma_sat_cm2", "x_th", "width", "shape")])
        assert _nll(_mu(th_h, x, nF), k) <= _nll(_mu(th_t, x, nF), k) + 1e-6
    a = fit_cross_section(beam(3), make_rng(9, "f"), n_boot=15)
    b = fit_cross_section(beam(3), make_rng(9, "f"), n_boot=15)
    assert a.params == b.params and np.array_equal(a.samples, b.samples)


def test_predicted_rate_is_better_constrained_than_individual_parameters():
    f = fit_cross_section(beam(11), make_rng(2, "f"), n_boot=80)
    rs = np.array([rate(f.draw(i)) for i in range(len(f.samples))])
    rel_rate = (np.percentile(rs, 97.5) - np.percentile(rs, 2.5)) / np.median(rs)
    lo, hi = f.ci95["x_th"]
    assert rel_rate < 1.0 and (hi / lo) > 3.0            # x_th spans a big factor, the rate does not
    assert np.percentile(rs, 2.5) <= rate(TRUTH) <= np.percentile(rs, 97.5)


def test_fixed_shape_is_honoured_and_recorded_as_derived():
    c = SimConfig()
    f = fit_cross_section(beam(4), make_rng(2, "f"), n_boot=15, fix={"shape": 2.0})
    assert f.params["shape"] == 2.0 and f.ci95["shape"] == (2.0, 2.0) and np.all(f.samples[:, 3] == 2.0)
    apply_cross_section_fit(c, f)
    assert c.calibration["radiation.sram.ion.shape"]["status"] == "derived"
    assert c.calibration["radiation.sram.ion.sigma_sat_cm2"]["status"] == "measured"


def test_apply_updates_config_ledger_and_audit():
    c = SimConfig(); f = fit_cross_section(beam(4), make_rng(2, "f"), n_boot=15)
    apply_cross_section_fit(c, f, source="beam run 2025-03")
    assert c.radiation.sram.ion.sigma_sat_cm2 == f.params["sigma_sat_cm2"]
    e = c.calibration["radiation.sram.ion.width"]
    assert e["source"] == "beam run 2025-03" and e["ci95"][0] <= f.params["width"] <= e["ci95"][1]
    a = placeholder_audit(c)
    assert all(f"radiation.sram.ion.{p}" in a.resolved for p in ("sigma_sat_cm2", "x_th", "width", "shape"))
    assert "radiation.sram.proton.x_th" in a.unresolved


def test_insufficient_or_empty_data_is_refused_with_an_upper_limit():
    pts = tuple(BeamPoint(x, 1e7, 0, 1e6) for x in ION_X)
    with pytest.raises(CalibrationDataError, match="upper limit"):
        fit_cross_section(BeamDataset("z", "sram", "ion", pts), make_rng(0, "f"))
    with pytest.raises(CalibrationDataError, match=">= 4"):
        fit_cross_section(BeamDataset("z", "sram", "ion", pts[:3]), make_rng(0, "f"))
    assert cross_section_upper_limit(0, 1e7, 1e6) == pytest.approx(2.9957 / 1e13, rel=1e-3)
    assert cross_section_upper_limit(5, 1e7, 1e6) > cross_section_upper_limit(0, 1e7, 1e6)


def test_overdispersion_is_detected_and_intervals_widen():
    rng = make_rng(8, "od")
    pts_p, pts_o = [], []
    for x in ION_X:
        sig = float(TRUTH(x)); nF = 1e8 * 3e7
        mu = sig * nF
        pts_p.append(BeamPoint(x, 3e7, int(rng.poisson(mu)), 1e8))
        pts_o.append(BeamPoint(x, 3e7, int(rng.poisson(mu * rng.lognormal(0, 0.6))), 1e8))     # 60 % fluence/dosimetry scatter
    fp = fit_cross_section(BeamDataset("p", "sram", "ion", tuple(pts_p)), make_rng(1, "f"), n_boot=60)
    fo = fit_cross_section(BeamDataset("o", "sram", "ion", tuple(pts_o)), make_rng(1, "f"), n_boot=60)
    assert not fp.overdispersed and fo.overdispersed and fo.p_value < 0.05 and fo.dispersion > 2.0
    assert any("over-dispersed" in w for w in fo.warnings)
    wp = np.percentile(fp.samples[:, 0], 97.5) / np.percentile(fp.samples[:, 0], 2.5)
    wo = np.percentile(fo.samples[:, 0], 97.5) / np.percentile(fo.samples[:, 0], 2.5)
    assert wo > 1.3 * wp


def test_warns_when_saturation_is_not_reached_and_when_underdetermined():
    f = fit_cross_section(beam(3, x=[1.5, 2.2, 3.3, 5.0, 7.5, 11.0, 17.0], n_units=1e9), make_rng(2, "f"), n_boot=30)
    assert any("saturation not reached" in w for w in f.warnings)
    full = fit_cross_section(beam(3), make_rng(2, "f"), n_boot=30)             # data extend to 85 MeV cm2/mg
    assert not any("saturation not reached" in w for w in full.warnings)
    pts = tuple(BeamPoint(x, 1e7, int(c), 1e8) for x, c in zip((10, 10, 40, 40), (5, 6, 30, 28)))
    f2 = fit_cross_section(BeamDataset("u", "sram", "ion", tuple(pts)), make_rng(2, "f"), n_boot=30)
    assert any("distinct x values" in w for w in f2.warnings)


# ---- statistical validity of the intervals and of the goodness-of-fit p-value
@pytest.mark.slow
def test_bootstrap_interval_coverage_and_gof_calibration():
    R, hit_rate, hit_sig, ps = 30, 0, 0, []
    rt = rate(TRUTH)
    for i in range(R):
        f = fit_cross_section(beam(100 + i), make_rng(200 + i, "f"), n_boot=50)
        rs = np.array([rate(f.draw(j)) for j in range(len(f.samples))])
        hit_rate += np.percentile(rs, 2.5) <= rt <= np.percentile(rs, 97.5)
        lo, hi = f.ci95["sigma_sat_cm2"]; hit_sig += lo <= TRUTH.sigma_sat_cm2 <= hi
        ps.append(f.p_value)
    ps = np.array(ps)
    # measured on 40 repeats: rate 0.93, sigma_sat 0.88 (percentile bootstrap undercovers slightly), p-values ~ uniform
    assert hit_rate / R >= 0.80 and hit_sig / R >= 0.75
    assert 0.3 < ps.mean() < 0.7 and (ps < 0.05).mean() <= 0.2


# ====================================================================== MBU
def test_cluster_pmf_is_a_distribution_and_matches_the_simulator():
    for q, M in ((0.45, 5), (0.2, 8), (0.9, 3), (1.0, 4)):
        pmf = _cluster_pmf(q, M); assert pmf.sum() == pytest.approx(1.0) and np.all(pmf >= 0)
    c = SimConfig(); c.radiation.mbu_cluster_geom_p, c.radiation.mbu_max_cluster = 0.45, 5
    sizes = RadiationSubsystem(c.validate(), None, make_rng(3, "m"))._cluster_sizes(400_000)
    emp = np.bincount(sizes, minlength=6)[2:] / len(sizes)
    assert emp == pytest.approx(_cluster_pmf(0.45, 5), abs=0.004)              # fit model == simulator model


def _mbu_counts(rng, N, p, q, M):
    pmf = np.concatenate([[1 - p], p * _cluster_pmf(q, M)])
    s = rng.choice(np.arange(1, M + 1), size=N, p=pmf)
    return {int(m): int((s == m).sum()) for m in range(1, M + 1)}


def test_mbu_fit_recovers_parameters_and_passes_gof():
    ds = MbuDataset("m", _mbu_counts(make_rng(1, "m"), 50_000, 0.18, 0.45, 5))
    f = fit_mbu(ds, make_rng(2, "f"), max_cluster=5)
    assert f.p_mbu == pytest.approx(0.18, abs=0.006) and f.geom_p == pytest.approx(0.45, abs=0.02)
    assert f.p_mbu_ci95[0] < 0.18 < f.p_mbu_ci95[1] and f.geom_p_ci95[0] < 0.45 < f.geom_p_ci95[1]
    assert f.chi2_p_value > 0.01 and f.max_cluster == 5
    assert 0 < f.p_samples.min() and f.q_samples.max() < 1 and len(f.p_samples) == 500


def test_mbu_interval_coverage():
    rng = make_rng(3, "cov"); hp = hq = 0; R = 300
    for _ in range(R):
        f = fit_mbu(MbuDataset("m", _mbu_counts(rng, 800, 0.18, 0.45, 5)), make_rng(0, "f"), max_cluster=5)
        hp += f.p_mbu_ci95[0] <= 0.18 <= f.p_mbu_ci95[1]; hq += f.geom_p_ci95[0] <= 0.45 <= f.geom_p_ci95[1]
    assert hp / R >= 0.92 and hq / R >= 0.90


def test_mbu_refuses_thin_data_and_warns_about_truncation():
    with pytest.raises(CalibrationDataError, match=">= 20"):
        fit_mbu(MbuDataset("m", {1: 10, 2: 3}), make_rng(0, "f"))
    with pytest.raises(CalibrationDataError, match="multi-bit"):
        fit_mbu(MbuDataset("m", {1: 500, 2: 2}), make_rng(0, "f"))
    with pytest.raises(CalibrationDataError, match="max_cluster"):
        fit_mbu(MbuDataset("m", {1: 500, 2: 40, 7: 5}), make_rng(0, "f"), max_cluster=5)
    f = fit_mbu(MbuDataset("m", {1: 800, 2: 120, 3: 40, 4: 20}), make_rng(0, "f"))
    assert any("truncation" in w for w in f.warnings)


def test_apply_mbu_updates_the_simulator_parameters():
    c = SimConfig(); f = fit_mbu(MbuDataset("m", _mbu_counts(make_rng(1, "m"), 5000, 0.2, 0.4, 6)), make_rng(2, "f"))
    apply_mbu_fit(c, f)
    assert (c.radiation.mbu_prob, c.radiation.mbu_cluster_geom_p, c.radiation.mbu_max_cluster) == (f.p_mbu, f.geom_p, f.max_cluster)
    assert c.calibration["radiation.mbu_max_cluster"]["status"] == "derived"
    c.validate()


# ====================================================================== SEP
def _catalog(rng, years, rate, mean_dur, med, sig):
    n = int(rng.poisson(rate * years))
    return SepCatalog("s", years * 365.25 * 86400.0, tuple(rng.exponential(mean_dur, n)),
                      tuple(rng.lognormal(math.log(med), sig, n)))


def test_sep_fit_recovers_parameters():
    cat = _catalog(make_rng(1, "s"), 2000.0, 4.0, 30 * 3600.0, 0.8, 1.3)
    f = fit_sep_statistics(cat, make_rng(2, "f"))
    assert f.rate_per_year == pytest.approx(4.0, rel=0.03) and f.mean_duration_s == pytest.approx(30 * 3600.0, rel=0.03)
    assert f.median_intensity == pytest.approx(0.8, rel=0.03) and f.log_sigma == pytest.approx(1.3, rel=0.03)
    for est, ci in ((f.rate_per_year, f.rate_ci95), (f.mean_duration_s, f.duration_ci95), (f.median_intensity, f.median_ci95), (f.log_sigma, f.log_sigma_ci95)):
        assert ci[0] < est < ci[1]
    assert f.samples.shape == (500, 4) and np.all(f.samples > 0)


def test_sep_interval_coverage():
    rng = make_rng(4, "cov"); hr = hd = hs = 0; R = 300
    for _ in range(R):
        f = fit_sep_statistics(_catalog(rng, 12.0, 4.0, 30 * 3600.0, 0.8, 1.3), make_rng(0, "f"), n_draw=10)
        hr += f.rate_ci95[0] <= 4.0 <= f.rate_ci95[1]; hd += f.duration_ci95[0] <= 30 * 3600.0 <= f.duration_ci95[1]
        hs += f.log_sigma_ci95[0] <= 1.3 <= f.log_sigma_ci95[1]
    assert min(hr, hd, hs) / R >= 0.92


def test_sep_small_catalogues():
    with pytest.raises(CalibrationDataError, match=">= 3"):
        fit_sep_statistics(SepCatalog("s", 1e8, (1.0, 2.0), (1.0, 2.0)), make_rng(0, "f"))
    f = fit_sep_statistics(SepCatalog("s", 3e8, (3600.0, 7200.0, 1800.0, 5400.0), (0.5, 1.5, 0.9, 2.0)), make_rng(0, "f"))
    assert any("only 4 SEP events" in w for w in f.warnings)


def test_apply_sep_drives_the_flare_schedule():
    c = SimConfig(); cat = _catalog(make_rng(1, "s"), 500.0, 6.0, 20 * 3600.0, 1.5, 0.5)
    f = fit_sep_statistics(cat, make_rng(2, "f")); apply_sep_fit(c, f)
    o = OrbitalEnvironment(c.validate().orbital, make_rng(3, "o")); o.flares.extend_to(100 * 365.25 * 86400.0)
    ev = o.flares.events
    assert len(ev) == pytest.approx(100 * f.rate_per_year, rel=0.12)
    assert np.median([e[2] for e in ev]) == pytest.approx(f.median_intensity, rel=0.1)
    assert c.calibration["orbital.sep_events_per_year"]["method"].startswith("Poisson")


# ====================================================================== spectra
def test_power_law_fit_recovers_a_truncated_power_law_table():
    x = np.geomspace(1e-2, 149.0, 300)
    tab = SpectrumTable(x.tolist(), LAW.integral(x).tolist())
    r = fit_power_law_to_table(tab, x_hi=150.0)
    assert r.params.phi_ref == pytest.approx(2e-3, rel=0.01) and r.params.gamma == pytest.approx(1.6, rel=0.01)
    assert r.max_rel_error < 0.01 and not r.warnings
    cs = CrossSection(1e-14, 0.5, 20.0, 1.5)
    law2 = TruncatedPowerLaw(r.params.phi_ref, r.params.x_ref, r.params.gamma, r.params.x_max)
    assert integral_rate(cs, law2, 1e-2, extra_nodes=[0.5]) == pytest.approx(integral_rate(cs, LAW, 1e-2, extra_nodes=[0.5]), rel=0.02)


def test_power_law_fit_warns_when_the_table_is_not_a_power_law():
    x = np.geomspace(0.1, 100, 80)
    phi = np.where(x < 5, 1e-2 * (x / 0.1) ** -0.3, 1e-2 * (50) ** -0.3 * (x / 5) ** -3.0)
    r = fit_power_law_to_table(SpectrumTable(x.tolist(), phi.tolist()))
    assert r.max_rel_error > 0.3 and any("use the table directly" in w for w in r.warnings)
    with pytest.raises(CalibrationDataError):
        fit_power_law_to_table(SpectrumTable([1.0, 2.0, 3.0], [3.0, 2.0, 1.0]))


def test_install_tables_switches_mode_and_records_provenance():
    c = SimConfig(); x = np.geomspace(1e-2, 149.0, 200)
    tabs = {"gcr_ion": SpectrumTable(x.tolist(), LAW.integral(x).tolist())}
    assert install_environment_tables(c, tabs, "CREME96 run A") == []
    assert c.radiation.environment_mode == "tabulated_orbit"
    a = placeholder_audit(c)
    assert {"radiation.environment", "radiation.shield_mm_al", "radiation.shield_atten_len_mm"} <= set(a.resolved)
    assert c.calibration["radiation.shield_mm_al"]["status"] == "absorbed"
    # GCR-only table: the rate equals the analytic GCR integral
    o = OrbitalEnvironment(c.orbital); o.flares = FlareSchedule.from_events([])
    env = RadiationEnvironment(c, o)
    ref = integral_rate(c.radiation.sram.ion, LAW, 1e-2, extra_nodes=[c.radiation.sram.ion.x_th])
    assert env.static_rate["sram"] == pytest.approx(ref, rel=0.03, abs=0)


def test_table_coverage_warning_when_flux_below_threshold_is_missing():
    c = SimConfig()
    late = SpectrumTable([5.0, 10.0, 50.0], [1e-3, 1e-4, 1e-6])
    w = install_environment_tables(c, {"gcr_ion": late}, "late table")
    assert w and "above" in w[0] and "non-conservative" in w[0]
    assert check_table_coverage(c, {"gcr_ion": SpectrumTable([0.01, 10.0], [1e-1, 1e-6])}) == []


# ====================================================================== flight data
def test_flight_update_matches_the_conjugate_gamma_posterior():
    a, E0, k = 6.0, 40.0, 61
    s = make_rng(1, "s").gamma(a, 1.0 / a, 60_000)                    # prior multiplier ~ Gamma(a, rate a), mean 1
    fu = flight_update(E0 * s, k)
    post = stats.gamma(a + k, scale=1.0 / (a + E0))                   # exact posterior (Poisson-Gamma conjugacy)
    assert fu.posterior_multiplier_median == pytest.approx(post.median(), rel=0.02)
    lo, hi = post.ppf([0.025, 0.975])
    assert fu.posterior_multiplier_ci95[0] == pytest.approx(lo, rel=0.05) and fu.posterior_multiplier_ci95[1] == pytest.approx(hi, rel=0.05)
    assert fu.weights.sum() == pytest.approx(1.0) and fu.p_consistency > 0.05


def test_flight_update_flags_inconsistent_data_and_discrepancy_term_helps():
    E = make_rng(2, "E").lognormal(math.log(50.0), 0.15, 400)
    bad = flight_update(E, 500)
    assert bad.p_consistency < 0.01 and any("inconsistent" in w for w in bad.warnings)
    soft = flight_update(E, 500, discrepancy_log_sigma=1.5)
    assert soft.p_consistency > bad.p_consistency and soft.ess > bad.ess
    ok = flight_update(E, 51)
    assert ok.p_consistency > 0.3 and not ok.warnings or ok.ess > 20
    assert flight_update(E, 51, discrepancy_log_sigma=0.4).weights.sum() == pytest.approx(1.0)


def test_weights_pull_posterior_towards_the_flight_count():
    E = np.linspace(30, 90, 300)
    fu = flight_update(E, 75)
    post_mean = np.sum(fu.weights * E)
    assert 70 < post_mean < 80 and fu.ess < 300


def test_weighted_quantile_matches_numpy_for_uniform_weights():
    v = make_rng(0, "q").normal(size=2001)
    assert weighted_quantile(v, np.ones_like(v), [0.1, 0.5, 0.9]) == pytest.approx(np.quantile(v, [0.1, 0.5, 0.9]), abs=0.01)
    w = np.where(v > 0, 1.0, 0.0)
    assert weighted_quantile(v, w, [0.5])[0] > 0.3


def test_gamma_scale_posterior_closed_form_and_coverage():
    m, (lo, hi) = gamma_scale_posterior(20, 10.0)
    assert m == pytest.approx(20.5 / 10.0) and lo < 2.0 < hi
    rng = make_rng(1, "g"); R = 600; hit = 0
    for _ in range(R):
        k = int(rng.poisson(1.7 * 25.0)); _, (a, b) = gamma_scale_posterior(k, 25.0); hit += a <= 1.7 <= b
    assert hit / R >= 0.93


def test_expected_events_for_flight_is_linear_and_flare_exact():
    c = SimConfig().validate()
    segs = ((0.0, 1e5), (2e5, 3e5))
    base = expected_events_for_flight(c, "sram", 1e8, segs)
    assert expected_events_for_flight(c, "sram", 2e8, segs) == pytest.approx(2 * base, rel=1e-12)
    assert expected_events_for_flight(c, "sram", 1e8, ((0.0, 2e5),)) == pytest.approx(2 * expected_events_for_flight(c, "sram", 1e8, ((0.0, 1e5),)), rel=1e-12)
    withfl = expected_events_for_flight(c, "sram", 1e8, segs, ((0.0, 1e4, 2.0),))
    env = RadiationEnvironment(c, OrbitalEnvironment(c.orbital))
    assert withfl - base == pytest.approx(1e8 * env.sep_coeff["sram"] * 2.0 * 1e4, rel=1e-9)
    assert expected_events_for_flight(c, "sram", 1e8, ((1e5, 2e5),), ((0.0, 1e4, 2.0),)) == pytest.approx(
        expected_events_for_flight(c, "sram", 1e8, ((1e5, 2e5),)), rel=1e-12)      # flare outside the monitored window


# ====================================================================== AVF
def test_calibrate_avf_conservative_vs_point_estimate():
    c1, c2 = SimConfig(), SimConfig()
    r1 = calibrate_avf(c1, trials_per_bit=30, seed=1, conservative=True)
    r2 = calibrate_avf(c2, trials_per_bit=30, seed=1, conservative=False)
    assert c2.radiation.avf_sram == pytest.approx(r2.avf) and c1.radiation.avf_sram == pytest.approx(r1.ci_high)
    assert c1.radiation.avf_sram >= c2.radiation.avf_sram and 0 < c2.radiation.avf_sram < 1
    e = c1.calibration["radiation.avf_sram"]
    assert e["status"] == "measured" and e["ci95"][0] <= e["ci95"][1] and "fault injection" in e["method"].lower()
    with pytest.raises(ValueError, match="RTL"):
        calibrate_avf(c1, "avf_register")
