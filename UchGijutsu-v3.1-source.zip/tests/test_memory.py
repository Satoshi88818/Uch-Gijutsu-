import math

import pytest

from uchu import DType, SimConfig, WorkloadLayer, estimate_layer, structured_sparsity_speedup
from uchu.memory import hbm_bandwidth_bytes_s, profile_pass, weight_bytes_factor

F = 1.5


def cfg(**kw):
    c = SimConfig()
    for k, v in kw.items():
        setattr(c.compute if k in ("array_size", "pipeline_overlap") else c.memory, k, v)
    return c.validate()


def test_cycle_count_exact_single_tile():
    c = cfg(array_size=64)
    l = WorkloadLayer("t", "linear", 64, 128, 64, DType.INT8)
    p = estimate_layer(l, c, F)
    assert p.t_compute_s == pytest.approx((128 + 2 * 64 - 2) / (F * 1e9))


def test_tiling_quantisation_penalty():
    c = cfg(array_size=64)
    a = estimate_layer(WorkloadLayer("a", "linear", 64, 4096, 64), c, F)
    b = estimate_layer(WorkloadLayer("b", "linear", 65, 4096, 64), c, F)   # 2 row-tiles for 1 extra row
    assert b.t_compute_s == pytest.approx(2 * a.t_compute_s)
    assert b.util < 0.55 * a.util + 1e-9 or b.util < a.util * 0.6


def test_peak_matches_closed_form():
    c = cfg()
    p = estimate_layer(WorkloadLayer("t", "linear", 4096, 4096, 4096), c, F)
    assert p.peak_exec_tflops == pytest.approx(2 * 256 * 256 * F * 1e9 / 1e12)


def test_large_gemm_is_compute_bound_and_near_peak():
    c = cfg()
    p = estimate_layer(WorkloadLayer("t", "linear", 8192, 8192, 8192), c, F)
    assert not p.memory_bound
    assert p.util > 0.9


def test_gemv_on_output_stationary_array_is_compute_limited_by_idle_rows():
    """M=1 uses 1 of 256 PE rows: the array, not HBM, is the bottleneck at default bandwidth."""
    p = estimate_layer(WorkloadLayer("gemv", "linear", 1, 8192, 8192), cfg(), F)
    assert not p.memory_bound and p.util < 0.01


def test_memory_bound_when_bandwidth_is_scarce():
    slow = cfg(hbm_bw_tb_s_per_stack=0.05)
    p = estimate_layer(WorkloadLayer("gemv", "linear", 1, 8192, 8192), slow, F)
    assert p.memory_bound and p.t_memory_s > p.t_compute_s
    assert p.duration_s == pytest.approx(p.t_memory_s)


def test_roofline_crossover_follows_arithmetic_intensity():
    """With full array utilisation (aligned dims, large K) memory_bound <=> AI < ridge."""
    slow = cfg(hbm_bw_tb_s_per_stack=0.05)
    lo = estimate_layer(WorkloadLayer("lo", "linear", 256, 4096, 4096), slow, F)
    hi = estimate_layer(WorkloadLayer("hi", "linear", 8192, 4096, 4096), slow, F)
    assert lo.arithmetic_intensity < lo.ridge_point and lo.memory_bound
    assert hi.arithmetic_intensity > hi.ridge_point and not hi.memory_bound


def test_duration_is_max_of_the_two_roofs_everywhere():
    c = cfg(hbm_bw_tb_s_per_stack=0.2)
    for M in (1, 7, 64, 256, 300, 4096):
        for K in (64, 1000, 4096):
            for N in (64, 513, 4096):
                p = estimate_layer(WorkloadLayer("r", "linear", M, K, N), c, F)
                assert p.duration_s == pytest.approx(max(p.t_compute_s, p.t_memory_s))
                assert p.memory_bound == (p.t_memory_s > p.t_compute_s)
                assert p.executed_flops / p.duration_s <= p.peak_exec_tflops * 1e12 * (1 + 1e-12)


def test_sparsity_counted_once_never_exceeds_nominal_speedup():
    c = cfg()
    d = estimate_layer(WorkloadLayer("d", "linear", 8192, 8192, 8192, DType.INT8, 0.0), c, F)
    s = estimate_layer(WorkloadLayer("s", "linear", 8192, 8192, 8192, DType.INT8, 0.5), c, F)
    assert s.executed_flops == pytest.approx(d.executed_flops / 1.85)
    assert 1.7 < d.duration_s / s.duration_s < 1.85       # fill/drain does not shrink -> < 1.85, never 1.85^2
    assert s.dense_flops == d.dense_flops


def test_sparsity_speedup_approaches_nominal_for_deep_reductions():
    c = cfg()
    d = estimate_layer(WorkloadLayer("d", "linear", 256, 131072, 256, DType.INT8, 0.0), c, F)
    s = estimate_layer(WorkloadLayer("s", "linear", 256, 131072, 256, DType.INT8, 0.5), c, F)
    assert d.duration_s / s.duration_s == pytest.approx(1.85, rel=0.01)


def test_pipeline_overlap_hides_fill_drain():
    l = WorkloadLayer("a", "linear", 1024, 64, 1024)      # 16 tiles, shallow K: fill/drain dominates
    exposed = estimate_layer(l, cfg(array_size=64, pipeline_overlap=0.0), F)
    hidden = estimate_layer(l, cfg(array_size=64, pipeline_overlap=1.0), F)
    tiles = 16 * 16
    assert exposed.t_compute_s == pytest.approx(tiles * (64 + 126) / (F * 1e9))
    assert hidden.t_compute_s == pytest.approx((tiles * 64 + 126) / (F * 1e9))
    assert hidden.util / exposed.util == pytest.approx((tiles * 190) / (tiles * 64 + 126), rel=1e-9)


def test_dtype_scaling_int8_vs_fp16():
    c = cfg()
    i8 = estimate_layer(WorkloadLayer("a", "linear", 256, 131072, 256, DType.INT8), c, F)
    f16 = estimate_layer(WorkloadLayer("b", "linear", 256, 131072, 256, DType.FP16), c, F)
    assert f16.t_compute_s / i8.t_compute_s == pytest.approx(2.0, rel=0.01)
    int4 = estimate_layer(WorkloadLayer("c", "linear", 256, 131072, 256, DType.INT4), c, F)
    assert i8.t_compute_s / int4.t_compute_s == pytest.approx(2.0, rel=0.01)


def test_sparse_weights_reduce_traffic():
    c = cfg()
    d = estimate_layer(WorkloadLayer("d", "linear", 8, 4096, 4096, DType.INT8, 0.0), c, F)
    s = estimate_layer(WorkloadLayer("s", "linear", 8, 4096, 4096, DType.INT8, 0.5), c, F)
    assert s.hbm_bytes < d.hbm_bytes
    assert weight_bytes_factor(0.5, 1.0) == pytest.approx(0.5 * 1.25)


def test_unsupported_sparsity_rejected():
    with pytest.raises(ValueError):
        WorkloadLayer("x", "linear", 8, 8, 8, DType.INT8, 0.75)
    with pytest.raises(ValueError):
        structured_sparsity_speedup(0.3)


def test_small_sram_increases_traffic_big_sram_is_compulsory():
    l = WorkloadLayer("t", "linear", 4096, 4096, 4096)
    small = estimate_layer(l, cfg(onchip_sram_mb=1.0), F)
    big = estimate_layer(l, cfg(onchip_sram_mb=4096.0), F)
    compulsory = (4096 * 4096) * 3 * 1.0
    assert big.hbm_bytes == pytest.approx(compulsory)
    assert small.hbm_bytes > 2 * big.hbm_bytes


def test_ecc_overhead_reduces_bandwidth():
    on = hbm_bandwidth_bytes_s(cfg(ecc_enabled=True))
    off = hbm_bandwidth_bytes_s(cfg(ecc_enabled=False))
    assert on == pytest.approx(off / 1.125)


def test_util_bounded_and_profile_consistent():
    c = cfg()
    from uchu import build_transformer_workload
    L = build_transformer_workload(num_layers=2)
    pr = profile_pass(L, c, F)
    assert 0.0 < pr.util <= 1.0
    assert pr.duration_s == pytest.approx(sum(p.duration_s for p in pr.layers))
    assert all(0.0 < p.util <= 1.0 for p in pr.layers)


def test_duration_scales_inversely_with_frequency_when_compute_bound():
    c = cfg()
    l = WorkloadLayer("t", "linear", 8192, 8192, 8192)
    a, b = estimate_layer(l, c, 1.0), estimate_layer(l, c, 2.0)
    assert a.duration_s / b.duration_s == pytest.approx(2.0, rel=1e-6)
