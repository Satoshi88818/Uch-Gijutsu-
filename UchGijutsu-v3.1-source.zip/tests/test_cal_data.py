import math
import textwrap

import numpy as np
import pytest

from uchu import SimConfig, make_rng
from uchu.calibration import data as D
from uchu.calibration.data import CalibrationDataError, effective_let
from uchu.calibration.registry import (STATUS_ACCEPTED, UncalibratedError, accept_placeholder, declare, get_by_path,
                                       placeholder_audit, record, require_calibrated, required_paths, set_by_path)
from uchu.calibration.synthetic import bake_environment_tables
from uchu.config import OrbitalConfig, OrbitType, SolarActivity, SpectrumTable
from uchu.orbit import FlareSchedule, OrbitalEnvironment
from uchu.radiation import RadiationEnvironment, RadiationSubsystem
from uchu.memory import hbm_bandwidth_bytes_s


# ------------------------------------------------------------------ config round trip & new hooks
def test_config_round_trip_default_and_modified():
    c = SimConfig().validate()
    assert SimConfig.from_dict(c.to_dict()).config_hash() == c.config_hash()
    c.orbital = OrbitalConfig.for_orbit(OrbitType.GEO, solar_activity=SolarActivity.HIGH, sep_events_per_year=3.5)
    c.radiation.tables = {"gcr_ion": SpectrumTable([0.1, 1, 10], [1e-2, 1e-3, 1e-5])}
    c.radiation.environment_mode = "tabulated_orbit"
    record(c, "power.base_power_w", source="bench", method="fit", ci=(1.0, 2.0))
    c2 = SimConfig.from_json(c.to_json())
    assert c2.config_hash() == c.config_hash()
    assert c2.orbital.orbit_type is OrbitType.GEO and c2.orbital.sep_events_per_year == 3.5
    assert isinstance(c2.radiation.tables["gcr_ion"], SpectrumTable) and c2.calibration["power.base_power_w"]["ci95"] == [1.0, 2.0]


def test_from_dict_is_strict_and_spectrum_tables_canonical():
    with pytest.raises(ValueError, match="unknown field"):
        SimConfig.from_dict({"nonsense": 1})
    with pytest.raises(ValueError, match="unknown field"):
        SimConfig.from_dict({"radiation": {"sram": {"ion": {"sigma_sat_cm2": 1, "x_th": 1, "width": 1, "shape": 1, "bogus": 2},
                                                        "proton": {"sigma_sat_cm2": 1, "x_th": 1, "width": 1, "shape": 1}}}})
    assert SpectrumTable([1, 2], [3, 2]).x == [1.0, 2.0]


@pytest.mark.parametrize("mutate,msg", [
    (lambda c: setattr(c.radiation, "environment_mode", "magic"), "environment_mode"),
    (lambda c: setattr(c.radiation, "environment_mode", "tabulated_orbit"), "at least one table"),
    (lambda c: c.radiation.tables.update(bogus=SpectrumTable([1, 2], [2, 1])), "unknown spectrum table"),
    (lambda c: c.radiation.tables.update(gcr_ion=SpectrumTable([2, 1], [2, 1])), "ascending"),
    (lambda c: c.radiation.tables.update(gcr_ion=SpectrumTable([1, 2], [1, 2])), "non-increasing"),
    (lambda c: setattr(c.memory, "hbm_efficiency", 1.5), "hbm_efficiency"),
    (lambda c: setattr(c.radiation, "mbu_cluster_geom_p", 0.0), "mbu_cluster_geom_p"),
    (lambda c: setattr(c.orbital, "sep_intensity_median", -1.0), "SEP"),
])
def test_new_config_fields_validated(mutate, msg):
    c = SimConfig(); mutate(c)
    with pytest.raises(ValueError, match=msg):
        c.validate()


def _env(c):
    o = OrbitalEnvironment(c.orbital); o.flares = FlareSchedule.from_events([])
    return RadiationEnvironment(c.validate(), o)


def test_baked_tables_reproduce_placeholder_rates():
    base = SimConfig(); baked = bake_environment_tables(base)
    e0, e1 = _env(base), _env(baked)
    for r in ("sram", "register", "logic_set", "sel"):
        assert e1.static_rate[r] == pytest.approx(e0.static_rate[r], rel=2e-3, abs=0)
        if e0.sep_coeff[r] > 0:
            assert e1.sep_coeff[r] == pytest.approx(e0.sep_coeff[r], rel=2e-3, abs=0)


def test_tabulated_mode_bypasses_every_placeholder_scaling():
    baked = bake_environment_tables(SimConfig())
    e_ref = _env(baked)
    placeholder_ref = _env(SimConfig())
    for mutate in (lambda c: setattr(c.radiation, "shield_mm_al", 50.0),       # acts on proton terms
                   lambda c: setattr(c.orbital, "inclination_deg", 5.0),        # acts on the geomagnetic factor (SEP/GCR)
                   lambda c: setattr(c.orbital, "altitude_km", 1500.0)):        # acts on the trapped-proton factor
        c = baked.copy(); mutate(c); e = _env(c)
        for attr in ("static_rate", "sep_coeff"):                               # tables are authoritative: no reaction at all
            assert getattr(e, attr)["sram"] == pytest.approx(getattr(e_ref, attr)["sram"], rel=1e-12, abs=0)
        p = SimConfig(); mutate(p); ep = _env(p)                                # ...whereas the placeholders do react
        reacts = any(getattr(ep, a)["sram"] != pytest.approx(getattr(placeholder_ref, a)["sram"], rel=1e-2, abs=0)
                     for a in ("static_rate", "sep_coeff"))
        assert reacts


def test_tabulated_mode_bypasses_solar_modulation_where_gcr_dominates():
    def deep(sol, tabulated):
        c = SimConfig(); c.orbital = OrbitalConfig.for_orbit(OrbitType.DEEP, solar_activity=sol)
        if tabulated:
            c = bake_environment_tables(SimConfig().__class__.from_dict(
                {**c.to_dict(), "orbital": {**c.to_dict()["orbital"], "solar_activity": "SolarActivity.LOW"}}))
            c.orbital.solar_activity = sol            # tables baked at LOW; changing the label must change nothing
        return _env(c).static_rate["sram"]
    assert deep(SolarActivity.HIGH, False) < 0.6 * deep(SolarActivity.LOW, False)     # placeholders: GCR modulated
    assert deep(SolarActivity.HIGH, True) == pytest.approx(deep(SolarActivity.LOW, True), rel=1e-12, abs=0)


def test_missing_table_component_means_zero_flux():
    baked = bake_environment_tables(SimConfig())
    full = _env(baked).static_rate["sram"]
    c = baked.copy(); del c.radiation.tables["trapped_proton"]
    assert _env(c).static_rate["sram"] < 0.01 * full         # trapped protons dominate LEO
    c = baked.copy(); del c.radiation.tables["sep_proton"]; del c.radiation.tables["sep_ion"]
    assert _env(c).sep_coeff["sram"] == 0.0


def test_hbm_efficiency_scales_bandwidth_linearly():
    a, b = SimConfig(), SimConfig(); b.memory.hbm_efficiency = 0.5
    assert hbm_bandwidth_bytes_s(b) == pytest.approx(0.5 * hbm_bandwidth_bytes_s(a))


def test_mbu_geometric_parameter_controls_cluster_size():
    def mean_size(q):
        c = SimConfig(); c.radiation.mbu_cluster_geom_p = q
        s = RadiationSubsystem(c.validate(), None, make_rng(0, "x"))
        return s._cluster_sizes(200_000).mean()
    assert mean_size(0.9) == pytest.approx(2.0 + 0.1 + 0.01 + 0.001 + 0.0001, abs=0.02) or mean_size(0.9) < 2.2
    assert mean_size(0.2) > 3.2 > mean_size(0.5) > mean_size(0.9)


def test_sep_statistics_configurable_and_default_unchanged():
    from uchu.orbit import SEP_EVENTS_PER_YEAR
    o0 = OrbitalEnvironment(OrbitalConfig(), make_rng(1, "o"))
    assert o0.flares.rate == pytest.approx(SEP_EVENTS_PER_YEAR[SolarActivity.MODERATE] / (365.25 * 86400))
    cfg = OrbitalConfig(sep_events_per_year=10.0, sep_mean_duration_s=3600.0, sep_intensity_median=5.0, sep_intensity_log_sigma=0.3)
    o = OrbitalEnvironment(cfg, make_rng(1, "o")); o.flares.extend_to(60 * 365.25 * 86400.0)
    ev = o.flares.events
    assert len(ev) == pytest.approx(600, rel=0.15)
    assert np.median([e[2] for e in ev]) == pytest.approx(5.0, rel=0.08)
    assert np.mean([e[1] - e[0] for e in ev]) == pytest.approx(3600.0, rel=0.1)


# ------------------------------------------------------------------ data layer
def test_effective_let_cosine_law_and_limits():
    assert effective_let(10.0, 0.0) == 10.0 and effective_let(10.0, 60.0) == pytest.approx(20.0)
    with pytest.raises(CalibrationDataError):
        effective_let(10.0, 75.0)
    with pytest.raises(CalibrationDataError):
        effective_let(10.0, -1.0)


def write(tmp_path, name, text):
    p = tmp_path / name
    p.write_text(textwrap.dedent(text).lstrip())
    return p


def test_beam_loader_applies_tilt_conventions(tmp_path):
    p = write(tmp_path, "b.csv", """
        # comment line ignored
        let_mev_cm2_mg,fluence_cm2,events,tilt_deg,n_units

        10,1e7,50,60,1e6
        20,1e7,80,0,1e6
        """)
    ds = D.load_beam_csv(p, "sram", "ion")
    assert ds.points[0].x == pytest.approx(20.0) and ds.points[0].fluence_cm2 == pytest.approx(5e6)
    assert ds.points[1].x == 20.0 and ds.points[1].fluence_cm2 == 1e7 and ds.points[0].n_units == 1e6


def test_proton_loader_and_defaults(tmp_path):
    p = write(tmp_path, "p.csv", "energy_mev,fluence_cm2,events\n30,1e9,5\n60,1e9,9\n")
    ds = D.load_beam_csv(p, "sram", "proton")
    assert [pt.x for pt in ds.points] == [30.0, 60.0] and ds.points[0].n_units == 1.0


@pytest.mark.parametrize("text,needle", [
    ("let_mev_cm2_mg,fluence_cm2\n1,1e7\n", "missing column"),
    ("let_mev_cm2_mg,fluence_cm2,events\n1,1e7,2.5\n", "must be an integer"),
    ("let_mev_cm2_mg,fluence_cm2,events\n1,abc,2\n", "not a number"),
    ("let_mev_cm2_mg,fluence_cm2,events\n1,1e7,\n", "is empty"),
    ("let_mev_cm2_mg,fluence_cm2,events\n", "no data rows"),
    ("let_mev_cm2_mg,fluence_cm2,events\n1,nan,3\n", "not finite"),
])
def test_beam_loader_rejects_bad_files_with_located_messages(tmp_path, text, needle):
    with pytest.raises(CalibrationDataError, match=needle):
        D.load_beam_csv(write(tmp_path, "bad.csv", text), "sram", "ion")


def test_error_messages_name_file_and_row(tmp_path):
    p = write(tmp_path, "named.csv", "let_mev_cm2_mg,fluence_cm2,events\n1,1e7,3\n2,xyz,4\n")
    with pytest.raises(CalibrationDataError) as e:
        D.load_beam_csv(p, "sram", "ion")
    assert "named.csv" in str(e.value) and "row 3" in str(e.value) and "fluence_cm2" in str(e.value)


def test_dataset_physical_validation():
    for pt in (D.BeamPoint(-1, 1e7, 1), D.BeamPoint(1, 0, 1), D.BeamPoint(1, 1e7, -1), D.BeamPoint(1, 1e7, 1, 0)):
        with pytest.raises(CalibrationDataError):
            D.BeamDataset("x", "sram", "ion", (pt,))
    with pytest.raises(CalibrationDataError):
        D.BeamDataset("x", "flash", "ion", ())
    with pytest.raises(CalibrationDataError):
        D.load_beam_csv("/nonexistent/file.csv", "sram", "ion")


def test_other_loaders_validate(tmp_path):
    pw = D.load_power_csv(write(tmp_path, "p.csv", "T_k,f_ghz,v_v,util,power_w\n300,1.5,0.9,1,50\n"))
    assert pw[0].power_w == 50.0
    with pytest.raises(CalibrationDataError, match="impossible"):
        D.load_power_csv(write(tmp_path, "p2.csv", "T_k,f_ghz,v_v,util,power_w\n300,1.5,0.9,1.5,50\n"))
    rows = "\n".join(f"{i * 10},40,{i % 2},{290 + i}" for i in range(12))
    assert len(D.load_thermal_csv(write(tmp_path, "t.csv", "t_s,power_w,eclipse,T_k\n" + rows + "\n"))) == 12
    with pytest.raises(CalibrationDataError, match="strictly increasing"):
        D.load_thermal_csv(write(tmp_path, "t2.csv", "t_s,power_w,eclipse,T_k\n" + "\n".join(f"{5},40,0,290" for _ in range(12)) + "\n"))
    with pytest.raises(CalibrationDataError, match="eclipse must be"):
        D.load_thermal_csv(write(tmp_path, "t3.csv", "t_s,power_w,eclipse,T_k\n" + "\n".join(f"{i},40,maybe,290" for i in range(12)) + "\n"))
    with pytest.raises(CalibrationDataError, match=">= 10 samples"):
        D.load_thermal_csv(write(tmp_path, "t4.csv", "t_s,power_w,eclipse,T_k\n1,40,0,290\n2,40,0,290\n"))
    assert D.load_perf_csv(write(tmp_path, "f.csv", "M,K,N,dtype,sparsity,freq_ghz,latency_s\n8,8,8,int8,0.5,1.5,1e-5\n"))[0].sparsity == 0.5
    with pytest.raises(CalibrationDataError, match="dtype"):
        D.load_perf_csv(write(tmp_path, "f2.csv", "M,K,N,dtype,sparsity,freq_ghz,latency_s\n8,8,8,int7,0,1.5,1e-5\n"))
    with pytest.raises(CalibrationDataError, match="sparsity"):
        D.load_perf_csv(write(tmp_path, "f3.csv", "M,K,N,dtype,sparsity,freq_ghz,latency_s\n8,8,8,int8,0.75,1.5,1e-5\n"))
    assert D.load_mbu_csv(write(tmp_path, "m.csv", "cluster_size,count\n1,90\n2,8\n3,2\n")).counts == {1: 90, 2: 8, 3: 2}
    assert len(D.load_sep_csv(write(tmp_path, "s.csv", "duration_s,intensity_rel\n3600,1.2\n7200,0.7\n"), 1e7).durations_s) == 2
    with pytest.raises(CalibrationDataError):
        D.load_spectrum_csv(write(tmp_path, "sp.csv", "x,phi_integral\n1,1e-3\n2,1e-2\n"))     # flux increases
    assert D.load_spectrum_csv(write(tmp_path, "sp2.csv", "x,phi_integral\n1,1e-2\n2,1e-3\n")).x == [1.0, 2.0]


# ------------------------------------------------------------------ registry / audit
def test_fresh_config_is_entirely_unresolved():
    c = SimConfig(); a = placeholder_audit(c)
    assert a.n_total > 40 and not a.resolved and len(a.unresolved) == a.n_total
    with pytest.raises(UncalibratedError):
        require_calibrated(c)


def test_declare_and_record_resolve_paths():
    c = SimConfig()
    declare(c, "radiation.gates_per_pe", 1800, "netlist rev C")
    assert c.radiation.gates_per_pe == 1800
    a = placeholder_audit(c)
    assert "radiation.gates_per_pe" in a.resolved and "radiation.gates_per_pe" not in a.unresolved
    assert a.resolved["radiation.gates_per_pe"]["source"] == "netlist rev C"
    require_calibrated(c, ["radiation.gates_per_pe"])                       # subset check passes
    with pytest.raises(UncalibratedError):
        require_calibrated(c, ["radiation.gates_per_pe", "power.base_power_w"])


def test_accepted_placeholders_are_visible_and_strict_by_default():
    c = SimConfig()
    accept_placeholder(c, "power.interconnect_frac", "no layout data yet")
    a = placeholder_audit(c)
    assert "power.interconnect_frac" in a.accepted and c.calibration["power.interconnect_frac"]["status"] == STATUS_ACCEPTED
    with pytest.raises(UncalibratedError):
        require_calibrated(c, ["power.interconnect_frac"])
    require_calibrated(c, ["power.interconnect_frac"], allow_accepted=True)


def test_required_paths_adapt_to_config():
    c = SimConfig()
    assert "radiation.sel.proton.sigma_sat_cm2" not in required_paths(c)       # sigma_sat == 0: mechanism not modelled
    assert "radiation.sram.ion.x_th" in required_paths(c)
    assert "radiation.tmr_residual" not in required_paths(c)
    c.radiation.tmr_enabled = True; c.memory.ecc_enabled = False
    p = required_paths(c)
    assert "radiation.tmr_residual" in p and "memory.ecc_bw_overhead_pct" not in p


def test_path_helpers_and_bad_status():
    c = SimConfig()
    assert get_by_path(c, "radiation.sram.ion.x_th") == c.radiation.sram.ion.x_th
    set_by_path(c, "radiation.sram.ion.x_th", 2.5); assert c.radiation.sram.ion.x_th == 2.5
    with pytest.raises(AttributeError):
        set_by_path(c, "radiation.not_a_thing", 1)
    with pytest.raises(ValueError):
        record(c, "power.base_power_w", source="x", method="y", status="vibes")
