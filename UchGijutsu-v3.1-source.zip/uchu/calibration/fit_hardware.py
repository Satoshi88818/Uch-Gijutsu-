"""Hardware-side calibration: power model, lumped thermal model, performance (roofline) parameters.

Each fit reports parameter covariance from the Jacobian, a condition-number identifiability check on the *measurement
design* (non-identifiable designs raise ``CalibrationDataError`` instead of returning confident nonsense), and
parameter draws for epistemic-uncertainty propagation.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import least_squares

from ..config import DType, OrbitType, ProcessNode, SimConfig
from ..memory import WorkloadLayer, estimate_layer
from ..thermal import SIGMA_SB
from .data import CalibrationDataError, PerfMeasurement, PowerMeasurement, ThermalSample
from .registry import record

COND_WARN, COND_FATAL = 1e4, 1e7


def _covariance(res, n_obs: int, names: Sequence[str], scale: Optional[np.ndarray] = None):
    """Wald covariance from the Jacobian.  Identifiability (condition number / weakest direction) is judged on the
    Jacobian with each column multiplied by that parameter's plausible range, so it does not depend on units."""
    J = res.jac
    n_par = J.shape[1]
    dof = max(n_obs - n_par, 1)
    s2 = float(np.sum(res.fun ** 2) / dof)
    Js = J if scale is None else J * np.asarray(scale)[None, :]
    sv = np.linalg.svd(Js, compute_uv=False)
    cond = float(sv[0] / max(sv[-1], 1e-300))
    warn: List[str] = []
    if cond > COND_FATAL:
        _, _, vt = np.linalg.svd(Js)
        weak = names[int(np.argmax(np.abs(vt[-1])))]
        raise CalibrationDataError(f"measurement design cannot identify the parameters (condition number {cond:.2g}; "
                                   f"weakest direction is dominated by '{weak}'): add measurements that vary it independently")
    if cond > COND_WARN:
        warn.append(f"ill-conditioned design (condition number {cond:.2g}): some parameters are strongly correlated")
    return s2 * np.linalg.pinv(J.T @ J), float(math.sqrt(s2)), warn, cond


def _ci(theta: np.ndarray, cov: np.ndarray, lo_hi=None) -> np.ndarray:
    se = np.sqrt(np.maximum(np.diag(cov), 0))
    return np.column_stack([theta - 1.96 * se, theta + 1.96 * se])


# ===========================================================================
# Power model
# ===========================================================================
@dataclass
class PowerFit:
    S_w: float
    D_w: float
    leak_temp_coeff: float
    clock_frac: float
    config_values: Dict[str, float]
    ci95: Dict[str, Tuple[float, float]]
    rel_rms_error: float
    cond: float
    samples: np.ndarray                 # (n, 4) draws of base_power_w, static_frac, leak_temp_coeff, clock_frac
    n_points: int
    warnings: List[str] = field(default_factory=list)


def _power_pred(u, T, f, v, util, cfg, ic_scale):
    S, D, k, c = math.exp(u[0]), math.exp(u[1]), u[2], u[3]
    ic = cfg.power.interconnect_frac
    fr, vr = f / cfg.dvfs.nom_freq_ghz, v / cfg.dvfs.nom_voltage_v
    act = (1.0 - c - ic) + ic * ic_scale
    return S * np.exp(k * (T - cfg.power.T_nom_k) / cfg.power.T_nom_k) * vr ** 3 + D * fr * vr ** 2 * (c + act * util)


def power_to_config_values(cfg: SimConfig, S: float, D: float) -> Tuple[float, float]:
    """Invert PowerModel's scaling: (static_nom_w, dynamic_nom_w) -> (base_power_w, static_frac) for THIS chip."""
    comp, pw = cfg.compute, cfg.power
    area_ratio = comp.area_mm2 / pw.ref_area_mm2
    array_ratio = (comp.array_size / pw.ref_array_size) ** 2
    ref = ProcessNode[pw.ref_node]
    stat = S / (area_ratio * comp.process_node.leakage_factor() / ref.leakage_factor())
    dyn = D / (array_ratio * comp.process_node.cap_factor() / ref.cap_factor())
    return stat + dyn, stat / (stat + dyn)


def fit_power_model(meas: Sequence[PowerMeasurement], cfg: SimConfig, rng: np.random.Generator,
                    n_draw: int = 500) -> PowerFit:
    if len(meas) < 8:
        raise CalibrationDataError(f"need >= 8 power measurements, got {len(meas)}")
    a = {n: np.array([getattr(m, n) for m in meas], float) for n in ("T_k", "f_ghz", "v_v", "util", "power_w")}
    array_ratio = (cfg.compute.array_size / cfg.power.ref_array_size) ** 2
    ic_scale = array_ratio ** cfg.power.interconnect_extra_exponent
    c_hi = 0.95 - cfg.power.interconnect_frac
    P = a["power_w"]

    def resid(u):
        return (_power_pred(u, a["T_k"], a["f_ghz"], a["v_v"], a["util"], cfg, ic_scale) - P) / P

    lo = np.array([math.log(1e-3), math.log(1e-3), 0.0, 0.0])
    hi = np.array([math.log(1e4), math.log(1e4), 12.0, c_hi])
    best = None
    for S0 in (0.2, 0.5, 0.8):
        for k0 in (2.0, 5.0):
            u0 = np.array([math.log(S0 * P.mean()), math.log((1 - S0) * P.mean()), k0, 0.1])
            r = least_squares(resid, np.clip(u0, lo + 1e-9, hi - 1e-9), bounds=(lo, hi))
            if best is None or r.cost < best.cost:
                best = r
    cov, sig, warn, cond = _covariance(best, len(P), ["ln S (static)", "ln D (dynamic)", "leak_temp_coeff", "clock_frac"], hi - lo)
    u = best.x
    at_bound = [n for n, v, l, h in zip(["static", "dynamic", "leak_temp_coeff", "clock_frac"], u, lo, hi)
                if min(v - l, h - v) < 1e-6]
    if at_bound:
        warn.append(f"estimate at a bound for {at_bound}: Wald interval invalid for those parameters")
    draws = rng.multivariate_normal(u, cov, size=n_draw, check_valid="ignore")
    draws = np.clip(draws, lo, hi)
    S, D = math.exp(u[0]), math.exp(u[1])
    base, sf = power_to_config_values(cfg, S, D)
    d_base, d_sf = zip(*(power_to_config_values(cfg, math.exp(d[0]), math.exp(d[1])) for d in draws))
    samples = np.column_stack([d_base, d_sf, draws[:, 2], draws[:, 3]])
    lo_hi = np.percentile(samples, [2.5, 97.5], axis=0)
    names = ["base_power_w", "static_frac", "leak_temp_coeff", "clock_frac"]
    ci = {n: (float(lo_hi[0, i]), float(lo_hi[1, i])) for i, n in enumerate(names)}
    if cfg.power.interconnect_frac > 0:
        warn.append("interconnect_frac is not identifiable from chip-level power (it only splits the active power); "
                    "supply it from post-layout analysis via registry.declare()")
    return PowerFit(S, D, float(u[2]), float(u[3]), dict(zip(names, [base, sf, float(u[2]), float(u[3])])), ci,
                    float(np.sqrt(np.mean(best.fun ** 2))), cond, samples, len(P), warn)


def apply_power_fit(cfg: SimConfig, fit: PowerFit, source: str) -> None:
    for n, v in fit.config_values.items():
        setattr(cfg.power, n, v)
        record(cfg, f"power.{n}", source=source, method="nonlinear least squares (relative residuals) + Wald/MVN",
               value=v, ci=fit.ci95[n], note=f"rms rel. error {fit.rel_rms_error:.3%}, cond {fit.cond:.1e}")


def suggest_power_design() -> List[dict]:
    """Minimum measurement design that identifies (static, dynamic, leakage slope, clock share)."""
    return [{"T_k": T, "f_frac": f, "v_frac": v, "util": u}
            for T in (300.0, 340.0, 380.0) for (f, v) in ((1.0, 1.0), (0.6, 0.8)) for u in (0.0, 0.5, 1.0)]


# ===========================================================================
# Thermal model
# ===========================================================================
def integrate_thermal(C: float, kr: float, Q_sun: float, Q_ecl: float, t: np.ndarray, P: np.ndarray,
                      ecl: np.ndarray, T0: float) -> np.ndarray:
    """Backward-Euler / Newton integration of  C dT/dt = P + Q - kr T^4  (same equation as LumpedThermalModel.step,
    with constant power over each telemetry interval).  Fast enough for optimiser inner loops."""
    T = np.empty(len(t))
    T[0] = Tc = T0
    for i in range(1, len(t)):
        a = C / (t[i] - t[i - 1])
        rhs = P[i] + (Q_ecl if ecl[i] else Q_sun)
        Tn = Tc
        for _ in range(60):
            f = a * (Tn - Tc) - rhs + kr * Tn ** 4
            step = f / (a + 4.0 * kr * Tn ** 3)
            Tn -= step
            if abs(step) < 1e-10:
                break
        T[i] = Tc = Tn
    return T


@dataclass
class ThermalFit:
    C: float
    kr: float
    Q_sun: float
    Q_ecl: float
    config_values: Dict[str, float]
    ci95: Dict[str, Tuple[float, float]]
    rms_K: float
    cond: float
    samples: np.ndarray        # (n, 4): C, kr, Q_sun, Q_ecl
    fixed: List[str]
    n_points: int
    warnings: List[str] = field(default_factory=list)


def thermal_to_config_values(cfg: SimConfig, C: float, kr: float, Q_sun: float, Q_ecl: float) -> Tuple[Dict[str, float], List[str]]:
    tc, w = cfg.thermal, []
    F_eff = max(0.1, tc.view_factor * (1.0 - tc.degradation_per_year * tc.mission_year))
    A = kr / (SIGMA_SB * tc.emissivity * F_eff)
    out = {"capacitance_j_per_k": C, "radiator_area_m2": A}
    if cfg.orbital.orbit_type == OrbitType.DEEP:
        out["sun_projected_fraction"] = max(Q_sun / (tc.absorptance * tc.solar_flux_w_m2 * A), 0.0)
        if out["sun_projected_fraction"] > 1.0:
            w.append(f"sunlit load implies a projected-area fraction of {out['sun_projected_fraction']:.2f} > 1: telemetry "
                     f"contains a heat source the model lacks (self-heating, harness, other units)")
        return out, w
    Fe = Q_ecl / (tc.emissivity * tc.earth_ir_w_m2 * A)
    if Fe > 1.0:
        w.append(f"eclipse load implies Earth view fraction {Fe:.2f} > 1: telemetry contains a heat source the model lacks")
        Fe = 1.0
    alb = tc.absorptance * tc.albedo * tc.solar_flux_w_m2 * Fe * tc.albedo_geometry * A
    fsun = (Q_sun - Q_ecl - alb) / (tc.absorptance * tc.solar_flux_w_m2 * A)
    if fsun < 0:
        w.append("sunlit-minus-eclipse load smaller than the albedo term: sun_projected_fraction clamped to 0")
        fsun = 0.0
    if fsun > 1.0:
        w.append(f"sunlit load implies a projected-area fraction of {fsun:.2f} > 1: telemetry contains a heat source the model lacks")
    out.update(earth_view_fraction=Fe, sun_projected_fraction=fsun)
    return out, w


def fit_thermal_model(samples: Sequence[ThermalSample], cfg: SimConfig, rng: np.random.Generator,
                      n_draw: int = 500) -> ThermalFit:
    if len(samples) < 20:
        raise CalibrationDataError(f"need >= 20 thermal telemetry samples, got {len(samples)}")
    t = np.array([s.t_s for s in samples]); P = np.array([s.power_w for s in samples])
    ecl = np.array([s.eclipse for s in samples], bool); Tm = np.array([s.T_k for s in samples])
    tc = cfg.thermal
    F_eff = max(0.1, tc.view_factor * (1.0 - tc.degradation_per_year * tc.mission_year))
    from ..thermal import LumpedThermalModel
    lm = LumpedThermalModel(cfg)
    x0 = np.array([tc.capacitance_j_per_k, tc.emissivity * SIGMA_SB * F_eff * tc.radiator_area_m2,
                   lm.env_load_w(False), lm.env_load_w(True)])
    names = ["C", "kr", "Q_sun", "Q_ecl"]
    fixed: List[str] = []
    warn: List[str] = []
    has_ecl, has_sun = ecl[1:].any(), (~ecl[1:]).any()
    if not has_ecl:
        fixed.append("Q_ecl"); warn.append("no eclipse samples: Q_ecl kept at its placeholder (unresolved)")
    if not has_sun:
        fixed.append("Q_sun"); warn.append("no sunlit samples: Q_sun kept at its placeholder (unresolved)")
    free = [i for i, n in enumerate(names) if n not in fixed]

    lo = np.array([math.log(1.0), math.log(1e-13), 0.0, 0.0]); hi = np.array([math.log(1e7), math.log(1e-6), 5e3, 5e3])

    def full(v):
        u = np.array([math.log(x0[0]), math.log(x0[1]), x0[2], x0[3]])
        u[free] = v
        return u

    def model(v):
        u = full(v)
        return integrate_thermal(math.exp(u[0]), math.exp(u[1]), u[2], u[3], t, P, ecl, Tm[0])

    def resid(v):
        return model(v) - Tm

    best = None
    base_u = np.array([math.log(x0[0]), math.log(x0[1]), x0[2], x0[3]])
    for fc in (0.3, 1.0, 3.0):
        for fk in (0.5, 1.0, 2.0):
            u0 = base_u.copy(); u0[0] += math.log(fc); u0[1] += math.log(fk)
            u0[2:] = np.maximum(u0[2:], 1.0)
            r = least_squares(resid, np.clip(u0[free], lo[free] + 1e-9, hi[free] - 1e-9),
                              bounds=(lo[free], hi[free]), x_scale="jac")
            if best is None or r.cost < best.cost:
                best = r
    cov_f, sig, w2, cond = _covariance(best, len(Tm) - 1, [names[i] for i in free], (hi - lo)[free])
    warn += w2
    u = full(best.x)
    cov = np.zeros((4, 4)); idx = np.array(free)
    cov[np.ix_(idx, idx)] = cov_f
    d = rng.multivariate_normal(u, cov, size=n_draw, check_valid="ignore")
    d = np.clip(d, lo, hi)
    samples_nat = np.column_stack([np.exp(d[:, 0]), np.exp(d[:, 1]), d[:, 2], d[:, 3]])
    C, kr, Qs, Qe = math.exp(u[0]), math.exp(u[1]), float(u[2]), float(u[3])
    cfgv, w3 = thermal_to_config_values(cfg, C, kr, Qs, Qe)
    warn += w3
    keys = list(cfgv)
    mapped = np.array([[thermal_to_config_values(cfg, *row)[0][k] for k in keys] for row in samples_nat])
    qlo, qhi = np.percentile(mapped, [2.5, 97.5], axis=0)
    ci = {k: (float(qlo[i]), float(qhi[i])) for i, k in enumerate(keys)}
    return ThermalFit(C, kr, Qs, Qe, cfgv, ci, float(np.sqrt(np.mean(best.fun ** 2))), cond,
                      samples_nat, fixed, len(Tm), warn)


def apply_thermal_fit(cfg: SimConfig, fit: ThermalFit, source: str) -> None:
    for k, v in fit.config_values.items():
        if (k == "earth_view_fraction" and "Q_ecl" in fit.fixed) or (k == "sun_projected_fraction" and "Q_sun" in fit.fixed):
            continue
        setattr(cfg.thermal, k, v)
        record(cfg, f"thermal.{k}", source=source, method="Newton/backward-Euler trajectory fit + Wald/MVN",
               status="derived" if k in ("earth_view_fraction", "sun_projected_fraction") else "measured",
               value=v, ci=fit.ci95[k], note=f"telemetry rms {fit.rms_K:.3f} K, cond {fit.cond:.1e}")
    record(cfg, "thermal.albedo_geometry", source=source, method="not separable from sun_projected_fraction",
           status="absorbed", value=cfg.thermal.albedo_geometry, note="sunlit load fitted as a lump; geometry split is nominal")


# ===========================================================================
# Performance (roofline) parameters
# ===========================================================================
_DT = {d.label: d for d in DType}


@dataclass
class PerfFit:
    params: Dict[str, float]
    ci95: Dict[str, Tuple[float, float]]
    t_launch_s: float
    log_rms: float
    cond: float
    samples: np.ndarray            # (n, 3): overlap, hbm_efficiency, speedup
    fixed: List[str]
    informative: Dict[str, int]
    n_points: int
    warnings: List[str] = field(default_factory=list)


def _layer(m: PerfMeasurement) -> WorkloadLayer:
    return WorkloadLayer("m", "gemm", m.M, m.K, m.N, _DT[m.dtype], m.sparsity)


def _set(cfg: SimConfig, overlap: float, eff: float, spd: float) -> None:
    cfg.compute.pipeline_overlap, cfg.memory.hbm_efficiency, cfg.compute.sparse_speedup_at_50 = overlap, eff, spd


def regime_counts(meas: Sequence[PerfMeasurement], cfg: SimConfig) -> Dict[str, int]:
    """How many measurements are informative about each parameter (evaluated under extreme settings)."""
    c = cfg.copy()
    n = {"pipeline_overlap": 0, "hbm_efficiency": 0, "sparse_speedup_at_50": 0}
    for m in meas:
        L = _layer(m)
        _set(c, 0.0, 1.0, cfg.compute.sparse_speedup_at_50)
        a = estimate_layer(L, c, m.freq_ghz)
        tiles = math.ceil(m.M / c.compute.array_size) * math.ceil(m.N / c.compute.array_size)
        fill = (2 * c.compute.array_size - 2) * tiles
        cycles_total = a.t_compute_s * m.freq_ghz * 1e9
        if tiles > 1 and fill / cycles_total > 0.15 and a.t_memory_s < a.t_compute_s:
            n["pipeline_overlap"] += 1
        if a.t_memory_s > 0.3 * a.t_compute_s:
            n["hbm_efficiency"] += 1
        if m.sparsity == 0.5 and a.t_memory_s < 0.5 * a.t_compute_s:
            n["sparse_speedup_at_50"] += 1
    return n


def fit_performance(meas: Sequence[PerfMeasurement], cfg: SimConfig, rng: np.random.Generator,
                    n_draw: int = 500, min_informative: int = 3) -> PerfFit:
    if len(meas) < 8:
        raise CalibrationDataError(f"need >= 8 latency measurements, got {len(meas)}")
    info = regime_counts(meas, cfg)
    names = ["pipeline_overlap", "hbm_efficiency", "sparse_speedup_at_50"]
    cur = [cfg.compute.pipeline_overlap, cfg.memory.hbm_efficiency, cfg.compute.sparse_speedup_at_50]
    fixed = [n for n in names if info[n] < min_informative]
    warn = [f"{n}: only {info[n]} informative measurement(s) (< {min_informative}); kept at its placeholder (unresolved)"
            for n in fixed]
    free = [i for i, n in enumerate(names) if n not in fixed]
    lat = np.array([m.latency_s for m in meas])
    lo = np.array([0.0, 0.05, 1.0, 0.0]); hi = np.array([1.0, 1.0, 2.0, 0.999 * lat.min()])      # launch overhead cannot exceed the fastest measurement
    c = cfg.copy()
    layers = [_layer(m) for m in meas]

    def predict(v):
        p = np.array(cur + [0.0], float)
        p[free] = v[:len(free)]
        p[3] = v[-1]
        _set(c, p[0], p[1], p[2])
        return np.array([estimate_layer(L, c, m.freq_ghz, exact_cycles=False).duration_s for L, m in zip(layers, meas)]) + p[3]

    def resid(v):
        return np.log(predict(v)) - np.log(lat)

    def solve(free_):
        idx_ = free_ + [3]
        best_ = None
        for o0 in (0.2, 0.8):
            for e0 in (0.4, 0.9):
                for s0 in (1.4, 1.9):
                    p0 = np.array([o0, e0, s0, 0.1 * lat.min()])
                    r = least_squares(lambda v: resid_for(free_, v), np.clip(p0[idx_], lo[idx_] + 1e-9, hi[idx_] - 1e-9),
                                      bounds=(lo[idx_], hi[idx_]), x_scale="jac")
                    if best_ is None or r.cost < best_.cost:
                        best_ = r
        return best_

    def resid_for(free_, v):
        p = np.array(cur + [0.0], float)
        p[free_] = v[:len(free_)]
        p[3] = v[-1]
        _set(c, p[0], p[1], p[2])
        pred = np.array([estimate_layer(L, c, m.freq_ghz, exact_cycles=False).duration_s for L, m in zip(layers, meas)]) + p[3]
        return np.log(pred) - np.log(lat)

    best = solve(free)
    while True:                       # drop parameters with no sensitivity at the optimum (non-binding regime)
        cn = np.linalg.norm(best.jac, axis=0) * (hi - lo)[free + [3]]      # sensitivity over the plausible range
        weak = [free[j] for j in range(len(free)) if cn[j] < 1e-6 * max(cn.max(), 1e-300)]
        if not weak:
            break
        for i_ in weak:
            fixed.append(names[i_])
            warn.append(f"{names[i_]}: zero sensitivity at the optimum (that regime is not binding on this chip); "
                        f"kept at its placeholder (unresolved)")
        free = [i_ for i_ in free if i_ not in weak]
        if not free:
            raise CalibrationDataError("no performance parameter is identifiable from these measurements")
        best = solve(free)
    idx = free + [3]
    cov_f, sig, w2, cond = _covariance(best, len(lat), [names[i] for i in free] + ["t_launch"], (hi - lo)[free + [3]])
    warn += w2
    est = np.array(cur + [0.0], float); est[free] = best.x[:len(free)]; est[3] = best.x[-1]
    cov = np.zeros((4, 4)); ix = np.array(idx); cov[np.ix_(ix, ix)] = cov_f
    d = np.clip(rng.multivariate_normal(est, cov, size=n_draw, check_valid="ignore"), lo, hi)
    for j in range(3):
        if j not in free:
            d[:, j] = est[j]
    q = np.percentile(d[:, :3], [2.5, 97.5], axis=0)
    ci = {n: (float(q[0, i]), float(q[1, i])) for i, n in enumerate(names)}
    at_bound = [names[i] for i in free if min(est[i] - lo[i], hi[i] - est[i]) < 1e-6]
    if est[3] > 0.99 * hi[3]:
        at_bound.append("t_launch")
    if at_bound:
        warn.append(f"estimate at a physical bound for {at_bound}: Wald interval invalid for those parameters")
    if cfg.memory.ecc_enabled:
        warn.append("hbm_efficiency absorbs the ECC bandwidth overhead (not separable from achieved-bandwidth efficiency)")
    return PerfFit(dict(zip(names, map(float, est[:3]))), ci, float(est[3]), float(np.sqrt(np.mean(best.fun ** 2))),
                   cond, d[:, :3], fixed, info, len(lat), warn)


def apply_perf_fit(cfg: SimConfig, fit: PerfFit, source: str) -> None:
    for n, v in fit.params.items():
        if n in fit.fixed:
            continue
        sect = cfg.memory if n == "hbm_efficiency" else cfg.compute
        setattr(sect, n, v)
        record(cfg, ("memory." if n == "hbm_efficiency" else "compute.") + n, source=source,
               method="log-latency least squares + Wald/MVN", value=v, ci=fit.ci95[n],
               note=f"log rms {fit.log_rms:.3f}, informative points {fit.informative[n]}")
    if cfg.memory.ecc_enabled and "hbm_efficiency" not in fit.fixed:
        record(cfg, "memory.ecc_bw_overhead_pct", source=source, method="absorbed into hbm_efficiency", status="absorbed",
               value=cfg.memory.ecc_bw_overhead_pct)


def suggest_gemm_shapes(cfg: SimConfig) -> List[dict]:
    """Microbenchmark set spanning the regimes the three performance parameters are sensitive to.
    Check it against YOUR chip with ``design_coverage`` before spending bench time."""
    A = cfg.compute.array_size
    out = []
    for K in (A // 4, A // 2, A):                                  # shallow-K, many tiles -> pipeline_overlap
        out.append(dict(M=8 * A, K=K, N=8 * A, dtype="int8", sparsity=0.0))
    for M in (1, 8, 32, 128):                                       # skinny / weight-streaming -> hbm_efficiency
        out.append(dict(M=M, K=16 * A, N=16 * A, dtype="int8", sparsity=0.0))
    for K in (32 * A, 96 * A, 160 * A):                             # large, deep, compute-bound dense+sparse pairs
        for sp in (0.0, 0.5):
            out.append(dict(M=16 * A, K=K, N=16 * A, dtype="int8", sparsity=sp))
    for s in (A // 2, A):                                           # tiny: fixed launch overhead
        out.append(dict(M=s, K=s, N=s, dtype="int8", sparsity=0.0))
    return out


def design_coverage(cfg: SimConfig, shapes: Optional[Sequence[dict]] = None, freq_ghz: Optional[float] = None,
                    min_informative: int = 3) -> Dict[str, int]:
    """Number of benchmark shapes informative about each performance parameter on this chip (0 => unidentifiable)."""
    shapes = list(shapes if shapes is not None else suggest_gemm_shapes(cfg))
    f = freq_ghz or cfg.dvfs.nom_freq_ghz
    meas = [PerfMeasurement(s["M"], s["K"], s["N"], s["dtype"], s["sparsity"], f, 1.0) for s in shapes]
    return regime_counts(meas, cfg)
