"""Placeholder registry and provenance ledger.

``SimConfig.calibration`` maps a dotted parameter path to a provenance entry.  ``placeholder_audit`` compares the set of
parameters the physics depends on against that ledger, so "which numbers in this run are still guesses?" always has a
machine-checkable answer.  ``require_calibrated`` lets a study refuse to run with unresolved placeholders.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional

import numpy as np

from ..config import SimConfig

REGIONS = ("sram", "register", "logic_set", "sel")
KINDS = ("ion", "proton")
XS_PARAMS = ("sigma_sat_cm2", "x_th", "width", "shape")

STATUS_RESOLVED = ("measured", "derived", "design_fact", "absorbed")
STATUS_ACCEPTED = "accepted_placeholder"


class UncalibratedError(RuntimeError):
    pass


def get_by_path(cfg: Any, path: str):
    obj = cfg
    for part in path.split("."):
        obj = getattr(obj, part)
    return obj


def set_by_path(cfg: Any, path: str, value) -> None:
    *head, last = path.split(".")
    obj = cfg
    for part in head:
        obj = getattr(obj, part)
    if not hasattr(obj, last):
        raise AttributeError(f"no config parameter '{path}'")
    setattr(obj, last, value)


def _jsonable(v):
    if isinstance(v, (np.floating, np.integer)):
        return v.item()
    if isinstance(v, (list, tuple)):
        return [_jsonable(a) for a in v]
    return v


def record(cfg: SimConfig, path: str, *, source: str, method: str, status: str = "measured",
           value=None, ci: Optional[Iterable[float]] = None, note: str = "") -> None:
    if status not in STATUS_RESOLVED + (STATUS_ACCEPTED,):
        raise ValueError(f"unknown status '{status}'")
    cfg.calibration[path] = {
        "source": source, "method": method, "status": status,
        "value": _jsonable(value if value is not None else _safe_get(cfg, path)),
        "ci95": None if ci is None else [float(c) for c in ci], "note": note}


def _safe_get(cfg, path):
    try:
        v = get_by_path(cfg, path)
        return v if isinstance(v, (int, float, str, bool)) else None
    except AttributeError:
        return None


def declare(cfg: SimConfig, path: str, value, source: str, status: str = "design_fact") -> None:
    """Set a parameter that is a known design fact (netlist, datasheet, ops decision) and record where it came from."""
    set_by_path(cfg, path, value)
    record(cfg, path, source=source, method="declared", status=status, value=value)


def accept_placeholder(cfg: SimConfig, path: str, reason: str) -> None:
    """Explicitly keep a placeholder value, with a reason.  Still reported as unresolved by strict audits."""
    record(cfg, path, source="analyst", method="accepted", status=STATUS_ACCEPTED, note=reason)


def required_paths(cfg: SimConfig) -> List[str]:
    paths: List[str] = []
    for r in REGIONS:
        for k in KINDS:
            if getattr(getattr(cfg.radiation, r), k).sigma_sat_cm2 > 0:      # sigma_sat == 0 => mechanism not modelled
                paths += [f"radiation.{r}.{k}.{p}" for p in XS_PARAMS]
    paths += ["radiation.environment", "radiation.shield_mm_al", "radiation.shield_atten_len_mm",
              "radiation.mbu_prob", "radiation.mbu_max_cluster", "radiation.mbu_cluster_geom_p",
              "radiation.avf_sram", "radiation.avf_register", "radiation.avf_logic",
              "radiation.gates_per_pe", "radiation.reg_bits_per_pe", "radiation.set_pulse_width_ps",
              "radiation.sel_recovery_s",
              "orbital.sep_events_per_year", "orbital.sep_mean_duration_s",
              "orbital.sep_intensity_median", "orbital.sep_intensity_log_sigma",
              "power.base_power_w", "power.static_frac", "power.clock_frac", "power.interconnect_frac",
              "power.leak_temp_coeff", "power.interconnect_extra_exponent",
              "thermal.capacitance_j_per_k", "thermal.radiator_area_m2", "thermal.sun_projected_fraction",
              "thermal.earth_view_fraction", "thermal.albedo_geometry",
              "compute.sparse_speedup_at_50", "compute.pipeline_overlap", "memory.hbm_efficiency"]
    if cfg.memory.ecc_enabled:
        paths.append("memory.ecc_bw_overhead_pct")
    if cfg.radiation.tmr_enabled:
        paths.append("radiation.tmr_residual")
    return paths


@dataclass
class AuditResult:
    resolved: Dict[str, dict] = field(default_factory=dict)
    accepted: Dict[str, dict] = field(default_factory=dict)
    unresolved: List[str] = field(default_factory=list)

    @property
    def n_total(self) -> int:
        return len(self.resolved) + len(self.accepted) + len(self.unresolved)

    def render(self) -> str:
        lines = [f"{len(self.resolved)}/{self.n_total} parameters calibrated or declared, "
                 f"{len(self.accepted)} accepted placeholders, {len(self.unresolved)} UNRESOLVED"]
        lines += [f"  UNRESOLVED  {p}" for p in self.unresolved]
        lines += [f"  accepted    {p}  ({e['note']})" for p, e in self.accepted.items()]
        return "\n".join(lines)


def placeholder_audit(cfg: SimConfig) -> AuditResult:
    res = AuditResult()
    for p in required_paths(cfg):
        e = cfg.calibration.get(p)
        if e is None:
            res.unresolved.append(p)
        elif e["status"] == STATUS_ACCEPTED:
            res.accepted[p] = e
        else:
            res.resolved[p] = e
    return res


def require_calibrated(cfg: SimConfig, paths: Optional[Iterable[str]] = None, allow_accepted: bool = False) -> None:
    """Raise ``UncalibratedError`` if any of ``paths`` (default: every required path) is still a placeholder."""
    a = placeholder_audit(cfg)
    wanted = set(paths) if paths is not None else None
    bad = [p for p in a.unresolved if wanted is None or p in wanted]
    if not allow_accepted:
        bad += [p for p in a.accepted if wanted is None or p in wanted]
    if bad:
        raise UncalibratedError(f"{len(bad)} placeholder parameter(s) unresolved: {sorted(bad)[:8]}"
                                + (" ..." if len(bad) > 8 else ""))
