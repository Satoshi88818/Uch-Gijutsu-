"""Calibration data schemas and strict, validated CSV loaders.

Every loader rejects malformed input with ``CalibrationDataError`` and a message naming the file,
row and column: a calibration silently built on a mis-parsed table is worse than none.
"""
from __future__ import annotations

import csv
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from ..config import DType, SpectrumTable


class CalibrationDataError(ValueError):
    """Raised for malformed, physically impossible or insufficient calibration data."""


MAX_TILT_DEG = 60.0   # the 1/cos(theta) effective-LET law is not trustworthy beyond ~60 deg


def effective_let(let_normal: float, tilt_deg: float = 0.0) -> float:
    """Cosine-law effective LET.  ``tilt_deg`` = angle between beam and surface normal."""
    if not 0.0 <= tilt_deg <= MAX_TILT_DEG:
        raise CalibrationDataError(f"tilt {tilt_deg} deg outside [0, {MAX_TILT_DEG}] (cosine law invalid)")
    return let_normal / math.cos(math.radians(tilt_deg))


# ---------------------------------------------------------------------------
# Datasets
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class BeamPoint:
    """One beam run.  ``x`` = effective LET [MeV cm2/mg] (ions) or energy [MeV] (protons);
    ``fluence_cm2`` = fluence through the DEVICE SURFACE (already cos-corrected for tilt);
    ``events`` = observed upsets summed over ``n_units`` identical units (bits / FFs / gates / devices)."""
    x: float
    fluence_cm2: float
    events: int
    n_units: float = 1.0


@dataclass(frozen=True)
class BeamDataset:
    name: str
    region: str                 # sram | register | logic_set | sel
    kind: str                   # ion | proton
    points: Tuple[BeamPoint, ...]

    def __post_init__(self):
        if self.region not in ("sram", "register", "logic_set", "sel"):
            raise CalibrationDataError(f"{self.name}: unknown region '{self.region}'")
        if self.kind not in ("ion", "proton"):
            raise CalibrationDataError(f"{self.name}: kind must be 'ion' or 'proton'")
        for i, p in enumerate(self.points):
            if not (math.isfinite(p.x) and p.x > 0):
                raise CalibrationDataError(f"{self.name} point {i}: x must be positive and finite")
            if not (math.isfinite(p.fluence_cm2) and p.fluence_cm2 > 0):
                raise CalibrationDataError(f"{self.name} point {i}: fluence must be positive")
            if p.events < 0 or int(p.events) != p.events:
                raise CalibrationDataError(f"{self.name} point {i}: events must be a non-negative integer")
            if not (math.isfinite(p.n_units) and p.n_units > 0):
                raise CalibrationDataError(f"{self.name} point {i}: n_units must be positive")


@dataclass(frozen=True)
class PowerMeasurement:
    T_k: float
    f_ghz: float
    v_v: float
    util: float
    power_w: float


@dataclass(frozen=True)
class ThermalSample:
    """Row i describes the interval ENDING at t_s (backward-looking): mean power and eclipse state over
    that interval, and the temperature at t_s.  The first row is the initial condition (power ignored)."""
    t_s: float
    power_w: float
    eclipse: bool
    T_k: float


@dataclass(frozen=True)
class PerfMeasurement:
    M: int
    K: int
    N: int
    dtype: str
    sparsity: float
    freq_ghz: float
    latency_s: float


@dataclass(frozen=True)
class MbuDataset:
    name: str
    counts: Dict[int, int]          # cluster size (bits flipped per strike) -> number of strikes


@dataclass(frozen=True)
class SepCatalog:
    name: str
    obs_span_s: float
    durations_s: Tuple[float, ...]
    intensities_rel: Tuple[float, ...]    # peak intensity relative to the reference event in the SEP tables


@dataclass(frozen=True)
class FlightLog:
    """Upsets counted by on-board EDAC over known exposure.  ``cfg.orbital`` must describe the flight orbit."""
    name: str
    region: str
    n_units: float
    segments: Tuple[Tuple[float, float], ...]          # (t0_s, t1_s) of valid monitoring
    events: int
    flare_events: Tuple[Tuple[float, float, float], ...] = ()   # (start_s, end_s, intensity) from SEP catalogue


@dataclass
class AvfRequest:
    field: str = "avf_sram"
    dtype: str = "int8"
    tol: float = 1e-2
    trials_per_bit: int = 100
    shape: Tuple[int, int, int] = (32, 32, 32)


@dataclass
class DesignFact:
    path: str
    value: object
    source: str


@dataclass
class CalibrationData:
    env_tables: Dict[str, SpectrumTable] = field(default_factory=dict)
    env_source: str = ""
    beam: List[BeamDataset] = field(default_factory=list)
    mbu: Optional[MbuDataset] = None
    sep: Optional[SepCatalog] = None
    power: List[PowerMeasurement] = field(default_factory=list)
    power_source: str = "power measurements"
    thermal: List[ThermalSample] = field(default_factory=list)
    thermal_source: str = "thermal telemetry"
    perf: List[PerfMeasurement] = field(default_factory=list)
    perf_source: str = "performance microbenchmarks"
    flight: List[FlightLog] = field(default_factory=list)
    avf: List[AvfRequest] = field(default_factory=list)
    design_facts: List[DesignFact] = field(default_factory=list)


# ---------------------------------------------------------------------------
# CSV loading
# ---------------------------------------------------------------------------
def _rows(path, required: Sequence[str], optional: Sequence[str] = ()):
    path = Path(path)
    if not path.exists():
        raise CalibrationDataError(f"{path}: file not found")
    with open(path, newline="") as fh:
        lines = [ln for ln in fh if ln.strip() and not ln.lstrip().startswith("#")]
    if not lines:
        raise CalibrationDataError(f"{path}: empty")
    rd = csv.DictReader(lines)
    header = [h.strip() for h in (rd.fieldnames or [])]
    missing = [c for c in required if c not in header]
    if missing:
        raise CalibrationDataError(f"{path}: missing column(s) {missing}; found {header}")
    out = []
    for i, row in enumerate(rd, start=2):
        row = {k.strip(): (v.strip() if v is not None else "") for k, v in row.items() if k}
        out.append((i, row))
    if not out:
        raise CalibrationDataError(f"{path}: no data rows")
    return path, out


def _num(path, i, row, col, default=None, integer=False):
    raw = row.get(col, "")
    if raw == "":
        if default is not None:
            return default
        raise CalibrationDataError(f"{path} row {i}: column '{col}' is empty")
    try:
        v = float(raw)
    except ValueError:
        raise CalibrationDataError(f"{path} row {i}: column '{col}' = '{raw}' is not a number") from None
    if not math.isfinite(v):
        raise CalibrationDataError(f"{path} row {i}: column '{col}' is not finite")
    if integer:
        if v != int(v):
            raise CalibrationDataError(f"{path} row {i}: column '{col}' = {raw} must be an integer")
        return int(v)
    return v


def load_beam_csv(path, region: str, kind: str, name: Optional[str] = None) -> BeamDataset:
    """ion   : let_mev_cm2_mg, fluence_cm2, events [, tilt_deg, n_units]   (fluence = beam fluence normal to the beam;
               it is converted to surface fluence F*cos(theta) and LET to LET/cos(theta))
       proton: energy_mev,     fluence_cm2, events [, n_units]"""
    xcol = "let_mev_cm2_mg" if kind == "ion" else "energy_mev"
    path, rows = _rows(path, [xcol, "fluence_cm2", "events"])
    pts = []
    for i, r in rows:
        x = _num(path, i, r, xcol)
        fl = _num(path, i, r, "fluence_cm2")
        ev = _num(path, i, r, "events", integer=True)
        nu = _num(path, i, r, "n_units", default=1.0)
        if kind == "ion":
            tilt = _num(path, i, r, "tilt_deg", default=0.0)
            x = effective_let(x, tilt)
            fl = fl * math.cos(math.radians(tilt))
        pts.append(BeamPoint(x, fl, ev, nu))
    return BeamDataset(name or Path(path).stem, region, kind, tuple(pts))


def load_power_csv(path) -> List[PowerMeasurement]:
    path, rows = _rows(path, ["T_k", "f_ghz", "v_v", "util", "power_w"])
    out = []
    for i, r in rows:
        m = PowerMeasurement(*(_num(path, i, r, c) for c in ("T_k", "f_ghz", "v_v", "util", "power_w")))
        if not (m.T_k > 0 and m.f_ghz > 0 and m.v_v > 0 and 0 <= m.util <= 1 and m.power_w > 0):
            raise CalibrationDataError(f"{path} row {i}: physically impossible values {m}")
        out.append(m)
    return out


def load_thermal_csv(path) -> List[ThermalSample]:
    path, rows = _rows(path, ["t_s", "power_w", "eclipse", "T_k"])
    out, last = [], -math.inf
    for i, r in rows:
        t = _num(path, i, r, "t_s")
        if t <= last:
            raise CalibrationDataError(f"{path} row {i}: t_s must be strictly increasing")
        last = t
        ecl = r["eclipse"].lower() in ("1", "true", "yes", "t")
        if r["eclipse"].lower() not in ("0", "1", "true", "false", "yes", "no", "t", "f"):
            raise CalibrationDataError(f"{path} row {i}: eclipse must be 0/1/true/false")
        T = _num(path, i, r, "T_k")
        if T <= 0:
            raise CalibrationDataError(f"{path} row {i}: T_k must be positive")
        out.append(ThermalSample(t, _num(path, i, r, "power_w"), ecl, T))
    if len(out) < 10:
        raise CalibrationDataError(f"{path}: need >= 10 samples, got {len(out)}")
    return out


def load_perf_csv(path) -> List[PerfMeasurement]:
    path, rows = _rows(path, ["M", "K", "N", "dtype", "sparsity", "freq_ghz", "latency_s"])
    valid = {d.label for d in DType}
    out = []
    for i, r in rows:
        if r["dtype"] not in valid:
            raise CalibrationDataError(f"{path} row {i}: dtype '{r['dtype']}' not in {sorted(valid)}")
        sp = _num(path, i, r, "sparsity")
        if sp not in (0.0, 0.5):
            raise CalibrationDataError(f"{path} row {i}: sparsity must be 0 or 0.5")
        lat = _num(path, i, r, "latency_s")
        if lat <= 0:
            raise CalibrationDataError(f"{path} row {i}: latency must be positive")
        out.append(PerfMeasurement(_num(path, i, r, "M", integer=True), _num(path, i, r, "K", integer=True),
                                   _num(path, i, r, "N", integer=True), r["dtype"], sp,
                                   _num(path, i, r, "freq_ghz"), lat))
    return out


def load_spectrum_csv(path) -> SpectrumTable:
    path, rows = _rows(path, ["x", "phi_integral"])
    x = [_num(path, i, r, "x") for i, r in rows]
    ph = [_num(path, i, r, "phi_integral") for i, r in rows]
    tab = SpectrumTable(x, ph)
    import numpy as np
    if not (np.all(np.diff(x) > 0) and np.all(np.diff(ph) <= 0) and min(ph) >= 0 and min(x) > 0):
        raise CalibrationDataError(f"{path}: x must be positive ascending and Phi(>x) non-negative, non-increasing")
    return tab


def load_mbu_csv(path, name: Optional[str] = None) -> MbuDataset:
    path, rows = _rows(path, ["cluster_size", "count"])
    counts: Dict[int, int] = {}
    for i, r in rows:
        m = _num(path, i, r, "cluster_size", integer=True)
        c = _num(path, i, r, "count", integer=True)
        if m < 1 or c < 0:
            raise CalibrationDataError(f"{path} row {i}: cluster_size >= 1 and count >= 0 required")
        counts[m] = counts.get(m, 0) + c
    return MbuDataset(name or Path(path).stem, counts)


def load_sep_csv(path, obs_span_s: float, name: Optional[str] = None) -> SepCatalog:
    path, rows = _rows(path, ["duration_s", "intensity_rel"])
    d = tuple(_num(path, i, r, "duration_s") for i, r in rows)
    it = tuple(_num(path, i, r, "intensity_rel") for i, r in rows)
    if min(d) <= 0 or min(it) <= 0 or obs_span_s <= 0:
        raise CalibrationDataError(f"{path}: durations, intensities and obs_span_s must be positive")
    return SepCatalog(name or Path(path).stem, float(obs_span_s), d, it)
