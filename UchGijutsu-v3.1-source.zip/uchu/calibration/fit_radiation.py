"""Radiation-side calibration.

  * ``fit_cross_section``   Poisson maximum-likelihood Weibull sigma(x) from beam-test counts, parametric-bootstrap
                            uncertainty (negative-binomial resampling when over-dispersed), deviance goodness-of-fit
  * ``fit_mbu``             closed-form MLE of the MBU probability and truncated-geometric cluster-size law
  * ``fit_sep_statistics``  SEP-event rate / duration / intensity law from an event catalogue
  * spectrum tools          power-law fit to a CREME/OMERE table, installation of orbit-specific tables
  * flight update           importance-reweighting of the beam-derived parameter draws by on-orbit EDAC counts
  * ``calibrate_avf``       measured architectural vulnerability from real bit-flip fault injection
"""
from __future__ import annotations

import math
import warnings
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from scipy import stats
from scipy.optimize import least_squares, minimize

from ..config import CrossSection, SimConfig, SpectrumParams, SpectrumTable
from ..faults import measure_gemm_vulnerability
from ..orbit import FlareSchedule, OrbitalEnvironment
from ..radiation import RadiationEnvironment
from ..stats import wilson_ci
from .data import BeamDataset, CalibrationDataError, MbuDataset, SepCatalog
from .registry import record

PARAMS = ("sigma_sat_cm2", "x_th", "width", "shape")


# ===========================================================================
# 1.  Weibull cross-section MLE
# ===========================================================================
def _mu(theta: np.ndarray, x: np.ndarray, nF: np.ndarray) -> np.ndarray:
    sig, xth, w, s = theta
    z = np.clip((x - xth) / w, 0.0, None)
    return sig * (1.0 - np.exp(-np.power(z, s))) * nF


def _nll(mu: np.ndarray, k: np.ndarray) -> float:
    mu = np.maximum(mu, 1e-300)
    return float(np.sum(mu - k * np.log(mu)))


def _deviance(mu: np.ndarray, k: np.ndarray) -> float:
    mu = np.maximum(mu, 1e-300)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = np.where(k > 0, k * np.log(np.maximum(k, 1.0) / mu), 0.0)
    return float(2.0 * np.sum(t - (k - mu)))


@dataclass
class CrossSectionFit:
    dataset: str
    region: str
    kind: str
    xs: CrossSection
    params: Dict[str, float]
    ci95: Dict[str, Tuple[float, float]]
    samples: np.ndarray                      # (B, 4) bootstrap draws in natural units [sigma_sat, x_th, width, shape]
    deviance: float
    dof: int
    p_value: float
    dispersion: float
    overdispersed: bool
    n_points: int
    n_events: int
    fixed: Dict[str, float]
    warnings: List[str] = field(default_factory=list)

    def draw(self, i: int) -> CrossSection:
        s = self.samples[i % len(self.samples)]
        return CrossSection(float(s[0]), float(s[1]), float(s[2]), float(s[3]))


class _Problem:
    """Bounds + parametrisation shared by the point fit and every bootstrap refit."""

    def __init__(self, x, nF, k, fixed, shape_bounds, x_th_bounds):
        self.x, self.nF, self.k, self.fixed = x, nF, k, dict(fixed)
        sig_meas = k / nF
        sig_max = float(sig_meas.max())
        x_first = float(x[k > 0].min())
        lo_xth = x_th_bounds[0] if x_th_bounds else float(x.min()) / 20.0
        hi_xth = x_first * (1 - 1e-6)
        rng_x = float(x.max() - x.min())
        self.bounds = {
            "sigma_sat_cm2": (0.3 * sig_max, 1e3 * sig_max),
            "x_th": (min(lo_xth, hi_xth * 0.999), hi_xth),
            "width": (max(0.01 * rng_x, 1e-6), 20.0 * float(x.max())),
            "shape": shape_bounds,
        }
        self.free = [p for p in PARAMS if p not in self.fixed]
        self.sig_max, self.x_first, self.rng_x = sig_max, x_first, rng_x

    def expand(self, u: np.ndarray) -> np.ndarray:
        th = dict(self.fixed)
        th.update({p: math.exp(v) for p, v in zip(self.free, u)})
        return np.array([th[p] for p in PARAMS])

    def to_u(self, theta: np.ndarray) -> np.ndarray:
        d = dict(zip(PARAMS, theta))
        return np.array([math.log(d[p]) for p in self.free])

    @property
    def ubounds(self):
        return [(math.log(self.bounds[p][0]), math.log(self.bounds[p][1])) for p in self.free]

    def with_counts(self, k):
        c = _Problem.__new__(_Problem)
        c.__dict__.update(self.__dict__)
        c.k = k
        return c

    def nll(self, u):
        return _nll(_mu(self.expand(u), self.x, self.nF), self.k)


def _local(prob: _Problem, u0: np.ndarray) -> Tuple[np.ndarray, float]:
    r = minimize(prob.nll, u0, method="L-BFGS-B", bounds=prob.ubounds,
                 options={"ftol": 1e-13, "gtol": 1e-9, "maxiter": 600})
    return r.x, float(r.fun)


def _global(prob: _Problem, rng: np.random.Generator, n_random: int = 14) -> Tuple[np.ndarray, float]:
    ub = prob.ubounds
    lo, hi = np.array([b[0] for b in ub]), np.array([b[1] for b in ub])
    starts = []
    for sh in (1.0, 2.0, 3.0):
        for wf in (0.15, 0.5):
            th = {"sigma_sat_cm2": 1.1 * prob.sig_max, "x_th": 0.8 * prob.x_first,
                  "width": wf * prob.rng_x, "shape": sh}
            th.update(prob.fixed)
            th = {p: float(np.clip(th[p], *prob.bounds[p])) for p in PARAMS}
            starts.append(prob.to_u(np.array([th[p] for p in PARAMS])))
    starts += [rng.uniform(lo, hi) for _ in range(n_random)]
    scored = sorted(((prob.nll(u), i) for i, u in enumerate(starts)))[:6]
    best_u, best_f = None, math.inf
    for _, i in scored:
        u, f = _local(prob, np.clip(starts[i], lo, hi))
        if f < best_f:
            best_u, best_f = u, f
    return best_u, best_f


def fit_cross_section(ds: BeamDataset, rng: np.random.Generator, n_boot: int = 200,
                      fix: Optional[Dict[str, float]] = None, shape_bounds=(0.5, 6.0),
                      x_th_bounds: Optional[Tuple[float, float]] = None) -> CrossSectionFit:
    pts = ds.points
    if len(pts) < 4:
        raise CalibrationDataError(f"{ds.name}: need >= 4 beam points, got {len(pts)}")
    x = np.array([p.x for p in pts], float)
    nF = np.array([p.n_units * p.fluence_cm2 for p in pts], float)
    k = np.array([p.events for p in pts], float)
    if k.sum() == 0:
        raise CalibrationDataError(f"{ds.name}: zero events at every point; only an upper limit exists "
                                   f"(sigma < {3.0 / nF.max():.3g} cm2/unit at 95 %), not a Weibull fit")
    fixed = dict(fix or {})
    prob = _Problem(x, nF, k, fixed, shape_bounds, x_th_bounds)
    warn: List[str] = []
    n_free = len(prob.free)
    if len(np.unique(x)) < n_free + 1:
        warn.append(f"only {len(np.unique(x))} distinct x values for {n_free} free parameters: poorly constrained")

    u_hat, _ = _global(prob, rng)
    theta = prob.expand(u_hat)
    mu_hat = _mu(theta, x, nF)
    D = _deviance(mu_hat, k)
    dof = len(x) - n_free
    phi = D / dof if dof > 0 else float("nan")

    def bootstrap(draw_counts) -> Tuple[np.ndarray, np.ndarray]:
        thetas, devs = [], []
        for _ in range(n_boot):
            kb = draw_counts()
            if kb.sum() == 0:
                continue
            pb = prob.with_counts(kb)
            cands = [_local(pb, u_hat), _local(pb, np.clip(u_hat + rng.normal(0, 0.25, len(u_hat)),
                                                           [b[0] for b in prob.ubounds], [b[1] for b in prob.ubounds]))]
            ub, _ = min(cands, key=lambda c: c[1])
            th_b = pb.expand(ub)
            thetas.append(th_b)
            devs.append(_deviance(_mu(th_b, x, nF), kb))
        return np.array(thetas), np.array(devs)

    th1, d1 = bootstrap(lambda: rng.poisson(mu_hat).astype(float))
    if len(d1) < 0.5 * n_boot:
        raise CalibrationDataError(f"{ds.name}: bootstrap degenerate ({len(d1)}/{n_boot} usable draws)")
    p_val = float((1 + np.sum(d1 >= D)) / (len(d1) + 1)) if dof > 0 else float("nan")
    overdisp = bool(dof > 0 and p_val < 0.05)
    samples = th1
    if overdisp:
        g = max(phi, 1.0 + 1e-6)
        warn.append(f"over-dispersed (deviance/dof = {phi:.2f}, bootstrap p = {p_val:.3f}): the Poisson model does not "
                    f"explain the scatter (fluence/dosimetry errors? SEL/SEFI contamination?). Intervals widened with a "
                    f"negative-binomial resample; investigate before trusting the point estimate.")
        th2, _ = bootstrap(lambda: rng.poisson(rng.gamma(np.maximum(mu_hat, 1e-12) / (g - 1.0), g - 1.0)).astype(float))
        samples = th2
    frac_trans = float(np.mean((mu_hat > 0.02 * theta[0] * nF) & (mu_hat < 0.95 * theta[0] * nF)))
    if np.sum((mu_hat > 0.02 * theta[0] * nF) & (mu_hat < 0.95 * theta[0] * nF)) < 3:
        warn.append("fewer than 3 points on the rising part of the curve: width/shape poorly constrained")
    frac_sat = float(1.0 - math.exp(-max((x.max() - theta[1]) / theta[2], 0.0) ** theta[3]))
    if frac_sat < 0.9:
        warn.append(f"saturation not reached within the tested range (fitted curve is at {frac_sat:.0%} of sigma_sat at the "
                    f"largest tested x): sigma_sat is an extrapolation")
    sat_spread = np.percentile(samples[:, 0], 97.5) / max(np.percentile(samples[:, 0], 2.5), 1e-300)
    if sat_spread > 3.0:
        warn.append(f"sigma_sat 95 % interval spans a factor {sat_spread:.1f}")
    at_bound = [p for p, v in zip(PARAMS, theta) if p in prob.free and
                (abs(math.log(v) - math.log(prob.bounds[p][0])) < 1e-3 or abs(math.log(v) - math.log(prob.bounds[p][1])) < 1e-3)]
    if at_bound:
        warn.append(f"estimate sits on a search bound for {at_bound}: constrain it physically or collect more data")

    lo, hi = np.percentile(samples, [2.5, 97.5], axis=0)
    return CrossSectionFit(
        dataset=ds.name, region=ds.region, kind=ds.kind,
        xs=CrossSection(*[float(v) for v in theta]), params=dict(zip(PARAMS, map(float, theta))),
        ci95={p: (float(lo[i]), float(hi[i])) for i, p in enumerate(PARAMS)}, samples=samples,
        deviance=D, dof=dof, p_value=p_val, dispersion=phi, overdispersed=overdisp,
        n_points=len(x), n_events=int(k.sum()), fixed=fixed, warnings=warn)


def apply_cross_section_fit(cfg: SimConfig, fit: CrossSectionFit, source: Optional[str] = None) -> None:
    reg = getattr(cfg.radiation, fit.region)
    setattr(reg, fit.kind, CrossSection(**fit.params))
    for p in PARAMS:
        status = "derived" if p in fit.fixed else "measured"
        record(cfg, f"radiation.{fit.region}.{fit.kind}.{p}", source=source or fit.dataset,
               method="Poisson MLE (Weibull) + parametric bootstrap", status=status, value=fit.params[p],
               ci=fit.ci95[p], note=f"deviance/dof={fit.dispersion:.2f}, p={fit.p_value:.3f}" + (
                   "; OVERDISPERSED" if fit.overdispersed else ""))


def cross_section_upper_limit(events: int, fluence_cm2: float, n_units: float = 1.0, conf: float = 0.95) -> float:
    """One-sided upper limit on sigma per unit when ``events`` were seen (3 / (nF) for zero events at 95 %)."""
    return float(stats.chi2.ppf(conf, 2 * (events + 1)) / 2.0 / (fluence_cm2 * n_units))


# ===========================================================================
# 2.  MBU multiplicity
# ===========================================================================
@dataclass
class MbuFit:
    dataset: str
    p_mbu: float
    p_mbu_ci95: Tuple[float, float]
    geom_p: float
    geom_p_ci95: Tuple[float, float]
    max_cluster: int
    n_strikes: int
    chi2_p_value: float
    p_samples: np.ndarray
    q_samples: np.ndarray
    warnings: List[str] = field(default_factory=list)


def _cluster_pmf(q: float, max_cluster: int) -> np.ndarray:
    """P(size = m | MBU), m = 2..max_cluster, truncated geometric (matches RadiationSubsystem._cluster_sizes)."""
    m = np.arange(2, max_cluster + 1)
    pmf = q * (1 - q) ** (m - 2)
    pmf[-1] = (1 - q) ** (max_cluster - 2)
    return pmf


def fit_mbu(ds: MbuDataset, rng: np.random.Generator, max_cluster: Optional[int] = None, n_draw: int = 500) -> MbuFit:
    counts = {int(m): int(c) for m, c in ds.counts.items() if c > 0}
    N = sum(counts.values())
    if N < 20:
        raise CalibrationDataError(f"{ds.name}: need >= 20 strikes, got {N}")
    n_multi = sum(c for m, c in counts.items() if m >= 2)
    if n_multi < 5:
        raise CalibrationDataError(f"{ds.name}: only {n_multi} multi-bit strikes; cluster law not identifiable")
    M = int(max_cluster or max(counts))
    if M < 2:
        raise CalibrationDataError("max_cluster must be >= 2")
    warn: List[str] = []
    if any(m > M for m in counts):
        raise CalibrationDataError(f"{ds.name}: observed cluster size > max_cluster={M}")
    p = n_multi / N
    n_stop = sum(c for m, c in counts.items() if 2 <= m < M)          # geometric "success" events
    n_cont = sum(c * (m - 2) for m, c in counts.items() if m >= 2)    # geometric "failure" events
    q = n_stop / (n_stop + n_cont) if (n_stop + n_cont) > 0 else 1.0
    q = min(max(q, 1e-6), 1.0)
    q_ci = wilson_ci(n_stop, n_stop + n_cont) if n_stop + n_cont > 0 else (0.0, 1.0)
    exp = np.array([n_multi * v for v in _cluster_pmf(q, M)])
    obs = np.array([counts.get(m, 0) for m in range(2, M + 1)], float)
    # pool bins with expected < 5 into the last bin
    while len(exp) > 2 and exp[-1] < 5:
        exp[-2] += exp[-1]; obs[-2] += obs[-1]; exp, obs = exp[:-1], obs[:-1]
    dof = len(exp) - 2
    pval = float(stats.chi2.sf(np.sum((obs - exp) ** 2 / np.maximum(exp, 1e-12)), dof)) if dof > 0 else float("nan")
    if max(counts) == M and counts.get(M, 0) > 0:
        warn.append(f"largest observed cluster ({M}) is the truncation point: the tail beyond it is unobserved")
    if q_ci[1] - q_ci[0] > 0.4:
        warn.append("cluster-size law poorly constrained (few multi-bit strikes)")
    return MbuFit(ds.name, p, wilson_ci(n_multi, N), q, q_ci, M, N, pval,
                  rng.beta(n_multi + 0.5, N - n_multi + 0.5, size=n_draw),
                  rng.beta(n_stop + 0.5, n_cont + 0.5, size=n_draw), warn)


def apply_mbu_fit(cfg: SimConfig, fit: MbuFit) -> None:
    cfg.radiation.mbu_prob, cfg.radiation.mbu_cluster_geom_p = fit.p_mbu, fit.geom_p
    cfg.radiation.mbu_max_cluster = fit.max_cluster
    record(cfg, "radiation.mbu_prob", source=fit.dataset, method="binomial MLE + Wilson", value=fit.p_mbu, ci=fit.p_mbu_ci95)
    record(cfg, "radiation.mbu_cluster_geom_p", source=fit.dataset, method="truncated-geometric MLE + Wilson",
           value=fit.geom_p, ci=fit.geom_p_ci95, note=f"chi2 p={fit.chi2_p_value:.3f}")
    record(cfg, "radiation.mbu_max_cluster", source=fit.dataset, method="largest observed cluster", status="derived",
           value=fit.max_cluster)


# ===========================================================================
# 3.  SEP statistics
# ===========================================================================
@dataclass
class SepFit:
    dataset: str
    n_events: int
    rate_per_year: float
    rate_ci95: Tuple[float, float]
    mean_duration_s: float
    duration_ci95: Tuple[float, float]
    median_intensity: float
    median_ci95: Tuple[float, float]
    log_sigma: float
    log_sigma_ci95: Tuple[float, float]
    samples: np.ndarray            # (n, 4): rate/yr, mean_dur, median, log_sigma
    warnings: List[str] = field(default_factory=list)


def fit_sep_statistics(cat: SepCatalog, rng: np.random.Generator, n_draw: int = 500, conf: float = 0.95) -> SepFit:
    n = len(cat.durations_s)
    if n < 3:
        raise CalibrationDataError(f"{cat.name}: need >= 3 SEP events, got {n}")
    a = 1 - conf
    yr = 365.25 * 86400.0
    rate = n / cat.obs_span_s * yr
    r_lo = 0.5 * stats.chi2.ppf(a / 2, 2 * n) / cat.obs_span_s * yr
    r_hi = 0.5 * stats.chi2.ppf(1 - a / 2, 2 * (n + 1)) / cat.obs_span_s * yr
    d = np.asarray(cat.durations_s)
    dm = float(d.mean())
    d_ci = (2 * n * dm / stats.chi2.ppf(1 - a / 2, 2 * n), 2 * n * dm / stats.chi2.ppf(a / 2, 2 * n))
    li = np.log(np.asarray(cat.intensities_rel))
    mu, sd = float(li.mean()), float(li.std(ddof=1))
    tq = stats.t.ppf(1 - a / 2, n - 1) * sd / math.sqrt(n)
    s_ci = (sd * math.sqrt((n - 1) / stats.chi2.ppf(1 - a / 2, n - 1)), sd * math.sqrt((n - 1) / stats.chi2.ppf(a / 2, n - 1)))
    warn = []
    if n < 10:
        warn.append(f"only {n} SEP events: rate and intensity law are weakly constrained (heavy tail unobserved)")
    # draws: Jeffreys posterior for rate; inverse-gamma for mean duration; t / chi2 for lognormal
    rate_d = rng.gamma(n + 0.5, 1.0 / cat.obs_span_s, n_draw) * yr
    dur_d = (n * dm) / rng.gamma(n, 1.0, n_draw)
    sig_d = sd * np.sqrt((n - 1) / rng.chisquare(n - 1, n_draw))
    med_d = np.exp(mu + sig_d / math.sqrt(n) * rng.standard_t(n - 1, n_draw))
    return SepFit(cat.name, n, rate, (r_lo, r_hi), dm, d_ci, math.exp(mu), (math.exp(mu - tq), math.exp(mu + tq)),
                  sd, s_ci, np.column_stack([rate_d, dur_d, med_d, sig_d]), warn)


def apply_sep_fit(cfg: SimConfig, fit: SepFit) -> None:
    o = cfg.orbital
    o.sep_events_per_year, o.sep_mean_duration_s = fit.rate_per_year, fit.mean_duration_s
    o.sep_intensity_median, o.sep_intensity_log_sigma = fit.median_intensity, fit.log_sigma
    src = fit.dataset
    record(cfg, "orbital.sep_events_per_year", source=src, method="Poisson MLE (Garwood)", value=fit.rate_per_year, ci=fit.rate_ci95)
    record(cfg, "orbital.sep_mean_duration_s", source=src, method="exponential MLE", value=fit.mean_duration_s, ci=fit.duration_ci95)
    record(cfg, "orbital.sep_intensity_median", source=src, method="lognormal MLE", value=fit.median_intensity, ci=fit.median_ci95)
    record(cfg, "orbital.sep_intensity_log_sigma", source=src, method="lognormal MLE", value=fit.log_sigma, ci=fit.log_sigma_ci95)


# ===========================================================================
# 4.  Environment spectra
# ===========================================================================
@dataclass
class PowerLawFit:
    params: SpectrumParams
    max_rel_error: float
    warnings: List[str]


def fit_power_law_to_table(tab: SpectrumTable, x_lo: Optional[float] = None, x_hi: Optional[float] = None,
                           x_ref: float = 1.0) -> PowerLawFit:
    """Least-squares (log space) fit of Phi(>x) = A[(x/xr)^-g - (xm/xr)^-g] to a table, over [x_lo, x_hi).
    Use for sensitivity studies; prefer the table itself (``install_environment_tables``) for the baseline."""
    x, ph = np.asarray(tab.x), np.asarray(tab.phi_integral)
    x_lo = x_lo or x[0]
    x_hi = x_hi or x[-1] * 1.0000001
    m = (x >= x_lo) & (x < x_hi) & (ph > 0)
    if m.sum() < 4:
        raise CalibrationDataError("need >= 4 positive table points in the fitting range")
    xs, ys = x[m], np.log(ph[m])
    g0 = max(0.1, -np.polyfit(np.log(xs), ys, 1)[0])
    A0 = float(np.exp(np.polyval(np.polyfit(np.log(xs), ys, 1), np.log(x_ref))))

    def res(v):
        A, g = math.exp(v[0]), math.exp(v[1])
        model = A * ((xs / x_ref) ** -g - (x_hi / x_ref) ** -g)
        return np.log(np.maximum(model, 1e-300)) - ys
    r = least_squares(res, [math.log(A0), math.log(g0)])
    A, g = math.exp(r.x[0]), math.exp(r.x[1])
    err = float(np.max(np.abs(np.exp(res(r.x)) - 1.0)))
    w = []
    if err > 0.3:
        w.append(f"power law misses the table by up to {err:.0%}: use the table directly for baseline rates")
    return PowerLawFit(SpectrumParams(A, x_ref, g, float(x_hi)), err, w)


def check_table_coverage(cfg: SimConfig, tables: Dict[str, SpectrumTable]) -> List[str]:
    """Warn when a table starts above a cross-section threshold (flux below the table is assumed zero)."""
    out = []
    comp_x = {"gcr_ion": ("ion", "x_th"), "sep_ion": ("ion", "x_th"),
              "trapped_proton": ("proton", "x_th"), "sep_proton": ("proton", "x_th")}
    for key, tab in tables.items():
        kind = comp_x[key][0]
        for r in ("sram", "register", "logic_set", "sel"):
            xs = getattr(getattr(cfg.radiation, r), kind)
            if xs.sigma_sat_cm2 > 0 and tab.x[0] > xs.x_th:
                out.append(f"table '{key}' starts at x={tab.x[0]:.3g}, above {r}.{kind} threshold {xs.x_th:.3g}: "
                           f"flux below the table is treated as zero (non-conservative)")
    return out


def install_environment_tables(cfg: SimConfig, tables: Dict[str, SpectrumTable], source: str) -> List[str]:
    """Switch to orbit-specific tabulated spectra.  The tables must already include geomagnetic shielding,
    solar-cycle modulation, trapped-belt content and spacecraft shielding; ALL placeholder orbit scalings are bypassed.
    The ``sep_*`` tables describe the reference SEP event (intensity = 1)."""
    cfg.radiation.environment_mode = "tabulated_orbit"
    cfg.radiation.tables = {k: SpectrumTable(list(t.x), list(t.phi_integral)) for k, t in tables.items()}
    cfg.validate()
    record(cfg, "radiation.environment", source=source, method="orbit-specific tabulated flux (CREME96/OMERE/AP-9)",
           status="measured", value="tabulated_orbit", note="tables: " + ",".join(sorted(tables)))
    for p in ("radiation.shield_mm_al", "radiation.shield_atten_len_mm"):
        record(cfg, p, source=source, method="embedded in tabulated flux", status="absorbed", value=None,
               note="shielding applied when the tables were generated")
    return check_table_coverage(cfg, tables)


# ===========================================================================
# 5.  Flight-data update
# ===========================================================================
def expected_events_for_flight(cfg: SimConfig, region: str, n_units: float,
                               segments: Sequence[Tuple[float, float]],
                               flare_events: Sequence[Tuple[float, float, float]] = ()) -> float:
    orbit = OrbitalEnvironment(cfg.orbital)
    orbit.flares = FlareSchedule.from_events(flare_events)
    env = RadiationEnvironment(cfg, orbit)
    return float(sum(env.expected(region, n_units, t0, t1) for t0, t1 in segments))


@dataclass
class FlightUpdate:
    log: str
    observed: int
    expected_prior_mean: float
    weights: np.ndarray
    ess: float
    p_consistency: float
    posterior_multiplier_median: float
    posterior_multiplier_ci95: Tuple[float, float]
    warnings: List[str] = field(default_factory=list)


def weighted_quantile(values: np.ndarray, weights: np.ndarray, q: Sequence[float]) -> np.ndarray:
    o = np.argsort(values)
    v, w = values[o], weights[o]
    cw = np.cumsum(w) - 0.5 * w
    cw /= w.sum()
    return np.interp(q, cw, v)


def flight_update(E_draws: np.ndarray, k_obs: int, discrepancy_log_sigma: float = 0.0,
                  log: str = "flight", n_gh: int = 41) -> FlightUpdate:
    """Importance-reweight parameter draws (each predicting E_j expected events) by the flight count.
    ``discrepancy_log_sigma`` is a lognormal model-discrepancy nuisance (environment/geometry errors the beam data
    cannot know about); 0 trusts the model exactly."""
    E = np.asarray(E_draws, float)
    if discrepancy_log_sigma > 0:
        z, wz = np.polynomial.hermite_e.hermegauss(n_gh)
        delta = np.exp(discrepancy_log_sigma * z)
        wz = wz / wz.sum()
        mu = E[:, None] * delta[None, :]
        like = (stats.poisson.pmf(k_obs, mu) * wz[None, :]).sum(axis=1)
        cdf_le = (stats.poisson.cdf(k_obs, mu) * wz).sum(axis=1).mean()
        cdf_ge = (stats.poisson.sf(k_obs - 1, mu) * wz).sum(axis=1).mean()
    else:
        like = stats.poisson.pmf(k_obs, E)
        cdf_le, cdf_ge = stats.poisson.cdf(k_obs, E).mean(), stats.poisson.sf(k_obs - 1, E).mean()
    p_cons = float(min(1.0, 2.0 * min(cdf_le, cdf_ge)))
    w = like / like.sum() if like.sum() > 0 else np.full(len(E), 1.0 / len(E))
    ess = float(1.0 / np.sum(w ** 2))
    mult = E / np.mean(E)
    q = weighted_quantile(mult, w, [0.025, 0.5, 0.975])
    warn = []
    if p_cons < 0.01:
        warn.append(f"flight count {k_obs} is inconsistent with the beam-derived model (prior-predictive p = {p_cons:.2g}): "
                    f"suspect environment/shielding/geometry or SEE mechanisms absent from the beam data")
    if ess < 0.1 * len(E):
        warn.append(f"effective sample size {ess:.0f}/{len(E)}: flight data strongly disagree with most draws; "
                    f"increase draws or add a model-discrepancy term")
    return FlightUpdate(log, int(k_obs), float(np.mean(E)), w, ess, p_cons, float(q[1]), (float(q[0]), float(q[2])), warn)


def gamma_scale_posterior(k_obs: int, E_expected: float, conf: float = 0.95) -> Tuple[float, Tuple[float, float]]:
    """Jeffreys Gamma(k + 1/2, E) posterior for a multiplicative rate correction s (k ~ Poisson(s E))."""
    d = stats.gamma(k_obs + 0.5, scale=1.0 / E_expected)
    a = (1 - conf) / 2
    return float(d.mean()), (float(d.ppf(a)), float(d.ppf(1 - a)))


# ===========================================================================
# 6.  Architectural vulnerability by fault injection
# ===========================================================================
def calibrate_avf(cfg: SimConfig, field_name: str = "avf_sram", dtype: str = "int8", tol: float = 1e-2,
                  trials_per_bit: int = 100, shape: Tuple[int, int, int] = (32, 32, 32), seed: int = 0,
                  conservative: bool = True):
    """Measure P(output corrupted beyond ``tol`` | single operand bit flip) and store it (upper CI bound if conservative)."""
    if field_name not in ("avf_sram",):
        raise ValueError("operand-flip injection measures memory (avf_sram) only; register/logic AVF needs RTL "
                         "fault injection: use registry.declare() with that result")
    r = measure_gemm_vulnerability(*shape, dtype=dtype, tol=tol, trials_per_bit=trials_per_bit, seed=seed)
    val = r.ci_high if conservative else r.avf
    setattr(cfg.radiation, field_name, float(val))
    record(cfg, f"radiation.{field_name}", source=f"GEMM bit-flip injection {dtype} {shape} tol={tol}",
           method="Monte-Carlo fault injection + Wilson", value=float(val), ci=(r.ci_low, r.ci_high),
           note=("upper 95 % bound used (conservative)" if conservative else "point estimate"))
    return r
