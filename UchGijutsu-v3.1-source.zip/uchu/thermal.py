"""Power, DVFS and the single lumped thermal model.

v3 fixes vs v2
  * ONE thermal model.  v2 integrated an ODE but then overwrote the state every
    layer with a static ``250 + 0.8 P`` estimate.
  * implicit (backward-Euler) integration with the leakage feedback solved
    inside the step: unconditionally stable (v2 used forward Euler with C = 0.5 J/K).
  * node leakage factor scales only STATIC power, area scales static power, MAC count scales
    dynamic power (v2 multiplied total power by area x array^2 x leakage).
  * clock/interconnect power also scale with V^2 (v2 omitted V).
  * Earth IR + albedo loads added; radiator sized so default dissipation is feasible.
  * runaway is detected and reported instead of silently clamped.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Optional, Tuple

from .config import ProcessNode, SimConfig
from .orbit import OrbitType

SIGMA_SB = 5.670374419e-8
T_MIN_K = 3.0
T_SEARCH_MAX_K = 2500.0


@dataclass(frozen=True)
class DVFSState:
    freq_ghz: float
    voltage_v: float
    throttled: bool


class PowerModel:
    """P = P_leak(T, V) + P_clock(f, V) + util * [P_logic + P_interconnect](f, V)."""

    def __init__(self, cfg: SimConfig):
        self.cfg = cfg
        pw, comp = cfg.power, cfg.compute
        self.pw, self.dv, self.node = pw, cfg.dvfs, comp.process_node
        ref = ProcessNode[pw.ref_node]
        area_ratio = comp.area_mm2 / pw.ref_area_mm2
        self.array_ratio = (comp.array_size / pw.ref_array_size) ** 2
        leak_rel = self.node.leakage_factor() / ref.leakage_factor()
        cap_rel = self.node.cap_factor() / ref.cap_factor()
        self.static_nom_w = pw.base_power_w * pw.static_frac * area_ratio * leak_rel
        self.dynamic_nom_w = pw.base_power_w * (1.0 - pw.static_frac) * self.array_ratio * cap_rel
        self.ic_scale = self.array_ratio ** pw.interconnect_extra_exponent

    def breakdown(self, T: float, f_ghz: float, v: float, util: float = 1.0) -> dict:
        pw = self.pw
        fr = f_ghz / self.dv.nom_freq_ghz
        vr = v / self.dv.nom_voltage_v
        dyn = self.dynamic_nom_w * fr * vr ** 2
        return {
            "leakage": self.static_nom_w * math.exp(pw.leak_temp_coeff * (T - pw.T_nom_k) / pw.T_nom_k) * vr ** 3,
            "clock": dyn * pw.clock_frac,
            "interconnect": dyn * pw.interconnect_frac * self.ic_scale * util,
            "logic": dyn * (1.0 - pw.clock_frac - pw.interconnect_frac) * util,
        }

    def power_w(self, T: float, f_ghz: float, v: float, util: float = 1.0) -> float:
        return sum(self.breakdown(T, f_ghz, v, util).values())

    def dvfs_state(self, T: float, f_target_ghz: Optional[float] = None) -> DVFSState:
        dv = self.dv
        f_t = dv.nom_freq_ghz if f_target_ghz is None else f_target_ghz
        excess = max(0.0, T - dv.throttle_onset_k)
        f = f_t * max(dv.throttle_floor, 1.0 - dv.throttle_slope_per_k * excess)
        f = min(f, self.node.max_freq_ghz())
        if dv.voltage_scaling:
            v = dv.nom_voltage_v * math.sqrt(f / dv.nom_freq_ghz)
            v = min(max(v, self.node.min_voltage()), self.node.max_voltage())
        else:
            v = dv.nom_voltage_v
        return DVFSState(f, v, throttled=f < 0.99 * f_t)


def _bracket(g: Callable[[float], float], T0: float, g0: float, direction: int
             ) -> Optional[Tuple[float, float]]:
    """Find [a, b] bracketing the nearest sign change of g from T0 in `direction` (doubling steps)."""
    step = 0.05
    a, ga = T0, g0
    while True:
        b = min(max(T0 + direction * step, T_MIN_K), T_SEARCH_MAX_K)
        gb = g(b)
        if ga == 0.0:
            return (a, a)
        if ga * gb <= 0.0:
            return (a, b)
        if b in (T_MIN_K, T_SEARCH_MAX_K):
            return None
        a, ga = b, gb
        step *= 2.0


class LumpedThermalModel:
    def __init__(self, cfg: SimConfig):
        self.tc = cfg.thermal
        self.orbit_type = cfg.orbital.orbit_type
        self.T = cfg.thermal.T_init_k
        self.runaway = False

    # ---- loads -----------------------------------------------------------
    @property
    def effective_view_factor(self) -> float:
        tc = self.tc
        return max(0.1, tc.view_factor * (1.0 - tc.degradation_per_year * tc.mission_year))

    def radiated_w(self, T: float) -> float:
        tc = self.tc
        return tc.emissivity * SIGMA_SB * self.effective_view_factor * tc.radiator_area_m2 * T ** 4

    def env_load_w(self, eclipse: bool) -> float:
        tc = self.tc
        A = tc.radiator_area_m2
        if self.orbit_type == OrbitType.DEEP:
            return tc.absorptance * tc.solar_flux_w_m2 * tc.sun_projected_fraction * A
        ir = tc.emissivity * tc.earth_ir_w_m2 * tc.earth_view_fraction * A
        if eclipse:
            return ir
        solar = tc.absorptance * tc.solar_flux_w_m2 * tc.sun_projected_fraction * A
        alb = (tc.absorptance * tc.albedo * tc.solar_flux_w_m2 * tc.earth_view_fraction
               * tc.albedo_geometry * A)
        return ir + solar + alb

    # ---- integration -------------------------------------------------------
    def step(self, dt: float, power_fn: Callable[[float], float], eclipse: bool) -> float:
        """Backward-Euler step of  C dT/dt = P(T) + Q_env - P_rad(T).  Returns the new temperature."""
        if dt <= 0.0:
            return self.T
        C, T0, Q = self.tc.capacitance_j_per_k, self.T, self.env_load_w(eclipse)

        def g(T: float) -> float:
            return C * (T - T0) / dt - power_fn(T) - Q + self.radiated_w(T)

        g0 = g(T0)
        if g0 == 0.0:
            return T0
        br = _bracket(g, T0, g0, +1 if g0 < 0.0 else -1)
        if br is None:
            if g0 < 0.0:                 # heating with no root below the search ceiling: runaway
                self.runaway = True
                self.T = T_SEARCH_MAX_K
            else:
                self.T = T_MIN_K
            return self.T
        from scipy.optimize import brentq
        a, b = br
        self.T = a if a == b else brentq(g, min(a, b), max(a, b), xtol=1e-10, rtol=1e-13, maxiter=200)
        return self.T

    def steady_state(self, power_fn: Callable[[float], float], eclipse: bool) -> Optional[float]:
        """Lowest (stable) equilibrium of P(T) + Q = P_rad(T); None if no equilibrium (runaway)."""
        import numpy as np
        from scipy.optimize import brentq
        Q = self.env_load_w(eclipse)

        def h(T: float) -> float:
            return self.radiated_w(T) - power_fn(T) - Q

        grid = np.geomspace(T_MIN_K, T_SEARCH_MAX_K, 800)
        vals = [h(float(T)) for T in grid]
        for i in range(len(grid) - 1):
            if vals[i] <= 0.0 < vals[i + 1]:
                return float(brentq(h, grid[i], grid[i + 1], xtol=1e-10))
        return None
