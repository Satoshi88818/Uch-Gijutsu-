"""Run provenance: everything needed to reproduce a result."""
from __future__ import annotations

import platform
import subprocess
import sys
from typing import Optional

import numpy as np
import scipy

from .config import SimConfig

MODEL_VERSION = "3.0.0"


def git_hash() -> Optional[str]:
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"],
                                       stderr=subprocess.DEVNULL, timeout=2).decode().strip()
    except Exception:
        return None


def provenance(cfg: SimConfig, seed: Optional[int] = None) -> dict:
    return {
        "model_version": MODEL_VERSION,
        "config_hash": cfg.config_hash(),
        "seed": cfg.random_seed if seed is None else seed,
        "python": sys.version.split()[0],
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "platform": platform.platform(),
        "git": git_hash(),
    }
