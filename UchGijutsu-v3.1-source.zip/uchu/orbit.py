"""Orbital environment: geometry (analytic eclipse), SEP-event schedule.

v3 design: the environment is *stateless in time* except for a lazily generated
flare schedule.  The simulator owns the single clock and queries exact
interval quantities (eclipse segments, integrated flare intensity), so there is
no per-layer ``advance_time`` drift.
"""
from __future__ import annotations

import math
from typing import List, Optional, Sequence, Tuple

import numpy as np

from .config import OrbitalConfig, OrbitType, SolarActivity

MU_EARTH = 3.986004418e14   # m^3 / s^2
R_EARTH_KM = 6378.137

# SEP-event (solar energetic particle) arrival rates, events / year   -- PLACEHOLDER
SEP_EVENTS_PER_YEAR = {SolarActivity.LOW: 0.5, SolarActivity.MODERATE: 3.0, SolarActivity.HIGH: 8.0}
SEP_MEAN_DURATION_S = 12 * 3600.0          # PLACEHOLDER
SEP_INTENSITY_LOGSIGMA = 1.0               # lognormal sigma, median intensity 1.0 (PLACEHOLDER)


def kepler_period_s(altitude_km: float) -> float:
    a = (R_EARTH_KM + altitude_km) * 1e3
    return 2.0 * math.pi * math.sqrt(a ** 3 / MU_EARTH)


def eclipse_fraction(altitude_km: float, beta_deg: float = 0.0) -> float:
    """Fraction of a circular orbit spent in Earth's cylindrical shadow."""
    R, h = R_EARTH_KM, altitude_km
    beta = math.radians(beta_deg)
    arg = math.sqrt(h * h + 2.0 * R * h) / ((R + h) * math.cos(beta))
    if arg >= 1.0:
        return 0.0
    return math.acos(arg) / math.pi


class FlareSchedule:
    """Poisson process of SEP events; each has (start, end, intensity).  Generated lazily and
    sequentially from one RNG, so the schedule prefix is independent of query order."""

    def __init__(self, rate_per_s: float, rng: Optional[np.random.Generator],
                 mean_duration_s: float = SEP_MEAN_DURATION_S,
                 log_sigma: float = SEP_INTENSITY_LOGSIGMA, median: float = 1.0):
        self.rate = rate_per_s
        self.median = median
        self.rng = rng
        self.mean_dur = mean_duration_s
        self.log_sigma = log_sigma
        self._cursor = 0.0
        self._ev: List[Tuple[float, float, float]] = []
        self._arr = (np.empty(0), np.empty(0), np.empty(0))
        self._fixed = False

    @classmethod
    def from_events(cls, events: Sequence[Tuple[float, float, float]]) -> "FlareSchedule":
        """Deterministic schedule for tests / replaying a real event list: (start_s, end_s, intensity)."""
        s = cls(0.0, None)
        s._ev = [tuple(map(float, e)) for e in events]
        s._fixed = True
        s._rebuild()
        return s

    def _rebuild(self):
        if self._ev:
            a = np.array(self._ev, float)
            self._arr = (a[:, 0], a[:, 1], a[:, 2])
        else:
            self._arr = (np.empty(0), np.empty(0), np.empty(0))

    def extend_to(self, t: float) -> None:
        if self._fixed or self.rate <= 0.0:
            return
        grew = False
        while self._cursor <= t:
            self._cursor += float(self.rng.exponential(1.0 / self.rate))
            dur = float(self.rng.exponential(self.mean_dur))
            inten = float(self.rng.lognormal(math.log(self.median), self.log_sigma))
            self._ev.append((self._cursor, self._cursor + dur, inten))
            grew = True
        if grew:
            self._rebuild()

    def intensity_integral(self, t0: float, t1: float) -> float:
        """Exact integral of summed flare intensity over [t0, t1]  [intensity * s]."""
        if t1 <= t0:
            return 0.0
        self.extend_to(t1)
        s, e, i = self._arr
        if s.size == 0:
            return 0.0
        overlap = np.clip(np.minimum(e, t1) - np.maximum(s, t0), 0.0, None)
        return float(np.sum(i * overlap))

    def intensity_at(self, t: float) -> float:
        self.extend_to(t)
        s, e, i = self._arr
        if s.size == 0:
            return 0.0
        return float(np.sum(i[(s <= t) & (t < e)]))

    @property
    def events(self) -> List[Tuple[float, float, float]]:
        return list(self._ev)


class OrbitalEnvironment:
    def __init__(self, cfg: OrbitalConfig, rng: Optional[np.random.Generator] = None):
        self.cfg = cfg
        if cfg.orbit_type == OrbitType.DEEP:
            self.period_s = 1e12
            self.eclipse_fraction = 0.0
        else:
            self.period_s = kepler_period_s(cfg.altitude_km)
            self.eclipse_fraction = (cfg.eclipse_fraction_override
                                     if cfg.eclipse_fraction_override is not None
                                     else eclipse_fraction(cfg.altitude_km, cfg.beta_deg))
        per_year = (cfg.sep_events_per_year if cfg.sep_events_per_year is not None
                    else SEP_EVENTS_PER_YEAR[cfg.solar_activity])
        self.flares = FlareSchedule(per_year / (365.25 * 86400.0),
                                    rng if rng is not None else np.random.default_rng(0),
                                    mean_duration_s=cfg.sep_mean_duration_s,
                                    log_sigma=cfg.sep_intensity_log_sigma, median=cfg.sep_intensity_median)

    # ---- geometry ---------------------------------------------------------
    def in_eclipse(self, t: float) -> bool:
        if self.eclipse_fraction <= 0.0:
            return False
        return (t % self.period_s) < self.eclipse_fraction * self.period_s

    def eclipse_segments(self, t0: float, t1: float) -> List[Tuple[float, float, bool]]:
        """Partition [t0, t1] into maximal (a, b, in_eclipse) segments, exactly."""
        if t1 <= t0:
            return []
        if self.eclipse_fraction <= 0.0:
            return [(t0, t1, False)]
        P = self.period_s
        ecl = self.eclipse_fraction * P
        segs: List[Tuple[float, float, bool]] = []
        t = t0
        k = int(math.floor(t0 / P))
        while t < t1:
            start = k * P
            ecl_end = start + ecl
            nxt = start + P
            if t < ecl_end:
                b = min(ecl_end, t1)
                segs.append((t, b, True))
                t = b
            if t < t1:
                b = min(nxt, t1)
                if b > t:
                    segs.append((t, b, False))
                    t = b
            k += 1
        return segs

    # ---- SEP events ---------------------------------------------------------
    def flare_intensity_integral(self, t0: float, t1: float) -> float:
        return self.flares.intensity_integral(t0, t1)

    def flare_intensity_at(self, t: float) -> float:
        return self.flares.intensity_at(t)
