"""Uchu Gijutsu v3 -- space-AI accelerator simulator (single clock, cross-section radiation core)."""
from .config import (ComputeConfig, CrossSection, DType, DVFSConfig, MemoryConfig, OrbitalConfig,
                     OrbitType, PowerConfig, ProcessNode, RadiationConfig, SimConfig, SolarActivity,
                     ThermalConfig)
from .faults import flip_bit, measure_gemm_vulnerability
from .memory import (WorkloadLayer, build_transformer_workload, estimate_layer, profile_pass,
                     structured_sparsity_speedup)
from .provenance import MODEL_VERSION, provenance
from .radiation import (EccMemory, RadiationEnvironment, RadiationStats, RadiationSubsystem,
                        TruncatedPowerLaw, integral_rate)
from .rng import child_seed, make_rng
from .simulator import ChipSimulator, run_ensemble, run_mission, run_workload
from .thermal import LumpedThermalModel, PowerModel

__version__ = MODEL_VERSION
