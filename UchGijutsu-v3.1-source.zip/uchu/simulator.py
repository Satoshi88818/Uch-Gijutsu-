"""Single-clock simulator: thermal + orbit + radiation advance together, exactly.

v3 fixes vs v2
  * ONE authoritative clock (``ChipSimulator.t``); thermal, eclipse, flares, scrubbing and
    radiation exposure all use the *actual* elapsed time of each step (v2 advanced orbit by a
    nominal-frequency estimate while layers ran at throttled speed).
  * run_mission() reaches orbit-scale time (eclipse cycles, flares) with macro-steps; v2 simulated
    ~10 s and Monte-Carlo used a single iteration, so it never saw an eclipse or a flare.
  * no global RNG: every stream comes from ``rng.make_rng(seed, key...)``.
  * ensemble members are independent processes with spawned seeds (v2: threads + global seeding).
"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import numpy as np

from .config import SimConfig, SolarActivity
from .memory import PassProfile, WorkloadLayer, profile_pass
from .orbit import OrbitalEnvironment
from .provenance import provenance
from .radiation import RadiationEnvironment, RadiationStats, RadiationSubsystem
from .rng import child_seed, make_rng
from .stats import poisson_rate_ci
from .thermal import DVFSState, LumpedThermalModel, PowerModel


class ChipSimulator:
    def __init__(self, cfg: SimConfig, seed: Optional[int] = None):
        self.cfg = cfg.validate()
        self.seed = cfg.random_seed if seed is None else int(seed)
        self.orbit = OrbitalEnvironment(cfg.orbital, make_rng(self.seed, "orbit"))
        self.power = PowerModel(cfg)
        self.thermal = LumpedThermalModel(cfg)
        self.env = RadiationEnvironment(cfg, self.orbit)
        self.rad = RadiationSubsystem(cfg, self.env, make_rng(self.seed, "radiation"))
        self.t = 0.0
        self.energy_j = 0.0
        self.overtemp_s = 0.0
        self.throttled_s = 0.0
        self.failed = False
        self.fail_reason: Optional[str] = None
        self._next_scrub = cfg.radiation.scrub_interval_s

    def dvfs(self) -> DVFSState:
        return self.power.dvfs_state(self.thermal.T)

    def advance(self, dt: float, util: float, live_sram_bits: float, state: DVFSState) -> None:
        """Advance the whole chip by ``dt`` seconds at fixed (f, V, util)."""
        cfg, rc = self.cfg, self.cfg.radiation
        t_end = self.t + dt
        while self.t < t_end - 1e-12 and not self.failed:
            a, b, ecl = self.orbit.eclipse_segments(self.t, t_end)[0]
            seg_end = min(b, self._next_scrub, self.t + cfg.thermal.max_substep_s, t_end)
            h = seg_end - self.t
            T_new = self.thermal.step(
                h, lambda T: self.power.power_w(T, state.freq_ghz, state.voltage_v, util), ecl)
            p_end = self.power.power_w(T_new, state.freq_ghz, state.voltage_v, util)
            self.energy_j += p_end * h            # end-point rule == backward-Euler energy balance
            if T_new > cfg.power.T_max_k:
                self.overtemp_s += h
            if state.throttled:
                self.throttled_s += h
            if self.thermal.runaway:
                self.failed, self.fail_reason = True, "thermal_runaway"
            self.rad.expose(self.t, seg_end, live_sram_bits, state.freq_ghz)
            if self.rad.ledger.destroyed:
                self.failed, self.fail_reason = True, "single_event_latchup_destructive"
            self.t = seg_end
            if self.t >= self._next_scrub - 1e-12:
                self.rad.scrub()
                self._next_scrub += rc.scrub_interval_s

    def finalize(self) -> RadiationStats:
        """Classify any still-unscrubbed flipped bits (treated as read at end of run)."""
        self.rad.scrub()
        return self.rad.stats(self.t)


# ---------------------------------------------------------------------------
# Short workload run (pass-level stepping, single clock)
# ---------------------------------------------------------------------------
@dataclass
class WorkloadResult:
    elapsed_s: float
    n_passes: int
    dense_flops: float
    executed_flops: float
    avg_tflops_dense: float
    avg_power_w: float
    energy_j: float
    peak_temperature_k: float
    final_temperature_k: float
    memory_bound_fraction: float
    radiation: RadiationStats
    failed: bool
    fail_reason: Optional[str]
    first_pass_layers: list
    provenance: dict = field(default_factory=dict)

    @property
    def tflops_per_watt(self) -> float:
        return self.avg_tflops_dense / self.avg_power_w if self.avg_power_w > 0 else 0.0


def run_workload(cfg: SimConfig, layers: Sequence[WorkloadLayer], n_passes: int = 100,
                 seed: Optional[int] = None) -> WorkloadResult:
    sim = ChipSimulator(cfg, seed)
    layers = list(layers)
    dense = execd = mb_time = 0.0
    peakT = sim.thermal.T
    first = None
    done = 0
    for _ in range(n_passes):
        state = sim.dvfs()
        prof = profile_pass(layers, cfg, state.freq_ghz)
        first = first or prof.layers
        sim.advance(prof.duration_s, prof.util, prof.live_sram_bits, state)
        dense += prof.dense_flops
        execd += prof.executed_flops
        mb_time += prof.memory_bound_fraction * prof.duration_s
        peakT = max(peakT, sim.thermal.T)
        done += 1
        if sim.failed:
            break
    rad = sim.finalize()
    el = max(sim.t, 1e-300)
    return WorkloadResult(
        elapsed_s=sim.t, n_passes=done, dense_flops=dense, executed_flops=execd,
        avg_tflops_dense=dense / el / 1e12, avg_power_w=sim.energy_j / el, energy_j=sim.energy_j,
        peak_temperature_k=peakT, final_temperature_k=sim.thermal.T,
        memory_bound_fraction=mb_time / el, radiation=rad, failed=sim.failed,
        fail_reason=sim.fail_reason, first_pass_layers=list(first or []),
        provenance=provenance(cfg, sim.seed))


# ---------------------------------------------------------------------------
# Mission run (macro-steps; reaches eclipse cycles and SEP events)
# ---------------------------------------------------------------------------
@dataclass
class MissionResult:
    mission_s: float
    simulated_s: float
    completed: bool
    failed: bool
    fail_reason: Optional[str]
    dense_flops: float
    avg_tflops_dense: float
    avg_power_w: float
    energy_j: float
    T_min_k: float
    T_max_k: float
    T_mean_k: float
    overtemp_s: float
    throttled_fraction: float
    radiation: RadiationStats
    availability: float
    flare_events: list
    series: Dict[str, np.ndarray]
    provenance: dict = field(default_factory=dict)


def run_mission(cfg: SimConfig, layers: Sequence[WorkloadLayer], mission_s: float, duty: float = 1.0,
                dt_max_s: float = 10.0, seed: Optional[int] = None,
                record_every_s: float = 60.0) -> MissionResult:
    if not 0.0 <= duty <= 1.0:
        raise ValueError("duty must be in [0, 1]")
    sim = ChipSimulator(cfg, seed)
    layers = list(layers)
    cache: Dict[float, PassProfile] = {}
    flops = 0.0
    sumT = Tmin = Tmax = None
    sumT = 0.0
    Tmin, Tmax = sim.thermal.T, sim.thermal.T
    rec = {"t": [], "T": [], "f": [], "eclipse": [], "flare": []}
    next_rec = 0.0
    while sim.t < mission_s - 1e-9 and not sim.failed:
        state = sim.dvfs()
        key = round(state.freq_ghz, 4)
        if key not in cache:
            cache[key] = profile_pass(layers, cfg, key)
        prof = cache[key]
        dt = min(dt_max_s, mission_s - sim.t)
        t0 = sim.t
        sim.advance(dt, duty * prof.util, prof.live_sram_bits, state)
        h = sim.t - t0
        flops += duty * h * prof.dense_flops / prof.duration_s
        T = sim.thermal.T
        sumT += T * h
        Tmin, Tmax = min(Tmin, T), max(Tmax, T)
        if t0 >= next_rec:
            rec["t"].append(t0); rec["T"].append(T); rec["f"].append(state.freq_ghz)
            rec["eclipse"].append(sim.orbit.in_eclipse(t0)); rec["flare"].append(sim.orbit.flare_intensity_at(t0))
            next_rec += record_every_s
    rad = sim.finalize()
    el = max(sim.t, 1e-300)
    avail = rad.availability
    flops *= avail
    return MissionResult(
        mission_s=mission_s, simulated_s=sim.t, completed=sim.t >= mission_s - 1e-6 and not sim.failed,
        failed=sim.failed, fail_reason=sim.fail_reason, dense_flops=flops,
        avg_tflops_dense=flops / el / 1e12, avg_power_w=sim.energy_j / el, energy_j=sim.energy_j,
        T_min_k=Tmin, T_max_k=Tmax, T_mean_k=sumT / el, overtemp_s=sim.overtemp_s,
        throttled_fraction=sim.throttled_s / el, radiation=rad, availability=avail,
        flare_events=sim.orbit.flares.events, series={k: np.asarray(v) for k, v in rec.items()},
        provenance=provenance(cfg, sim.seed))


# ---------------------------------------------------------------------------
# Ensemble (independent processes, spawned seeds, pooled exact Poisson statistics)
# ---------------------------------------------------------------------------
@dataclass
class EnsembleResult:
    n_samples: int
    total_hours: float
    total_sdc: int
    total_due: int
    sdc_per_hr: float
    sdc_per_hr_ci: tuple
    due_per_hr: float
    per_sample_sdc_per_hr: np.ndarray
    n_failed: int
    mean_availability: float
    provenance: dict


def _ensemble_worker(args):
    cfg, layers, mission_s, duty, dt_max_s, seed, activity = args
    cfg = cfg.copy()
    if activity is not None:
        cfg.orbital.solar_activity = activity
    r = run_mission(cfg, layers, mission_s, duty, dt_max_s, seed)
    return (r.radiation.sdc_total, r.radiation.words_due, r.simulated_s, r.failed, r.availability)


def run_ensemble(cfg: SimConfig, layers: Sequence[WorkloadLayer], n_samples: int, mission_s: float,
                 duty: float = 1.0, dt_max_s: float = 10.0, n_jobs: int = 1,
                 base_seed: Optional[int] = None,
                 solar_weights: Optional[Dict[SolarActivity, float]] = None) -> EnsembleResult:
    base = cfg.random_seed if base_seed is None else int(base_seed)
    acts: List[Optional[SolarActivity]] = [None] * n_samples
    if solar_weights:
        keys = list(solar_weights)
        w = np.array([solar_weights[k] for k in keys], float)
        w /= w.sum()
        for i in range(n_samples):
            acts[i] = keys[int(make_rng(base, "scenario", i).choice(len(keys), p=w))]
    jobs = [(cfg, list(layers), mission_s, duty, dt_max_s, child_seed(base, "sample", i), acts[i])
            for i in range(n_samples)]
    if n_jobs == 1:
        out = [_ensemble_worker(j) for j in jobs]
    else:
        with ProcessPoolExecutor(max_workers=n_jobs) as ex:
            out = list(ex.map(_ensemble_worker, jobs))
    sdc = np.array([o[0] for o in out]); due = np.array([o[1] for o in out])
    el = np.array([o[2] for o in out]) / 3600.0
    hours = float(el.sum())
    ci = poisson_rate_ci(int(sdc.sum()), hours)
    return EnsembleResult(
        n_samples=n_samples, total_hours=hours, total_sdc=int(sdc.sum()), total_due=int(due.sum()),
        sdc_per_hr=float(sdc.sum() / hours) if hours > 0 else 0.0, sdc_per_hr_ci=ci,
        due_per_hr=float(due.sum() / hours) if hours > 0 else 0.0,
        per_sample_sdc_per_hr=sdc / np.maximum(el, 1e-300), n_failed=int(sum(o[3] for o in out)),
        mean_availability=float(np.mean([o[4] for o in out])), provenance=provenance(cfg, base))
