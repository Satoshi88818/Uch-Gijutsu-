"""Deterministic, isolated random-number streams.

v3 never touches NumPy's / Python's / Torch's *global* RNG state.  Every
stochastic component asks for its own named stream derived from one master
seed via ``numpy.random.SeedSequence`` (``spawn_key`` = CRC32 of each key).
Streams with different keys are statistically independent; identical
(seed, keys) always reproduce identical streams, in any process.
"""
from __future__ import annotations

import zlib

import numpy as np


def _spawn_key(keys) -> tuple:
    return tuple(zlib.crc32(str(k).encode("utf-8")) for k in keys)


def make_rng(seed: int, *keys) -> np.random.Generator:
    """Independent Generator for (seed, *keys)."""
    ss = np.random.SeedSequence(entropy=int(seed), spawn_key=_spawn_key(keys))
    return np.random.default_rng(ss)


def child_seed(seed: int, *keys) -> int:
    """Integer seed derived from (seed, *keys); safe to ship to worker processes."""
    ss = np.random.SeedSequence(entropy=int(seed), spawn_key=_spawn_key(keys))
    return int(ss.generate_state(1, dtype=np.uint64)[0] % (2**63 - 1))
