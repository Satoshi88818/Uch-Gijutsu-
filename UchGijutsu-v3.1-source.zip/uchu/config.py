"""Configuration for Uchu Gijutsu v3.

Every parameter that is a *placeholder awaiting external calibration* is
marked ``# PLACEHOLDER`` and listed in the provenance table in the docs.
"""
from __future__ import annotations

import copy
import dataclasses
import hashlib
import json
import math
import typing
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

import numpy as np

# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------
_NODE = {
    "fmax": {"N28": 1.2, "N16": 1.8, "N7": 2.5, "N5": 3.0, "N3": 3.5},
    "vmin": {"N28": 0.75, "N16": 0.70, "N7": 0.65, "N5": 0.60, "N3": 0.55},
    "vmax": {"N28": 1.05, "N16": 1.00, "N7": 0.90, "N5": 0.85, "N3": 0.80},
    "leak": {"N28": 1.0, "N16": 1.4, "N7": 2.1, "N5": 2.8, "N3": 3.5},   # PLACEHOLDER (static power / mm^2)
    "cap": {"N28": 1.6, "N16": 1.25, "N7": 1.0, "N5": 0.85, "N3": 0.72},  # PLACEHOLDER (switched C / MAC)
}


class ProcessNode(Enum):
    N28 = "28nm"
    N16 = "16nm"
    N7 = "7nm"
    N5 = "5nm"
    N3 = "3nm"

    def max_freq_ghz(self) -> float:
        return _NODE["fmax"][self.name]

    def min_voltage(self) -> float:
        return _NODE["vmin"][self.name]

    def max_voltage(self) -> float:
        return _NODE["vmax"][self.name]

    def leakage_factor(self) -> float:
        return _NODE["leak"][self.name]

    def cap_factor(self) -> float:
        return _NODE["cap"][self.name]


class DType(Enum):
    """(label, bytes/element, MAC throughput per PE per cycle relative to a native INT8 PE).

    v3 FIX: v2 stored ``relative_ops`` = 1.0/0.5/0.25 for FP32/FP16/INT8, i.e.
    *lower* throughput for narrower types.  Narrow types are faster per PE.
    """
    FP32 = ("fp32", 4.0, 0.25)
    FP16 = ("fp16", 2.0, 0.5)
    BF16 = ("bf16", 2.0, 0.5)
    FP8 = ("fp8", 1.0, 1.0)
    INT8 = ("int8", 1.0, 1.0)
    INT4 = ("int4", 0.5, 2.0)

    def __init__(self, label: str, bytes_per_elem: float, pe_throughput: float):
        self.label = label
        self.bytes_per_elem = bytes_per_elem
        self.pe_throughput = pe_throughput


class OrbitType(Enum):
    LEO = "Low Earth Orbit"
    MEO = "Medium Earth Orbit"
    GEO = "Geostationary Orbit"
    DEEP = "Deep Space"


class SolarActivity(Enum):
    LOW = "solar_min"
    MODERATE = "moderate"
    HIGH = "solar_max"


_DEFAULT_ALT_KM = {OrbitType.LEO: 550.0, OrbitType.MEO: 20200.0,
                   OrbitType.GEO: 35786.0, OrbitType.DEEP: 0.0}

# ---------------------------------------------------------------------------
# Sub-configs
# ---------------------------------------------------------------------------


@dataclass
class MemoryConfig:
    hbm_bw_tb_s_per_stack: float = 1.0      # TB/s per stack
    num_hbm_stacks: int = 2
    onchip_sram_mb: float = 64.0
    ecc_enabled: bool = True
    ecc_bw_overhead_pct: float = 12.5       # PLACEHOLDER
    hbm_efficiency: float = 1.0             # PLACEHOLDER: achieved / peak HBM bandwidth (excl. ECC overhead)


@dataclass
class PowerConfig:
    base_power_w: float = 50.0     # total power at reference config, nominal V/f, T_nom, util=1
    static_frac: float = 0.45      # fraction of base power that is leakage; dynamic = 1 - static
    clock_frac: float = 0.08       # fraction of *dynamic* power in the clock tree (always toggling)
    interconnect_frac: float = 0.05  # fraction of *dynamic* power in interconnect
    interconnect_extra_exponent: float = 0.5  # PLACEHOLDER: wire power ~ array_ratio**exp beyond MAC scaling
    leak_temp_coeff: float = 3.5   # PLACEHOLDER: P_leak ~ exp(k (T-Tnom)/Tnom)
    T_nom_k: float = 300.0
    T_max_k: float = 390.0
    ref_area_mm2: float = 400.0
    ref_array_size: int = 256
    ref_node: str = "N7"


@dataclass
class DVFSConfig:
    nom_freq_ghz: float = 1.5
    nom_voltage_v: float = 0.9
    voltage_scaling: bool = True
    throttle_onset_k: float = 370.0
    throttle_slope_per_k: float = 0.02   # fractional f reduction per K above onset
    throttle_floor: float = 0.1


@dataclass
class ThermalConfig:
    """Single lumped node (chip + board + radiator).  No junction-to-radiator resistance."""
    capacitance_j_per_k: float = 500.0   # ~0.55 kg of Al-equivalent; v2 used 0.5 J/K (unphysical)
    radiator_area_m2: float = 0.25
    emissivity: float = 0.85
    view_factor: float = 0.85
    degradation_per_year: float = 0.02
    mission_year: float = 0.0
    absorptance: float = 0.15
    solar_flux_w_m2: float = 1361.0
    sun_projected_fraction: float = 0.15  # PLACEHOLDER (attitude-dependent)
    earth_ir_w_m2: float = 237.0
    albedo: float = 0.30
    earth_view_fraction: float = 0.25     # PLACEHOLDER
    albedo_geometry: float = 0.5          # PLACEHOLDER
    T_init_k: float = 290.0
    max_substep_s: float = 5.0


@dataclass
class OrbitalConfig:
    orbit_type: OrbitType = OrbitType.LEO
    altitude_km: float = 550.0
    inclination_deg: float = 51.6
    beta_deg: float = 0.0
    solar_activity: SolarActivity = SolarActivity.MODERATE
    eclipse_fraction_override: Optional[float] = None
    # SEP-event statistics.  None / defaults reproduce the v3.0 built-in table.   PLACEHOLDER until fitted
    sep_events_per_year: Optional[float] = None
    sep_mean_duration_s: float = 12 * 3600.0
    sep_intensity_median: float = 1.0          # relative to the reference event embodied in the SEP spectra
    sep_intensity_log_sigma: float = 1.0

    @classmethod
    def for_orbit(cls, orbit_type: OrbitType, **kw) -> "OrbitalConfig":
        kw.setdefault("altitude_km", _DEFAULT_ALT_KM[orbit_type])
        return cls(orbit_type=orbit_type, **kw)


@dataclass
class ComputeConfig:
    array_size: int = 256
    process_node: ProcessNode = ProcessNode.N7
    area_mm2: float = 400.0
    sparse_speedup_at_50: float = 1.85   # PLACEHOLDER: measured 2:4 compute speedup (<2 due to metadata/overhead)
    pipeline_overlap: float = 0.0        # fraction of per-tile fill/drain hidden by tile-to-tile pipelining
                                         # (0 = fully exposed = conservative; 1 = only one fill/drain per layer)


@dataclass
class CrossSection:
    """Weibull SEE cross-section sigma(x).  x = LET [MeV cm2/mg] (ions) or E [MeV] (protons).
    ``sigma_sat_cm2`` is per bit / per flip-flop / per gate / per device depending on region."""
    sigma_sat_cm2: float
    x_th: float
    width: float
    shape: float

    def __call__(self, x):
        x = np.asarray(x, dtype=float)
        z = np.clip((x - self.x_th) / self.width, 0.0, None)
        return self.sigma_sat_cm2 * (1.0 - np.exp(-np.power(z, self.shape)))


@dataclass
class RegionXS:
    ion: CrossSection
    proton: CrossSection


@dataclass
class SpectrumParams:
    """Truncated power-law integral flux  Phi(>x) = phi_ref [ (x/x_ref)^-g - (x_max/x_ref)^-g ], x < x_max.
    Units: particles / cm2 / s (omnidirectional)."""
    phi_ref: float
    x_ref: float
    gamma: float
    x_max: float


@dataclass
class SpectrumTable:
    """Integral flux table Phi(>x) [particles/cm2/s] vs x (LET [MeV cm2/mg] or E [MeV]) from CREME96/OMERE/SPENVIS."""
    x: List[float]
    phi_integral: List[float]

    def __post_init__(self):                       # canonical floats => stable config hash
        self.x = [float(v) for v in self.x]
        self.phi_integral = [float(v) for v in self.phi_integral]


_SPECTRUM_KEYS = ("gcr_ion", "trapped_proton", "sep_ion", "sep_proton")


@dataclass
class RadiationConfig:
    # --- device cross-sections (ALL PLACEHOLDER: replace with beam-test Weibull fits) ---
    sram: RegionXS = field(default_factory=lambda: RegionXS(
        CrossSection(1e-14, 0.5, 20.0, 1.5), CrossSection(3e-15, 10.0, 30.0, 1.5)))
    register: RegionXS = field(default_factory=lambda: RegionXS(
        CrossSection(2e-14, 0.5, 20.0, 1.5), CrossSection(3e-15, 10.0, 30.0, 1.5)))
    logic_set: RegionXS = field(default_factory=lambda: RegionXS(      # per gate
        CrossSection(1e-15, 2.0, 20.0, 1.5), CrossSection(1e-16, 15.0, 30.0, 1.5)))
    sel: RegionXS = field(default_factory=lambda: RegionXS(            # per device
        CrossSection(1e-4, 30.0, 30.0, 2.0), CrossSection(0.0, 30.0, 30.0, 2.0)))
    # --- environment spectra (PLACEHOLDER: replace with CREME96/OMERE/AP-9 exports) ---
    gcr_ion: SpectrumParams = field(default_factory=lambda: SpectrumParams(2e-3, 1.0, 1.6, 150.0))
    trapped_proton: SpectrumParams = field(default_factory=lambda: SpectrumParams(5.0, 10.0, 1.0, 400.0))
    sep_ion: SpectrumParams = field(default_factory=lambda: SpectrumParams(0.1, 1.0, 2.5, 30.0))
    sep_proton: SpectrumParams = field(default_factory=lambda: SpectrumParams(100.0, 10.0, 2.0, 300.0))
    # 'scaled_placeholder': power-law spectra x placeholder orbit scalings.
    # 'tabulated_orbit'   : `tables` are orbit-specific & already shielded; NO scalings are applied.
    environment_mode: str = "scaled_placeholder"
    tables: Dict[str, SpectrumTable] = field(default_factory=dict)
    let_grid_lo: float = 1e-2
    energy_grid_lo: float = 1.0
    shield_mm_al: float = 2.0
    shield_atten_len_mm: float = 10.0       # PLACEHOLDER (protons)
    # --- memory / ECC ---
    mbu_prob: float = 0.10                   # PLACEHOLDER: P(cluster | SRAM SEU)
    mbu_max_cluster: int = 6
    mbu_cluster_geom_p: float = 0.5          # PLACEHOLDER: P(stop) of the truncated-geometric cluster size
    ecc_word_bits: int = 64
    ecc_interleave: int = 4
    secded_odd_miscorrect_prob: float = 1.0  # conservative: odd >=3-bit errors alias to a 1-bit syndrome
    scrub_interval_s: float = 1.0
    # --- architectural derating (1.0 = conservative upper bound; set from fault injection) ---
    avf_sram: float = 1.0
    avf_register: float = 1.0
    avf_logic: float = 1.0
    reg_bits_per_pe: int = 48
    gates_per_pe: int = 1500                 # PLACEHOLDER
    set_pulse_width_ps: float = 150.0        # PLACEHOLDER
    tmr_enabled: bool = False
    tmr_residual: float = 1e-3               # PLACEHOLDER: voter / common-cause fraction left under TMR
    # --- latch-up ---
    sel_protected: bool = True
    sel_recovery_s: float = 5.0
    sel_destructive_prob_unprotected: float = 1.0


@dataclass
class SimConfig:
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    power: PowerConfig = field(default_factory=PowerConfig)
    dvfs: DVFSConfig = field(default_factory=DVFSConfig)
    thermal: ThermalConfig = field(default_factory=ThermalConfig)
    orbital: OrbitalConfig = field(default_factory=OrbitalConfig)
    compute: ComputeConfig = field(default_factory=ComputeConfig)
    radiation: RadiationConfig = field(default_factory=RadiationConfig)
    random_seed: int = 42
    calibration: Dict[str, dict] = field(default_factory=dict)   # dotted path -> provenance entry

    # ------------------------------------------------------------------
    def validate(self) -> "SimConfig":
        def need(cond: bool, msg: str):
            if not cond:
                raise ValueError(f"invalid SimConfig: {msg}")
        c, p, d, t, r, o, m = (self.compute, self.power, self.dvfs, self.thermal,
                               self.radiation, self.orbital, self.memory)
        need(c.array_size > 0, "array_size must be > 0")
        need(c.area_mm2 > 0, "area_mm2 must be > 0")
        need(0.0 <= p.static_frac < 1.0, "static_frac must be in [0,1)")
        need(p.clock_frac + p.interconnect_frac < 1.0, "clock_frac + interconnect_frac must be < 1")
        need(p.base_power_w > 0, "base_power_w must be > 0")
        need(p.T_nom_k < p.T_max_k, "T_nom_k < T_max_k")
        need(d.nom_freq_ghz > 0, "nom_freq_ghz must be > 0")
        need(c.process_node.min_voltage() <= d.nom_voltage_v <= c.process_node.max_voltage(),
             f"nom_voltage_v outside {c.process_node.value} range")
        need(d.nom_freq_ghz <= c.process_node.max_freq_ghz(), "nom_freq_ghz exceeds node maximum")
        need(0.0 < d.throttle_floor <= 1.0, "throttle_floor must be in (0,1]")
        need(t.capacitance_j_per_k > 0 and t.radiator_area_m2 > 0, "thermal capacitance/area must be > 0")
        need(0.0 < t.emissivity <= 1.0 and 0.0 < t.view_factor <= 1.0, "emissivity/view_factor in (0,1]")
        need(m.onchip_sram_mb > 0 and m.hbm_bw_tb_s_per_stack > 0 and m.num_hbm_stacks > 0, "memory sizes > 0")
        need(0.0 <= r.mbu_prob <= 1.0 and r.mbu_max_cluster >= 2, "mbu params")
        need(r.ecc_interleave >= 1 and r.ecc_word_bits >= 1, "ecc geometry")
        need(r.scrub_interval_s > 0, "scrub_interval_s must be > 0")
        for name in ("avf_sram", "avf_register", "avf_logic", "secded_odd_miscorrect_prob"):
            need(0.0 <= getattr(r, name) <= 1.0, f"{name} in [0,1]")
        need(0.0 <= o.inclination_deg <= 180.0, "inclination_deg in [0,180]")
        if o.eclipse_fraction_override is not None:
            need(0.0 <= o.eclipse_fraction_override < 1.0, "eclipse_fraction_override in [0,1)")
        need(c.sparse_speedup_at_50 >= 1.0, "sparse_speedup_at_50 >= 1")
        need(0.0 <= c.pipeline_overlap <= 1.0, "pipeline_overlap in [0,1]")
        need(0.0 < m.hbm_efficiency <= 1.0, "hbm_efficiency in (0,1]")
        need(0.0 < r.mbu_cluster_geom_p <= 1.0, "mbu_cluster_geom_p in (0,1]")
        need(r.environment_mode in ("scaled_placeholder", "tabulated_orbit"), "unknown environment_mode")
        need(o.sep_mean_duration_s > 0 and o.sep_intensity_median > 0 and o.sep_intensity_log_sigma >= 0,
             "SEP statistics must be positive")
        need(o.sep_events_per_year is None or o.sep_events_per_year >= 0, "sep_events_per_year >= 0")
        for key, tab in r.tables.items():
            need(key in _SPECTRUM_KEYS, f"unknown spectrum table '{key}'")
            xs_, ph_ = np.asarray(tab.x, float), np.asarray(tab.phi_integral, float)
            need(len(xs_) >= 2 and len(xs_) == len(ph_), f"table '{key}' needs >= 2 matched points")
            need(bool(np.all(np.diff(xs_) > 0) and np.all(xs_ > 0)), f"table '{key}': x must be positive ascending")
            need(bool(np.all(ph_ >= 0) and np.all(np.diff(ph_) <= 0)), f"table '{key}': flux must be >= 0, non-increasing")
        need(r.environment_mode != "tabulated_orbit" or len(r.tables) > 0, "tabulated_orbit needs at least one table")
        # cross-section grids must start below every threshold, or flux would be silently dropped
        for reg in (r.sram, r.register, r.logic_set, r.sel):
            need(reg.ion.x_th > r.let_grid_lo, "ion x_th must exceed let_grid_lo")
            need(reg.proton.x_th > r.energy_grid_lo, "proton x_th must exceed energy_grid_lo")
        return self

    # ------------------------------------------------------------------
    def copy(self) -> "SimConfig":
        return copy.deepcopy(self)

    def to_dict(self) -> dict:
        return json.loads(json.dumps(asdict(self), default=str))

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(asdict(self), indent=indent, default=str, sort_keys=True)

    def config_hash(self) -> str:
        return hashlib.sha256(self.to_json(indent=0).encode()).hexdigest()[:16]

    # ---- round trip -------------------------------------------------------
    @classmethod
    def from_dict(cls, d: dict) -> "SimConfig":
        return _dc_from_dict(cls, d)

    @classmethod
    def from_json(cls, text: str) -> "SimConfig":
        return cls.from_dict(json.loads(text))


# ---------------------------------------------------------------------------
# Generic dict -> dataclass reconstruction (enums, nested dataclasses, Optional, Dict, List)
# ---------------------------------------------------------------------------
def _build(tp, val):
    if val is None:
        return None
    origin, args = typing.get_origin(tp), typing.get_args(tp)
    if dataclasses.is_dataclass(tp):
        return _dc_from_dict(tp, val)
    if isinstance(tp, type) and issubclass(tp, Enum):
        return tp[val.split(".")[-1]] if isinstance(val, str) else tp(val)
    if origin is typing.Union:
        inner = [a for a in args if a is not type(None)]
        return _build(inner[0], val)
    if origin in (dict, Dict):
        return {k: _build(args[1], v) for k, v in val.items()}
    if origin in (list, List):
        return [_build(args[0], v) for v in val]
    if tp is float:
        return float(val)
    if tp is int:
        return int(val)
    return val


def _dc_from_dict(cls, d: dict):
    hints = typing.get_type_hints(cls)
    names = {f.name for f in dataclasses.fields(cls)}
    unknown = set(d) - names
    if unknown:
        raise ValueError(f"{cls.__name__}: unknown field(s) {sorted(unknown)}")
    return cls(**{k: _build(hints[k], v) for k, v in d.items()})
