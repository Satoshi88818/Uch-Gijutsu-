"""Roofline / performance model.

v3 fixes vs v2
  * arithmetic intensity & traffic use the real GEMM dims (M, K, N), not M alone
  * HBM traffic from an explicit blocking model (operand re-reads when SRAM is too small)
  * the layer's own dtype is used (v2 used a global dtype)
  * sparsity is applied ONCE (executed work shrinks; peak throughput is unchanged)
  * array tiling quantisation and pipeline fill/drain are modelled via an exact cycle count
    (fill/drain fully exposed per tile unless ComputeConfig.pipeline_overlap > 0: conservative)
  * the inverted dtype throughput table is corrected (see config.DType)
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List

from .config import DType, SimConfig


@dataclass(frozen=True)
class WorkloadLayer:
    name: str
    kind: str
    M: int
    K: int
    N: int
    dtype: DType = DType.INT8
    sparsity: float = 0.0   # 0.0 (dense) or 0.5 (2:4 structured) -- the only patterns hardware supports

    def __post_init__(self):
        if min(self.M, self.K, self.N) <= 0:
            raise ValueError(f"layer {self.name}: M, K, N must be positive")
        if self.sparsity not in (0.0, 0.5):
            raise ValueError(f"layer {self.name}: only 0.0 or 0.5 (2:4) sparsity is supported, "
                             f"got {self.sparsity}")

    @property
    def dense_flops(self) -> float:
        return 2.0 * self.M * self.K * self.N


def structured_sparsity_speedup(sparsity: float, speedup_at_50: float = 1.85) -> float:
    """Compute-bound speedup of 2:4 structured sparsity.  All-or-nothing: 0.0 -> 1, 0.5 -> speedup_at_50."""
    if sparsity == 0.0:
        return 1.0
    if sparsity == 0.5:
        return float(speedup_at_50)
    raise ValueError("2:4 hardware supports only sparsity 0.0 or 0.5")


def weight_bytes_factor(sparsity: float, bytes_per_elem: float) -> float:
    """Stored weight bytes relative to dense: kept values + 2-bit index per kept value."""
    if sparsity == 0.0:
        return 1.0
    kept = 1.0 - sparsity
    return kept * (1.0 + 2.0 / (8.0 * bytes_per_elem))


@dataclass(frozen=True)
class LayerPerf:
    name: str
    duration_s: float
    t_compute_s: float
    t_memory_s: float
    memory_bound: bool
    dense_flops: float
    executed_flops: float
    hbm_bytes: float
    arithmetic_intensity: float      # executed flops / HBM byte
    ridge_point: float               # flops/byte at which compute == memory roofs
    util: float                      # fraction of peak MAC slots doing useful work, in [0,1]
    resident_sram_bits: float
    peak_exec_tflops: float


def hbm_bandwidth_bytes_s(cfg: SimConfig) -> float:
    m = cfg.memory
    eff = 1.0 / (1.0 + m.ecc_bw_overhead_pct / 100.0) if m.ecc_enabled else 1.0
    return m.hbm_bw_tb_s_per_stack * 1e12 * m.num_hbm_stacks * eff * m.hbm_efficiency


def estimate_layer(layer: WorkloadLayer, cfg: SimConfig, freq_ghz: float, exact_cycles: bool = True) -> LayerPerf:
    """``exact_cycles=False`` drops the ceil() on the reduction depth (< 1 cycle per tile): used only by the calibration fits,
    whose objective must be smooth in ``sparse_speedup_at_50``."""
    A = cfg.compute.array_size
    b = layer.dtype.bytes_per_elem
    thr = layer.dtype.pe_throughput
    f_hz = freq_ghz * 1e9
    M, K, N = layer.M, layer.K, layer.N

    spd = structured_sparsity_speedup(layer.sparsity, cfg.compute.sparse_speedup_at_50)
    K_eff = K / spd                                   # executed reduction depth

    # --- compute: output-stationary AxA array, exact cycle count -----------------
    tiles = math.ceil(M / A) * math.ceil(N / A)
    fill = 2 * A - 2                                        # systolic fill + drain skew
    k_cycles = math.ceil(K_eff / thr) if exact_cycles else K_eff / thr
    cycles = (tiles * k_cycles
              + fill * (1.0 + (tiles - 1) * (1.0 - cfg.compute.pipeline_overlap)))
    t_compute = cycles / f_hz
    ideal_cycles = M * N * K_eff / (A * A * thr)

    # --- memory: blocked GEMM traffic ---------------------------------------------
    sram_bytes = cfg.memory.onchip_sram_mb * 2**20
    T = max(1, int(math.sqrt(sram_bytes / (3.0 * b))))      # square tile edge, 3 operand tiles resident
    wfac = weight_bytes_factor(layer.sparsity, b)
    hbm_bytes = b * (M * K * math.ceil(N / T)
                     + wfac * K * N * math.ceil(M / T)
                     + M * N)
    bw = hbm_bandwidth_bytes_s(cfg)
    t_mem = hbm_bytes / bw

    duration = max(t_compute, t_mem)
    executed = 2.0 * M * N * K_eff
    peak_exec = 2.0 * A * A * f_hz * thr
    util = min(1.0, ideal_cycles / (duration * f_hz))
    working_set_bits = 8.0 * b * (M * K + wfac * K * N + M * N)
    resident = min(sram_bytes * 8.0, working_set_bits)

    return LayerPerf(
        name=layer.name, duration_s=duration, t_compute_s=t_compute, t_memory_s=t_mem,
        memory_bound=t_mem > t_compute, dense_flops=layer.dense_flops, executed_flops=executed,
        hbm_bytes=hbm_bytes, arithmetic_intensity=executed / hbm_bytes,
        ridge_point=peak_exec / bw, util=util, resident_sram_bits=resident,
        peak_exec_tflops=peak_exec / 1e12)


@dataclass(frozen=True)
class PassProfile:
    """Time-weighted summary of one forward pass at a fixed clock."""
    duration_s: float
    dense_flops: float
    executed_flops: float
    util: float
    live_sram_bits: float
    memory_bound_fraction: float
    layers: tuple


def profile_pass(layers: List[WorkloadLayer], cfg: SimConfig, freq_ghz: float) -> PassProfile:
    perfs = [estimate_layer(l, cfg, freq_ghz) for l in layers]
    dur = sum(p.duration_s for p in perfs)
    return PassProfile(
        duration_s=dur,
        dense_flops=sum(p.dense_flops for p in perfs),
        executed_flops=sum(p.executed_flops for p in perfs),
        util=sum(p.util * p.duration_s for p in perfs) / dur,
        live_sram_bits=sum(p.resident_sram_bits * p.duration_s for p in perfs) / dur,
        memory_bound_fraction=sum(p.duration_s for p in perfs if p.memory_bound) / dur,
        layers=tuple(perfs))


def build_transformer_workload(seq_len: int = 512, hidden_dim: int = 1024, num_heads: int = 16,
                               num_layers: int = 12, ffn_mult: int = 4, batch_size: int = 1,
                               dtype: DType = DType.INT8, sparsity: float = 0.0) -> List[WorkloadLayer]:
    d, ff, B, S = hidden_dim, hidden_dim * ffn_mult, batch_size, seq_len
    hd = d // num_heads
    out: List[WorkloadLayer] = []
    for i in range(num_layers):
        p = f"L{i:02d}"
        out += [
            WorkloadLayer(f"{p}/QKV", "linear", B * S, d, 3 * d, dtype, sparsity),
            WorkloadLayer(f"{p}/AttnScore", "attention", B * num_heads * S, hd, S, dtype, 0.0),
            WorkloadLayer(f"{p}/AttnOut", "attention", B * num_heads * S, S, hd, dtype, 0.0),
            WorkloadLayer(f"{p}/OutProj", "linear", B * S, d, d, dtype, sparsity),
            WorkloadLayer(f"{p}/FFN1", "linear", B * S, d, ff, dtype, sparsity),
            WorkloadLayer(f"{p}/FFN2", "linear", B * S, ff, d, dtype, sparsity),
        ]
    return out
