"""Real bit flips on real tensors, and measured architectural vulnerability (AVF).

v2 injected additive noise into a 64-element array of zeros.  Here a single bit of a
real operand is flipped (two's-complement / IEEE-754 aware) and the GEMM output is compared
with the fault-free output, so derating factors come from measurement, not guesswork.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from .rng import make_rng
from .stats import wilson_ci

_UINT = {1: np.uint8, 2: np.uint16, 4: np.uint32, 8: np.uint64}


def flip_bit(arr: np.ndarray, flat_index: int, bit: int) -> np.ndarray:
    """Return a copy of ``arr`` with bit ``bit`` (0 = LSB) of element ``flat_index`` flipped."""
    out = np.ascontiguousarray(arr).copy()
    nbits = out.dtype.itemsize * 8
    if not 0 <= bit < nbits:
        raise ValueError(f"bit {bit} out of range for {out.dtype} ({nbits} bits)")
    view = out.reshape(-1).view(_UINT[out.dtype.itemsize])
    view[flat_index] ^= _UINT[out.dtype.itemsize](1 << bit)
    return out


def _gemm(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    with np.errstate(all="ignore"):          # flipped exponents legitimately produce inf / NaN
        if np.issubdtype(a.dtype, np.integer):
            return a.astype(np.int64) @ b.astype(np.int64)
        return a.astype(np.float64) @ b.astype(np.float64)


def _random_operand(rng, shape, dtype) -> np.ndarray:
    dt = np.dtype(dtype)
    if np.issubdtype(dt, np.integer):
        info = np.iinfo(dt)
        return rng.integers(info.min, info.max + 1, size=shape).astype(dt)
    return rng.standard_normal(shape).astype(dt)


@dataclass(frozen=True)
class VulnerabilityResult:
    avf: float
    ci_low: float
    ci_high: float
    per_bit_avf: Tuple[float, ...]   # index = bit position, 0 = LSB
    n_trials: int
    tol: float


def measure_gemm_vulnerability(M: int = 32, K: int = 32, N: int = 32, dtype="int8", tol: float = 1e-2,
                               trials_per_bit: int = 100, seed: int = 0) -> VulnerabilityResult:
    """P(single-bit operand flip changes the GEMM output by more than ``tol`` relative L2 error).

    Bit positions are weighted uniformly (every stored bit is equally likely to be hit);
    A and B are hit in proportion to their size.  Non-finite outputs count as vulnerable.
    """
    rng = make_rng(seed, "avf", str(dtype), M, K, N)
    dt = np.dtype(dtype)
    nbits = dt.itemsize * 8
    A, B = _random_operand(rng, (M, K), dt), _random_operand(rng, (K, N), dt)
    C = _gemm(A, B)
    nc = float(np.linalg.norm(C.astype(np.float64)))
    p_a = (M * K) / (M * K + K * N)
    per_bit, hits, total = [], 0, 0
    for bit in range(nbits):
        h = 0
        for _ in range(trials_per_bit):
            if rng.random() < p_a:
                idx = int(rng.integers(0, M * K))
                C2 = _gemm(flip_bit(A, idx, bit), B)
            else:
                idx = int(rng.integers(0, K * N))
                C2 = _gemm(A, flip_bit(B, idx, bit))
            d = C2.astype(np.float64) - C.astype(np.float64)
            err = float(np.linalg.norm(d)) / max(nc, 1e-300) if np.all(np.isfinite(d)) else np.inf
            h += err > tol
        per_bit.append(h / trials_per_bit)
        hits += h
        total += trials_per_bit
    lo, hi = wilson_ci(hits, total)
    return VulnerabilityResult(hits / total, lo, hi, tuple(per_bit), total, tol)
