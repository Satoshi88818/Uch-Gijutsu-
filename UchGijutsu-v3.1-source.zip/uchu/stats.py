"""Small statistics helpers (exact Poisson intervals, Wilson, bootstrap)."""
from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np
from scipy.stats import chi2, norm


def poisson_rate_ci(k: int, exposure: float, conf: float = 0.95) -> Tuple[float, float]:
    """Exact (Garwood) two-sided CI for a Poisson rate = k / exposure."""
    if exposure <= 0:
        return (0.0, math.inf)
    alpha = 1.0 - conf
    lo = 0.0 if k == 0 else 0.5 * chi2.ppf(alpha / 2.0, 2 * k)
    hi = 0.5 * chi2.ppf(1.0 - alpha / 2.0, 2 * (k + 1))
    return lo / exposure, hi / exposure


def wilson_ci(successes: int, n: int, conf: float = 0.95) -> Tuple[float, float]:
    """Wilson score interval for a binomial proportion."""
    if n <= 0:
        return (0.0, 1.0)
    z = norm.ppf(0.5 + conf / 2.0)
    p = successes / n
    denom = 1.0 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


def bootstrap_ci(data, n_boot: int = 2000, conf: float = 0.95,
                 rng: Optional[np.random.Generator] = None) -> Tuple[float, float]:
    """Percentile bootstrap CI for the mean (vectorised)."""
    data = np.asarray(data, float)
    rng = rng or np.random.default_rng(0)
    idx = rng.integers(0, len(data), size=(n_boot, len(data)))
    means = data[idx].mean(axis=1)
    a = (1 - conf) / 2
    return float(np.quantile(means, a)), float(np.quantile(means, 1 - a))
