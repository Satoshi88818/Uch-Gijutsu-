# Uchū Gijutsu v3.1 — Extracted Source

Space AI ASIC Simulator with full calibration subsystem.

This package was reconstructed from the embedded sources in:
https://github.com/Satoshi88818/Uch-Gijutsu-

## Layout

```
uchu/                     # Core simulator + physics
  config.py               # SimConfig, CrossSection, enums
  memory.py               # Roofline / GEMM performance model
  orbit.py                # Eclipse + SEP flare schedule
  thermal.py              # Lumped thermal node
  radiation.py            # Cross-section × flux, ECC, MBU, SEL
  simulator.py            # ChipSimulator + run_mission / run_ensemble
  faults.py, rng.py, stats.py, provenance.py
  calibration/            # Measurement-driven calibration
    data.py               # Strict CSV/JSON loaders
    fit_radiation.py      # Weibull, MBU, SEP, AVF, flight update
    fit_hardware.py       # Power / thermal / performance fits
    registry.py           # declare / audit / require_calibrated
    workflow.py           # Orchestrator + CalibrationReport
    synthetic.py          # Synthetic campaign generator
tests/                    # 237 tests
tools/                    # demo + mutation_check
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install numpy scipy pytest pytest-cov

# Run unit tests (may take a few minutes)
PYTHONPATH=. pytest tests/ -q

# Synthetic calibration demo
python tools/calibration_demo.py

# Or use the CLI
python -m uchu.calibration plan.json --out out/
```

## Dependencies

- numpy
- scipy
- pytest / pytest-cov (for tests)

Optional (not required for core + calibration):
- matplotlib, plotly, pandas, joblib, SALib, pymoo, omegaconf, torch (CPU)

## License

MIT (as stated in the original repository README).

Original author: Wombat Rider (Satoshi88818)
