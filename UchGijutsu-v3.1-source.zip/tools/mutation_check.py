"""Mutation check: re-introduce a defect into a scratch copy of the package and confirm the relevant tests FAIL.
A surviving mutant means the suite would not have caught that bug.  Slow (statistical) tests are excluded; each mutant
runs only the test files that are supposed to guard that code.

    python tools/mutation_check.py [substring-filter]
"""
import pathlib, shutil, subprocess, sys, tempfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
MEM, THM, ORB, RAD = "tests/test_memory.py", "tests/test_thermal.py", "tests/test_orbit.py", "tests/test_radiation.py"
CD, CR, CH, CW = "tests/test_cal_data.py", "tests/test_cal_radiation.py", "tests/test_cal_hardware.py", "tests/test_cal_workflow.py"

MUTANTS = [
    # ---- v3 core (original v2 defects) -------------------------------------------------------------
    ("sparsity double-counted (v2 bug)", "uchu/memory.py", "    executed = 2.0 * M * N * K_eff\n",
     "    executed = 2.0 * M * N * K_eff / spd\n    t_compute = t_compute / spd\n", [MEM]),
    ("dtype throughput inverted (v2 bug)", "uchu/config.py", 'INT8 = ("int8", 1.0, 1.0)', 'INT8 = ("int8", 1.0, 0.25)', [MEM, "tests/test_rng_config.py"]),
    ("thermal state clobbered by static estimate (v2 bug)", "uchu/thermal.py",
     "        self.T = a if a == b else brentq(g, min(a, b), max(a, b), xtol=1e-10, rtol=1e-13, maxiter=200)\n        return self.T",
     "        self.T = a if a == b else brentq(g, min(a, b), max(a, b), xtol=1e-10, rtol=1e-13, maxiter=200)\n        self.T = 250.0 + 0.8 * power_fn(self.T)\n        return self.T", [THM]),
    ("GCR rises with solar activity (v2 bug)", "uchu/radiation.py",
     "{SolarActivity.LOW: 1.0, SolarActivity.MODERATE: 0.7, SolarActivity.HIGH: 0.45}",
     "{SolarActivity.LOW: 0.45, SolarActivity.MODERATE: 0.7, SolarActivity.HIGH: 1.0}", [RAD]),
    ("flare intensity ignored (v2 bug)", "uchu/orbit.py", "        return float(np.sum(i * overlap))", "        return float(np.sum(overlap))", [ORB]),
    ("no bit interleaving in ECC words", "uchu/radiation.py", "        return row * self.I + (col % self.I)", "        return bits // self.W", [RAD]),
    ("scrub declares everything corrected (v2 bug)", "uchu/radiation.py", "        corrected = int(np.sum(counts == 1))", "        corrected = int(counts.size)", [RAD]),
    ("XOR toggle replaced by OR", "uchu/radiation.py", "        self.state = u[(c % 2) == 1]", "        self.state = u", [RAD]),
    ("eclipse boundary dropped", "uchu/orbit.py", "            segs.append((t, b, True))", "            segs.append((t, b, False))", [ORB]),
    ("MBU probability ignored", "uchu/radiation.py", "            is_mbu = rng.random(n) < rc.mbu_prob", "            is_mbu = rng.random(n) < 0.0", [RAD]),
    ("SET capture ignores clock frequency", "uchu/radiation.py",
     "p_cap = min(1.0, rc.set_pulse_width_ps * 1e-12 * freq_ghz * 1e9)", "p_cap = min(1.0, rc.set_pulse_width_ps * 1e-12 * 1.5e9)", [RAD]),
    ("forward Euler instead of implicit", "uchu/thermal.py",
     "        C, T0, Q = self.tc.capacitance_j_per_k, self.T, self.env_load_w(eclipse)",
     "        C, T0, Q = self.tc.capacitance_j_per_k, self.T, self.env_load_w(eclipse)\n        self.T = T0 + dt * (power_fn(T0) + Q - self.radiated_w(T0)) / C\n        return self.T", [THM]),
    ("TMR has no effect", "uchu/radiation.py", "        self._tmr = rc.tmr_residual if rc.tmr_enabled else 1.0", "        self._tmr = 1.0", [RAD]),
    ("roofline uses only compute time", "uchu/memory.py", "    duration = max(t_compute, t_mem)", "    duration = t_compute", [MEM]),
    ("leakage factor applied to dynamic power (v2 bug)", "uchu/thermal.py",
     "        self.dynamic_nom_w = pw.base_power_w * (1.0 - pw.static_frac) * self.array_ratio * cap_rel",
     "        self.dynamic_nom_w = pw.base_power_w * (1.0 - pw.static_frac) * self.array_ratio * cap_rel * leak_rel", [THM]),
    # ---- calibration: config / environment hooks -------------------------------------------------------
    ("tabulated mode still applies placeholder scalings", "uchu/radiation.py", "        if tabulated:        # orbit-specific, already-shielded tables: no placeholder scalings",
     "        if False:", [CD]),
    ("hbm_efficiency ignored", "uchu/memory.py", " * eff * m.hbm_efficiency", " * eff", [CD, MEM]),
    ("MBU geometric parameter hard-coded", "uchu/radiation.py", "self.rng.geometric(self.rc.mbu_cluster_geom_p, size=n)", "self.rng.geometric(0.5, size=n)", [CD]),
    ("SEP intensity median ignored", "uchu/orbit.py", "self.rng.lognormal(math.log(self.median), self.log_sigma)", "self.rng.lognormal(0.0, self.log_sigma)", [CD]),
    ("config round-trip drops enums", "uchu/config.py", "        return tp[val.split(\".\")[-1]] if isinstance(val, str) else tp(val)", "        return list(tp)[0]", [CD]),
    # ---- calibration: data layer & registry ----------------------------------------------------------------
    ("effective LET multiplies by cos instead of dividing", "uchu/calibration/data.py", "    return let_normal / math.cos(math.radians(tilt_deg))", "    return let_normal * math.cos(math.radians(tilt_deg))", [CD]),
    ("tilt not applied to fluence", "uchu/calibration/data.py", "            fl = fl * math.cos(math.radians(tilt))", "            fl = fl", [CD]),
    ("accepted placeholders recorded as measured", "uchu/calibration/registry.py", "    record(cfg, path, source=\"analyst\", method=\"accepted\", status=STATUS_ACCEPTED, note=reason)",
     "    record(cfg, path, source=\"analyst\", method=\"accepted\", status=\"measured\", note=reason)", [CD]),
    ("audit counts accepted as resolved", "uchu/calibration/registry.py", "        elif e[\"status\"] == STATUS_ACCEPTED:\n            res.accepted[p] = e", "        elif e[\"status\"] == STATUS_ACCEPTED:\n            res.resolved[p] = e", [CD]),
    # ---- calibration: radiation fits -------------------------------------------------------------------------
    ("Poisson NLL sign error", "uchu/calibration/fit_radiation.py", "    return float(np.sum(mu - k * np.log(mu)))", "    return float(np.sum(mu + k * np.log(mu)))", [CR]),
    ("deviance missing factor 2", "uchu/calibration/fit_radiation.py", "    return float(2.0 * np.sum(t - (k - mu)))", "    return float(np.sum(t - (k - mu)))", [CR]),
    ("bootstrap does not resample", "uchu/calibration/fit_radiation.py", "th1, d1 = bootstrap(lambda: rng.poisson(mu_hat).astype(float))", "th1, d1 = bootstrap(lambda: np.round(mu_hat))", [CR]),
    ("over-dispersed intervals not widened", "uchu/calibration/fit_radiation.py", "        samples = th2", "        samples = th1", [CR]),
    ("saturation warning never fires", "uchu/calibration/fit_radiation.py", "    if frac_sat < 0.9:", "    if False:", [CR]),
    ("MBU geometric MLE inverted", "uchu/calibration/fit_radiation.py", "    q = n_stop / (n_stop + n_cont) if (n_stop + n_cont) > 0 else 1.0", "    q = n_cont / (n_stop + n_cont) if (n_stop + n_cont) > 0 else 1.0", [CR]),
    ("SEP rate not converted to per-year", "uchu/calibration/fit_radiation.py", "    rate = n / cat.obs_span_s * yr", "    rate = n / cat.obs_span_s", [CR]),
    ("flight likelihood inverted", "uchu/calibration/fit_radiation.py", "        like = stats.poisson.pmf(k_obs, E)\n", "        like = 1.0 - stats.poisson.pmf(k_obs, E)\n", [CR]),
    ("Gamma posterior ignores Jeffreys half-count", "uchu/calibration/fit_radiation.py", "    d = stats.gamma(k_obs + 0.5, scale=1.0 / E_expected)", "    d = stats.gamma(k_obs, scale=1.0 / E_expected)", [CR]),
    ("weighted quantile ignores weights", "uchu/calibration/fit_radiation.py", "    cw = np.cumsum(w) - 0.5 * w", "    cw = np.arange(len(w)) + 0.5", [CR]),
    ("table coverage check disabled", "uchu/calibration/fit_radiation.py", "            if xs.sigma_sat_cm2 > 0 and tab.x[0] > xs.x_th:", "            if False:", [CR]),
    # ---- calibration: hardware fits -----------------------------------------------------------------------------
    ("power inversion swaps static and dynamic", "uchu/calibration/fit_hardware.py", "    return stat + dyn, stat / (stat + dyn)", "    return stat + dyn, dyn / (stat + dyn)", [CH]),
    ("identifiability check disabled", "uchu/calibration/fit_hardware.py", "    if cond > COND_FATAL:", "    if False:", [CH]),
    ("thermal integrator uses the wrong interval's eclipse flag", "uchu/calibration/fit_hardware.py", "        rhs = P[i] + (Q_ecl if ecl[i] else Q_sun)", "        rhs = P[i] + (Q_ecl if ecl[i - 1] else Q_sun)", [CH]),
    ("radiator area ignores view factor", "uchu/calibration/fit_hardware.py", "    A = kr / (SIGMA_SB * tc.emissivity * F_eff)", "    A = kr / (SIGMA_SB * tc.emissivity)", [CH]),
    ("zero-sensitivity parameters never dropped", "uchu/calibration/fit_hardware.py", "        weak = [free[j] for j in range(len(free)) if cn[j] < 1e-6 * max(cn.max(), 1e-300)]", "        weak = []", [CH]),
    ("launch-overhead bound too tight (bug found during development)", "uchu/calibration/fit_hardware.py", "hi = np.array([1.0, 1.0, 2.0, 0.999 * lat.min()])", "hi = np.array([1.0, 1.0, 2.0, 0.9 * lat.min()])", [CH]),
    ("sparse parameter always considered informative", "uchu/calibration/fit_hardware.py", "        if m.sparsity == 0.5 and a.t_memory_s < 0.5 * a.t_compute_s:", "        if m.sparsity == 0.5:", [CH]),
    # ---- calibration: workflow -------------------------------------------------------------------------------------
    ("placeholder-dependence flag always zero", "uchu/calibration/workflow.py", "    frac = sum(part[k] for k in unresolved) / total if total > 0 else 0.0", "    frac = 0.0", [CW]),
    ("flight weights not applied to draws", "uchu/calibration/workflow.py", "        weights = wts / wts.sum()", "        weights = np.ones(len(draws)) / len(draws)", [CW]),
    ("step failures abort silently as ok", "uchu/calibration/workflow.py", "            steps.append(StepResult(name, \"failed\", error=str(e)))", "            steps.append(StepResult(name, \"ok\", {}))", [CW]),
    ("input config mutated in place", "uchu/calibration/workflow.py", "    cfg = cfg.copy().validate()\n    steps", "    cfg = cfg.validate()\n    steps", [CW]),
]


def run_one(name, rel, old, new, tests):
    with tempfile.TemporaryDirectory() as td:
        dst = pathlib.Path(td) / "w"
        shutil.copytree(ROOT, dst, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache", ".coverage", "tools", "*.pyc"))
        f = dst / rel
        src = f.read_text()
        if old not in src:
            return "SETUP-ERROR", f"pattern not found in {rel}"
        f.write_text(src.replace(old, new, 1))
        r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider", "-m", "not slow", *tests],
                           cwd=dst, capture_output=True, text=True)
        first = next((l for l in r.stdout.splitlines() if l.startswith("FAILED") or l.startswith("ERROR")), "")
        return ("KILLED" if r.returncode != 0 else "SURVIVED"), first


def main() -> int:
    flt = sys.argv[1] if len(sys.argv) > 1 else ""
    bad = []
    sel = [m for m in MUTANTS if flt in m[0]]
    for name, rel, old, new, tests in sel:
        status, first = run_one(name, rel, old, new, tests)
        print(f"[{status:8s}] {name}   {first.split(' - ')[0][-70:]}", flush=True)
        if status != "KILLED":
            bad.append(name)
    print(f"\n{len(sel) - len(bad)}/{len(sel)} mutants killed")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
