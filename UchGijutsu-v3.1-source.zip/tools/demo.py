"""Demo: 3 LEO orbits of a 12-layer INT8 transformer; prints a compact, reproducible summary."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from uchu import SimConfig, build_transformer_workload, run_mission, run_workload

cfg = SimConfig(random_seed=42)
cfg.thermal.capacitance_j_per_k = 200.0
layers = build_transformer_workload(num_layers=12)

w = run_workload(cfg, layers, n_passes=100)
print(f"[workload] {w.n_passes} passes, {w.elapsed_s*1e3:.2f} ms simulated")
print(f"  dense-equivalent throughput : {w.avg_tflops_dense:7.2f} TFLOPS   power {w.avg_power_w:6.2f} W   "
      f"({w.tflops_per_watt:.2f} TFLOPS/W)   memory-bound time {w.memory_bound_fraction:.1%}")

m = run_mission(cfg, layers, mission_s=3 * 5739.0, duty=0.8, dt_max_s=10.0)
r = m.radiation
print(f"[mission ] {m.simulated_s/3600:.2f} h simulated, completed={m.completed}, failed={m.failed}")
print(f"  temperature  min/mean/max   : {m.T_min_k:6.1f} / {m.T_mean_k:6.1f} / {m.T_max_k:6.1f} K   throttled {m.throttled_fraction:.1%}")
print(f"  power / throughput           : {m.avg_power_w:6.2f} W / {m.avg_tflops_dense:6.2f} TFLOPS (duty 0.8)")
print(f"  SRAM SEUs / MBU / corrected  : {r.n_seu_sram} / {r.n_mbu} / {r.words_corrected}   DUE {r.words_due}   SDC {r.sdc_total}")
lo, hi = r.sdc_per_hr_ci()
print(f"  SDC rate 95% CI (per hour)   : [{lo:.3g}, {hi:.3g}]   availability {r.availability:.4f}")
print(f"  provenance                   : {m.provenance['model_version']} cfg={m.provenance['config_hash']} seed={m.provenance['seed']}")
