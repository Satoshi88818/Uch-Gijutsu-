"""End-to-end calibration demo on a SYNTHETIC campaign (hidden truth -> CSV files -> plan.json -> CLI -> report).

    python tools/calibration_demo.py [work_dir]

Shows the exact file formats and the exact command a real campaign would use.  Synthetic data prove the machinery
recovers known parameters; they do not prove the models describe real hardware.
"""
import json, pathlib, sys, tempfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from uchu import SimConfig, make_rng
from uchu.calibration.registry import get_by_path
from uchu.calibration.synthetic import analyst_start_config, make_truth_config, write_campaign
from uchu.calibration.workflow import _static_rate_per_bit_day, main

work = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix="uchu_cal_"))
truth = make_truth_config()
plan = write_campaign(work / "campaign", truth, analyst_start_config(truth), make_rng(2024, "demo"))
print(f"campaign files: {sorted(p.name for p in plan.parent.iterdir())}\n")
code = main([str(plan), "--out", str(work / "out")])

cfg = SimConfig.from_json((work / "out" / "calibrated_config.json").read_text())
rows = [(p, get_by_path(truth, p), e) for p, e in sorted(cfg.calibration.items()) if e["ci95"] and p != "radiation.avf_sram"]
inside = sum(e["ci95"][0] <= tv <= e["ci95"][1] for _, tv, e in rows)
print(f"\nhidden truth inside the 95 % interval: {inside}/{len(rows)} parameters")
tr = _static_rate_per_bit_day(truth, "sram")
rs = json.loads((work / "out" / "calibration_report.json").read_text())["rate_summary"]["sram"]
print(f"SRAM upset rate / bit / day: truth {tr:.3e} | shipped placeholder {rs['placeholder']:.3e} | "
      f"calibrated {rs['median']:.3e} [{rs['lo']:.3e}, {rs['hi']:.3e}]")
print(f"outputs in {work / 'out'}")
sys.exit(code)
